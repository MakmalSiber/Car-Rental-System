<?php 

include('_header.php'); 

$sql = "SELECT * FROM front_page WHERE id = 1";
db_select($sql);
if (db_rowcount() > 0) {
    func_setSelectVar();

} 
?>

<body class="load-full-screen">

<!-- BEGIN: PRELOADER -->
<div id="loader" class="load-full-screen">
	<div class="loading-animation">
		<span><i class="fa fa-plane"></i></span>
		<span><i class="fa fa-bed"></i></span>
		<span><i class="fa fa-ship"></i></span>
		<span><i class="fa fa-suitcase"></i></span>
	</div>
</div>
<!-- END: PRELOADER -->

	<?php include('_panel.php'); ?>

	<!-- BEGIN: SEARCH SECTION -->
	<div class="row">
		<div class="container">
			<div class="col-md-8 col-sm-6 text-center">
				<div>
					<div class="hotel-tagline text-center">
						<h3>Welcome to</h3>
						<h1><?php echo $website_name; ?></h1>
					</div>
				</div>
			</div>

			<div class="col-md-4 col-sm-6">
				<div class="room-check">
					<h4 class="text-center">BOOK A CAR</h4>
					<div class="room-check-body">
						<form action="booking.php" onsubmit="return validateForm()">
							<label>Pick Up Location</label>
							<div class="input-group">
								<select class="form-control" name="search_pickup_location">
										<?php
										$value = "";
										$sql = "SELECT id, description FROM location WHERE status = 'A'";
										db_select($sql);if (db_rowcount() > 0) {for ($j = 0; $j < db_rowcount(); $j++) {$value = $value . "<option value=" . db_get($j, 0) . " " . vali_iif(db_get($j, 0) == $class_id, 'Selected', '') . ">" . db_get($j, 1) . "</option>";}}
										echo $value;
										?>
								</select>
								<span class="input-group-addon"><i class="fa fa-map-marker fa-fw"></i></span>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6 padding-right">
							<label>Pick Up Date</label>
							<div class="input-group">
								<input type="text" autocomplete="off" id="check_in" name="search_pickup_date" class="form-control" placeholder="DD/MM/YYYY" required>
								<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
							</div>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6 padding-left">
							<label>Pick Up Time</label>
							<div class="input-group">
								<select name="search_pickup_time" class="form-control">
										<option value="00:00">00.00</option>
										<option value="00:30">00.30</option>
										<option value="01:00">01.00</option>
										<option value="01:30">01.30</option>
										<option value="02:00">02.00</option>
										<option value="02:30">02.30</option>
										<option value="03:00">03.00</option>
										<option value="03:30">03.30</option>
										<option value="04:00">04.00</option>
										<option value="04:30">04.30</option>
										<option value="05:00">05.00</option>
										<option value="05:30">05.30</option>
										<option value="06:00">06.00</option>
										<option value="06:30">06.30</option>
										<option value="07:00">07.00</option>
										<option value="07:30">07.30</option>
										<option value="08:00">08.00</option>
										<option value="08:30">08.30</option>
										<option value="09:00">09.00</option>
										<option value="09:30">09.30</option>
										<option value="10:00">10.00</option>
										<option value="10:30">10.30</option>
										<option value="11:00">11.00</option>
										<option value="11:30">11.30</option>
										<option selected="" value="12:00">12.00</option>
										<option value="12:30">12.30</option>
										<option value="13:00">13.00</option>
										<option value="13:30">13.30</option>
										<option value="14:00">14.00</option>
										<option value="14:30">14.30</option>
										<option value="15:00">15.00</option>
										<option value="15:30">15.30</option>
										<option value="16:00">16.00</option>
										<option value="16:30">16.30</option>
										<option value="17:00">17.00</option>
										<option value="17:30">17.30</option>
										<option value="18:00">18.00</option>
										<option value="18:30">18.30</option>
										<option value="19:00">19.00</option>
										<option value="19:30">19.30</option>
										<option value="20:00">20.00</option>
										<option value="20:30">20.30</option>
										<option value="21:00">21.00</option>
										<option value="21:30">21.30</option>
										<option value="22:00">22.00</option>
										<option value="22:30">22.30</option>
										<option value="23:00">23.00</option>
										<option value="23:30">23.30</option>
									</select>
								<span class="input-group-addon"><i class="fa fa-clock-o fa-fw"></i></span>
								</div>
							</div>
							<label>Return Location</label>
							<div class="input-group">
								<select class="form-control" name="search_return_location">
										<?php
										$value = "";
										$sql = "SELECT id, description FROM location WHERE status = 'A'";
										db_select($sql);if (db_rowcount() > 0) {for ($j = 0; $j < db_rowcount(); $j++) {$value = $value . "<option value=" . db_get($j, 0) . " " . vali_iif(db_get($j, 0) == $class_id, 'Selected', '') . ">" . db_get($j, 1) . "</option>";}}
										echo $value;
										?>
								</select>
								<span class="input-group-addon"><i class="fa fa-map-marker fa-fw"></i></span>
							</div>
							
							<div class="col-md-6 col-sm-6 col-xs-6 padding-right">
								<label>Return Date</label>
								<div class="input-group">
									<input type="text" autocomplete="off" id="check_out" name="search_return_date" class="form-control" placeholder="DD/MM/YYYY" required>
									<span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
								</div>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6 padding-left">
								<label>Return Time</label>
								<div class="input-group">
								<select name="search_return_time" class="form-control">
											<option value="00:00">00.00</option>
											<option value="00:30">00.30</option>
											<option value="01:00">01.00</option>
											<option value="01:30">01.30</option>
											<option value="02:00">02.00</option>
											<option value="02:30">02.30</option>
											<option value="03:00">03.00</option>
											<option value="03:30">03.30</option>
											<option value="04:00">04.00</option>
											<option value="04:30">04.30</option>
											<option value="05:00">05.00</option>
											<option value="05:30">05.30</option>
											<option value="06:00">06.00</option>
											<option value="06:30">06.30</option>
											<option value="07:00">07.00</option>
											<option value="07:30">07.30</option>
											<option value="08:00">08.00</option>
											<option value="08:30">08.30</option>
											<option value="09:00">09.00</option>
											<option value="09:30">09.30</option>
											<option value="10:00">10.00</option>
											<option value="10:30">10.30</option>
											<option value="11:00">11.00</option>
											<option value="11:30">11.30</option>
											<option selected="" value="12:00">12.00</option>
											<option value="12:30">12.30</option>
											<option value="13:00">13.00</option>
											<option value="13:30">13.30</option>
											<option value="14:00">14.00</option>
											<option value="14:30">14.30</option>
											<option value="15:00">15.00</option>
											<option value="15:30">15.30</option>
											<option value="16:00">16.00</option>
											<option value="16:30">16.30</option>
											<option value="17:00">17.00</option>
											<option value="17:30">17.30</option>
											<option value="18:00">18.00</option>
											<option value="18:30">18.30</option>
											<option value="19:00">19.00</option>
											<option value="19:30">19.30</option>
											<option value="20:00">20.00</option>
											<option value="20:30">20.30</option>
											<option value="21:00">21.00</option>
											<option value="21:30">21.30</option>
											<option value="22:00">22.00</option>
											<option value="22:30">22.30</option>
											<option value="23:00">23.00</option>
											<option value="23:30">23.30</option>
										</select>
									<span class="input-group-addon"><i class="fa fa-clock-o fa-fw"></i></span>
								</div>
							</div>
							<div class="text-center">
								<button name="btn_search" type="submit">Find Cars</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END: SEARCH SECTION -->

<!-- START: HOW IT WORK -->
<section id="how-it-work">
		<div class="row work-row">
			<div class="container">
				<div class="section-title text-center">
					<h2><?php echo $hero_title; ?></h2>
					<h4><?php echo $hero_subtitle; ?></h4>
					<div class="space"></div>
					<p>
						<?php echo $hero_paragraph; ?>
					</p>
				</div>
				<div class="work-step">
					<div class="col-md-4 col-sm-4 first-step text-center">
						<i class="fa fa-search"></i>
						<h5><?php echo $heroes_title1; ?></h5>
						<p><?php echo $heroes_sub1; ?></p>
					</div>
					<div class="col-md-4 col-sm-4 second-step text-center">
						<i class="fa fa-heart-o"></i>
						<h5><?php echo $heroes_title2; ?></h5>
						<p><?php echo $heroes_sub2; ?></p>
					</div>
					<div class="col-md-4 col-sm-4 third-step text-center">
						<i class="fa fa-shopping-cart"></i>
						<h5><?php echo $heroes_title3; ?></h5>
						<p><?php echo $heroes_sub3; ?></p>
					</div>
				</div>
			</div>
		</div>
</section>
<!-- END: HOW IT WORK -->

<!-- START: PRODUCT SECTION-->
<section class="hotel-product home-product">
	<!-- START: PRODUCT ROW 1 -->
	<div class="row light-row">
			<div class="col-md-6 clear-padding wow slideInLeft">
				<div class="product-wrapper">
					<div class="col-md-6 col-sm-6 home-product-padding tooltip-right">
						<h4><?php echo $productone_title; ?></h4>
						<h5><i class="fa fa-certificate"></i> <?php echo $productone_subtitle; ?></h5>
						<p><?php echo $productone_desc; ?></p>
						<div class="clearfix"></div>
						<div class="pricing-info">
							<span>RM<?php echo $productone_price; ?>/DAY</span> 
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-6 col-sm-6 clear-padding image-sm text-center">
						<img src="dashboard/assets/img/cms/<?php echo $productone_img; ?>" alt="<?php echo $productone_img; ?>">
						<div class="detail-link-wrapper">
							<div class="detail-link">
								<a href="#"><i class="fa fa-search"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="product-wrapper">
					<div class="col-md-6 col-sm-6 clear-padding image-sm text-center">
					<img src="dashboard/assets/img/cms/<?php echo $producttwo_img; ?>" alt="<?php echo $producttwo_img; ?>">
						<div class="detail-link-wrapper">
							<div class="detail-link">
								<a href="#"><i class="fa fa-search"></i></a>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6 home-product-padding tooltip-left">
						<h4><?php echo $producttwo_title; ?></h4>
						<h5><i class="fa fa-certificate"></i> <?php echo $producttwo_subtitle; ?></h5>
						<p><?php echo $producttwo_desc; ?></p>
						<div class="clearfix"></div>
						<div class="pricing-info">
							<span>RM<?php echo $producttwo_price; ?>/DAY</span> 
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="clearfix visible-sm-block"></div>
			<div class="col-md-6 clear-padding image-lg wow slideInRight">
				<img src="dashboard/assets/img/cms/<?php echo $productthree_img; ?>" alt="<?php echo $productthree_img; ?>">
				<div class="overlay">
					<div class="product-detail text-center">
						<h3><?php echo $productthree_title; ?></h3>
						<h5><i class="fa fa-certificate"></i> <?php echo $productthree_subtitle; ?></h5>
						<p><?php echo $productthree_desc; ?></p>
						<div class="clearfix"></div>
						<div class="pricing-info">
							<span>RM<?php echo $productthree_price; ?>/DAY</span> 
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
	</div>
	<!-- END: PRODUCT ROW 1 -->
</section>
<!-- END: PRODUCT SECTION -->

<!-- START: WHY CHOOSE US SECTION -->
<section id="why-choose-us">
	<div class="row choose-us-row">
		<div class="container clear-padding">
			<div class="light-section-title text-center">
				<h2><?php echo $choose_titlebar; ?></h2>
				<h4><?php echo $choose_sub_title; ?></h4>
				<div class="space"></div>
				<p>
					<?php echo $choose_desc; ?>
				</p>
			</div>
			<div class="col-md-4 col-sm-4 wow slideInLeft">
				<div class="choose-us-item text-center">
					<div class="choose-icon"><i class="fa fa-car"></i></div>
					<h4><?php echo $choose_card_title1; ?></h4>
					<p><?php echo $choose_card_subtitle1; ?></p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 wow slideInUp">
				<div class="choose-us-item text-center">
					<div class="choose-icon"><i class="fa fa-phone"></i></div>
					<h4><?php echo $choose_card_title2; ?></h4>
					<p><?php echo $choose_card_subtitle2; ?></p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 wow slideInRight">
				<div class="choose-us-item text-center">
					<div class="choose-icon"><i class="fa fa-smile-o"></i></div>
					<h4><?php echo $choose_card_title3; ?></h4>
					<p><?php echo $choose_card_subtitle3; ?></p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END: WHY CHOOSE US SECTION -->

<!-- START: TESTIMONIAL SECTION -->
<section id="customer-testimonial">
	<div class="row">
		<div class="container">
			<div class="section-title text-center">
				<h2><?php echo $testimonial_title; ?></h2>
				<h4><?php echo $testimonial_subtitle; ?></h4>
			</div>
			<div class="owl-carousel" id="review-customer">
				<div class="individual">
					<div class="col-md-2 col-sm-3 text-center">
						<img src="dashboard/assets/img/cms/<?php echo $testimonial_pic; ?>" alt="<?php echo $testimonial_pic; ?>">
					</div>
					<div class="col-md-10 col-sm-9 customer-word">
						<p class="text-center">
							<span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
							<?php echo $testimonial_feedback; ?>
						</p>
						<h5 class="text-center"><?php echo $testimonial_name; ?></h5>
						<h6 class="text-center"><?php echo $testimonial_origin; ?></h6>
					</div>
				</div>
				<div class="individual">
					<div class="col-md-2 col-sm-3 text-center">
						<img src="dashboard/assets/img/cms/<?php echo $testimonial_img; ?>" alt="<?php echo $testimonial_img; ?>">
					</div>
					<div class="col-md-10 col-sm-9 customer-word">
						<p class="text-center">
							<span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
							<?php echo $testimonial_feedbacks; ?>
						</p>
						<h5 class="text-center"><?php echo $testimonial_users; ?></h5>
						<h6 class="text-center"><?php echo $testimonial_origins; ?></h6>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END: TESTIMONIAL SECTION -->

<?php include('_footer.php'); ?>

<script>
	var check_in = $('#check_in').datepicker({ dateFormat: 'dd/mm/yy' }).val();
	var check_out = $('#check_out').datepicker({ dateFormat: 'dd/mm/yy' }).val();
</script>

<script type="text/javascript">

jQuery(function($){
	"use strict";
	$.supersized({

		//Functionality
		slideshow               :   1,		//Slideshow on/off
		autoplay				:	1,		//Slideshow starts playing automatically
		start_slide             :   1,		//Start slide (0 is random)
		random					: 	0,		//Randomize slide order (Ignores start slide)
		slide_interval          :   10000,	//Length between transitions
		transition              :   1, 		//0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
		transition_speed		:	500,	//Speed of transition
		new_window				:	1,		//Image links open in new window/tab
		pause_hover             :   0,		//Pause slideshow on hover
		keyboard_nav            :   0,		//Keyboard navigation on/off
		performance				:	1,		//0-Normal, 1-Hybrid speed/quality, 2-Optimizes image quality, 3-Optimizes transition speed // (Only works for Firefox/IE, not Webkit)
		image_protect			:	1,		//Disables image dragging and right click with Javascript

		//Size & Position
		min_width		        :   0,		//Min width allowed (in pixels)
		min_height		        :   0,		//Min height allowed (in pixels)
		vertical_center         :   1,		//Vertically center background
		horizontal_center       :   1,		//Horizontally center background
		fit_portrait         	:   1,		//Portrait images will not exceed browser height
		fit_landscape			:   0,		//Landscape images will not exceed browser width

		//Components
		navigation              :   1,		//Slideshow controls on/off
		thumbnail_navigation    :   1,		//Thumbnail navigation
		slide_counter           :   1,		//Display slide numbers
		slide_captions          :   1,		//Slide caption (Pull from "title" in slides array)
		slides 					:  	[		//Slideshow Images
											{image : 'assets/images/car-slide1.jpg', title : 'Slide 2'},
											{image : 'assets/images/car-slide2.jpg', title : 'Slide 1'}
									]

	});
});

</script>

<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','../../../../../www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-68058832-1', 'auto');
ga('send', 'pageview');
</script>

</body>

</html>