<?php
	include("_header.php");
	
	func_setReqVar();
	
	if(isset($btn_save)){
		func_setValid("Y");
		func_isEmpty($status, "status");
	
		if(func_isValid()){
			$sql="INSERT INTO class
			(
			class_name,
			people_capacity,
			baggage_capacity,
			doors,
			air_conditioned,
			max_weight,
			transmission, 
			desc_1, 
			desc_2, 
			desc_3, 
			desc_4, 
			status,  
			cid, 
			cdate
			)
			VALUES
			(
			'$class_name',
			'$people_capacity',
			'$baggage_capacity',
			'$vehicle_door',
			'$air_conditioned',
			'$weight',
			'$transmission',
			'$desc_1',
			'$desc_2',
			'$desc_3',
			'$desc_4',
			'$status',
			".$_SESSION['cid'].",
			CURRENT_TIMESTAMP
			)
			";
			//echo $sql;
			db_update($sql);
			
			
			$sql="SELECT last_insert_id() FROM class";
			db_select($sql);
			if(db_rowcount()>0){
				$id=db_get(0,0);
				//echo $id;
			}

			$sql = "INSERT INTO car_rate (class_id) VALUES ($id)";
			db_update($sql);
			vali_redirect("vehicle_rate.php?id=$id");
		}
	}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Vehicle Classes</h4>
                </div>
            <div class="card-content">
                     <form method="POST">
						<span style="color:red"><?php echo func_getErrMsg();?></span>
						<div class="form-group">
							<label class="control-label">Class Name</label>
							<input type="text" class="form-control" name="class_name" value="<?php echo $class_name;?>">
						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">People Capacity</label>
									<input class="form-control" name="people_capacity" value="<?= $people_capacity; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Baggage Capacity</label>
									<input class="form-control" name="baggage_capacit" value="<?= $baggage_capacity; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
										<label class="control-label">Vehicle Door</label>
										<input class="form-control" name="vehicle_door" value="<?= $vehicle_door; ?>">
								</div>
							</div>
						</div>
						

						
								<div class="form-group">
										<label class="control-label">Maximum Weight</label>
										<input class="form-control" name="maximum_weight" value="<?= $weight; ?>">
								</div>
						
						<div class="form-group label-floating">
                            <label class="control-label">Air Conditioned</label>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="Y" name="air_conditioned" <?php echo vali_iif('Y' == $air_conditioned, 'Checked', ''); ?>> &nbsp;
                                    </label>
                                </div>
                        </div>

						 <div class="form-group label-floating">
                                        <label class="control-label">Transmission</label>
                                        <select name="transmission" class="form-control">
                                            <option value='A' <?php echo vali_iif('A' == $transmission, 'Selected', ''); ?>>Automatic</option>
                                            <option value='M' <?php echo vali_iif('M' == $transmission, 'Selected', ''); ?>>Manual</option>
                                        </select>
                                    </div>
                        

						<div class="row">
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Description One</label>
                                        <input class="form-control" name="desc_1" value="<?php echo $desc_1; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Description Two</label>
                                        <input class="form-control" name="desc_2" value="<?php echo $desc_2; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Description Three</label>
                                        <input class="form-control" name="desc_3" value="<?php echo $desc_3; ?>">
                                        
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Description Four</label>
                                        <input class="form-control" name="desc_4" value="<?php echo $desc_4; ?>">
                                    </div>
                                </div>
                            </div>

						<div class="form-group">
							<label class="control-label">Status</label>
								<select name="status" class="form-control">
									<option value='A' <?php echo vali_iif('A'==$status,'Selected','');?>>Active</option>
									<option value='I' <?php echo vali_iif('I'==$status,'Selected','');?>>In-Active</option>
								</select>
						</div>

						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save & Next</button>
							</div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

<?php include("_footer.php"); ?>