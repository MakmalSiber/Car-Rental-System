<?php
	include("_header.php");
	func_setReqVar();
	
	session_unset();
	session_destroy();
	
	vali_redirect('index.php');
?>