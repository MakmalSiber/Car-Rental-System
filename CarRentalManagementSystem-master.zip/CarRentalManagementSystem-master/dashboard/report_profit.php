<?php

    include("_header.php"); 
    func_setReqVar(); 
    if (isset($btn_clear)) { vali_redirect('report_profit.php'); } 
?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="purple">
                            <h4 class="title">Profit</h4>
                        </div>
                        <div class="card-content">
                         <form>

                        <div class="row">
                            <div class="form-group">
                                <select class="form-control" name="search_investor" <?php echo $disabled;?>>
                                    <?php  $value = ""; $sql = "SELECT id, investor_name FROM investor"; 
                                    db_select($sql); 
                                    if(db_rowcount()>0){ 
                                        for($j=0;$j<db_rowcount();$j++){ 
                                            $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$search_investor,'Selected','').">".db_get($j,1)."</option>"; 
                                            } 
                                        } 
                                    echo $value; ?>
                                </select>
                            </div>
						</div>   

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-success" name="btn_search">Search</button>
							<a href="report_profit.php" class="btn btn-warning">Clear</a>
						</div>
						<div class="table-responsive">
                        <table class="table">
                        <thead class="text-primary">
											<th>No.</th>
											<th>Investor</th>
											<th>Car</th>
											<th>Sales</th>
											<th>Monthly Loan</th>
											<th>Maintenance</th>
											<th>Roadtax + Insurance</th>
											<th>Total Cost</th>
											<th>Total Profit</th>
											<th>Investor Profit (40%)</th>
											<th>Company Profit (60%)</th>
										</thead>
										<tbody>
                                        <?php
                            func_setPage(); 
                            func_setOffset(); 
                            func_setLimit(10);
                            if(isset($btn_search)){ 
                                if($search_investor!=""){ 
                                    $where=" AND investor.id = '".$search_investor."'"; 
                                } 
                            }
                            $sql = "SELECT 
                            vehicle.id,
                            investor_name,
                            monthly_loan,
                            reg_no,
                            make,
                            model,
                            loan_account_no,
                            cost,
                            amount,
                            sum(sub_total)
                            FROM vehicle 
                            LEFT JOIN investor ON vehicle.id = investor.vehicle_id 
                            LEFT JOIN fleet_maintenance ON vehicle.id = fleet_maintenance.vehicle_id 
                            LEFT JOIN fleet_insurance ON vehicle.id = fleet_insurance .vehicle_id 
                            LEFT JOIN booking_trans ON vehicle.id = booking_trans.vehicle_id 
                            WHERE investor.id IS NOT NULL
                            GROUP BY vehicle.id " .$where;
                            db_select($sql); 
                            
                            func_setTotalPage(db_rowcount()); 
                            db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset()); 
                            if(db_rowcount()>0) { 
                                for($i=0;$i<db_rowcount();$i++){ 
                                    if(func_getOffset()>=10){ 
                                        $no=func_getOffset()+1+$i; 
                                    }else{ 
                                        $no=$i+1; 
                                    } 
                                    $totalcost = number_format(db_get($i,2) + db_get($i,7) + db_get($i,8),2);
                                    $totalprofit = number_format(db_get($i,9) - $totalcost,2);
                                    $investotprofit = number_format(($totalprofit*40)/100,2);
                                    $companyprotfit = number_format(($totalprofit*60)/100,2);

                                    echo "<tr>
										<td>".$no."</td>
										<td>".db_get($i,1)."</td>
										<td>".db_get($i,4).' '.db_get($i,5).' ('.db_get($i,3).')'."</td>
										<td>RM ".db_get($i,9)."</td>
										<td>RM ".db_get($i,2)."</td>
										<td>RM ".db_get($i,7)."</td>
										<td>RM ".db_get($i,8)."</td>
										<td>RM ".$totalcost."</td>
										<td>RM ".$totalprofit."</td>
										<td>RM ".$investotprofit."</td>
										<td>RM ".$companyprotfit."</td>
                                        </tr>"; } 
                                        }else{ 
                                            echo "<tr><td colspan='11'>No records found</td></tr>"; 
                                        } ?>
						<tr>
							<td colspan="11" style="text-align:center">
							<?php  func_getPaging('report_profit.php?x&search_investor='.$search_investor); ?>
							</td>
						</tr>
						</tbody>
					</table>
					</div>
                         </form>
                    </div>
                </div>
			</div>
			
	<?php include('_footer.php'); ?>