<?php 

	include('_header.php'); 

	func_setReqVar();

?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card card-nav-tabs">
					<div class="card-header" data-background-color="purple">
						<div class="nav-tabs-navigation">
							<div class="nav-tabs-wrapper">
								<span class="nav-tabs-title">Booking</span>
								<ul class="nav nav-tabs" data-tabs="tabs">
									<li class="active">
										<a href="#schedule" data-toggle="tab">
											<i class="material-icons">schedule</i>
											Schedule
											<div class="ripple-container"></div>
										</a>
									</li>
									<li class="">
										<a href="#span" data-toggle="tab">
											<i class="material-icons">date_range</i>
											Span
											<div class="ripple-container"></div>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>

					<div class="card-content">
						<div class="tab-content">

							<!-- Booking Schedule -->
							<div class="tab-pane active" id="schedule">
								<form action="#" method="post">
									<div class="form-group">
										<select name="location" class="form-control">
											<option value='1'>Machang</option>
											<option value='2'>Kota Bahru</option>
											<option value='3'>Tanah Merah</option>
										</select>
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-success" name="btn_search">Search</button>
									</div>
									<div class="table-responsive">
									<table class="table">
										<thead class="text-primary">
											<th>Number</th>
											<th>Pick Up Date</th>
											<th>Pick Up Time</th>
											<th>Return Date</th>
											<th>Total</th>
										</thead>
										<tbody>
											<?php
					
					if(isset($btn_search)){
						
						func_setPage();
						func_setOffset();
						func_setLimit(10);
					
						if(isset($btn_search)){
						
							if($search_name!=""){
								$where=" AND name like '%".$search_name."%'";
							}
						}
                    
                        $location = $_POST['location'];
						$sql = "SELECT id, pickup_date, pickup_time, return_date, est_total 
						FROM booking_trans WHERE pickup_location = $location";
						
						//Combine vehicle  and booking_trans table 
						/*$sql = "SELECT id, vehicle.reg_no, vehicle.make, vehicle.model, vehicle.availibility, pickup_date, pickup_time, return_date, est_total 
						FROM booking_trans INNER JOIN ON vehicle_id = vehicle.id WHERE pickup_location = '$location'";*/
					

						db_select($sql);
						
						func_setTotalPage(db_rowcount());
						db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
						
						if(db_rowcount()>0){
							for($i=0;$i<db_rowcount();$i++){
								
								$status = "";
								
								if(func_getOffset()>=10){
									$no=func_getOffset()+1+$i;
								}else{
									$no=$i+1;
								}
								
								echo "<tr>
										<td>".$no."</a></td>
										<td>".db_get($i,1)."</td>
										<td>".db_get($i,2)."</td>
										<td>".db_get($i,3)."</td>
										<td>".db_get($i,4)."</td>
									</tr>";	
							}
						}else{
							echo "<tr><td colspan='10'><b>No Records Found!</b></td></tr>";
						}
					}
					?>
												<tr>
													<td colspan="5" style="text-align:center">
														<?php 
							func_getPaging('booking.php?x&btn_search=&location='.$location);
						?>
													</td>
												</tr>

										</tbody>
									</table>
								</div>
								</form>
							</div>
							<!-- End Booking Schedule -->

							<!-- Booking Span -->
							<div class="tab-pane" id="span">
									<table class="table table-responsive">
										<thead class="text-primary">
											<th>Number</th>
											<th>Span Duration</th>
											<th>Description</th>
										</thead>
										<tbody>

											<?php
											func_setPage();
											func_setOffset();
											func_setLimit(10);
										
											$sql = "SELECT id, day, description from booking_span where id is not NULL" .$where;
											db_select($sql);
											
											func_setTotalPage(db_rowcount());
											db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
											
											if(db_rowcount()>0){
												for($i=0;$i<db_rowcount();$i++){
													
													if(func_getOffset()>=10){
														$no=func_getOffset()+1+$i;
													}else{
														$no=$i+1;
													}
													
													echo "<tr>
															<td>".$no."</td>
															<td>".db_get($i,1)."</td>
															<td>".db_get($i,2)."</td>								
														</tr>";	
												}
											}else{
												echo "<tr><td colspan='6'>No records found</td></tr>";
											}

										?>

										</tbody>
									</table>	
							</div>
							<!-- End Booking Span -->

						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>


<!--   Core JS Files   -->
<script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>

<!--  Charts Plugin -->
<script src="assets/js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>

<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js"></script>