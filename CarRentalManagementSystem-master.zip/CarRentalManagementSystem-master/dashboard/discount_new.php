<?php
	include("_header.php");
	
	func_setReqVar();
	
	if(isset($btn_save)){
		func_setValid("Y");
        
        // func_isEmpty($code, "coupon code");
		// func_isEmpty($start_date, "start date");
		// func_isEmpty($end_date, "end date");
	
		if(func_isValid()){
			$sql="INSERT INTO 
			discount
			(
			code, 
			start_date, 
			end_date,  
			value_in,
			rate,
			cid, 
			cdate
			)
			VALUES
			(
			'".conv_text_to_dbtext3($code)."',
			'".conv_datetodbdate($start_date)."',
			'".conv_datetodbdate($end_date)."',
			'".$value_in."',
			".$rate.", 
			".$_SESSION['cid'].",
			CURRENT_TIMESTAMP
			)
			";
			//echo $sql;
			db_update($sql);
			
			vali_redirect("discount_coupon.php?btn_search=&search_start_date=".$search_start_date."&search_end_date=".$search_end_date."&page=".$page);
		}
	}
?>


    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="blue">
                            <h4 class="title">Add Discount Coupon</h4>
                        </div>
                        <div class="card-content">
                         <form>
						 <div class="form-group">
						 <label class="control-label">Coupon Code</label>
						 <input type="text" class="form-control" id="code" name="code" value="<?php echo $code;?>">
						</div>
                        <div class="form-group">
						 <label class="control-label">Start Date</label>
						 <input type="text" class="form-control" id="start_date" name="start_date" value="<?php echo $start_date;?>">
						</div>
						<div class="form-group">
							<label class="control-label">End Date</label>
							<input type="text" class="form-control" id="end_date" name="end_date" value="<?php echo $end_date;?>">
						</div>
						<div class="form-group">
							<label class="control-label">Value In</label>
							<div>
								<select name="value_in" class="form-control">
									<option value='P' <?php echo vali_iif('P'==$value_in,'Selected','');?>>Percentage</option>
									<option value='A' <?php echo vali_iif('A'==$value_in,'Selected','');?>>Amount</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label">Rate</label>
							<div>
								<input type="text" class="form-control" placeholder="Rate" name="rate" value="<?php echo $rate;?>">
							</div>
						</div>
						<div class="form-group text-center">
							<div>
								<button type="submit" class="btn btn-success" name="btn_save">Save</button>
								<button type="button" class="btn btn-info" onclick="location.href='discount_coupon.php?btn_search=&search_start_date=<?php echo $search_start_date; ?>&search_end_date=<?php echo $search_end_date; ?>&page=<?php echo $page;?>'" name="btn_cancel">Cancel</button>
							</div>
						</div>
                         </form>
                    </div>
                </div>
			</div>
			
	<?php include('_footer.php'); ?>

	<script>
        $(document).ready(function () {
            var date_input = $('input[name="start_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>
	<script>
        $(document).ready(function () {
            var date_input = $('input[name="end_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>