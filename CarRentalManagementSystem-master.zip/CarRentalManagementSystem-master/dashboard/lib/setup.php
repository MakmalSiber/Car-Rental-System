<?php 
	error_reporting(E_ALL ^ E_DEPRECATED ^ E_NOTICE);

	session_start();
	
	set_time_limit(100);
	
	include("phpmailer-lite/class.phpmailer-lite.php");
	include("LibDatabase.php");
	include("LibFunction.php");
	include("LibConvert.php");
	include("LibPaging.php");
	include("LibValidate.php");
	include("LibEmail.php");
	include("LibImage.php");
		
	define("DB_NAME", "884d828570389ce7791b8d8d1adf1be9");
	define("DB_HOST", "8668b8b68246a83cdddbea7f57f056df");
	define("DB_USERNAME", "908c9ff75d452e22f3de157a134e5cea");
	define("DB_PASSWORD", "f928f325094c37f8999a70217fec5e9a");
	
	vali_mustNoCache();
	
	db_connect(DB_NAME, DB_HOST,DB_USERNAME,DB_PASSWORD);
	
	//echo DOC_ROOT;
?>
