<div class="sidebar" data-color="red" data-image="assets/img/sidebar-5.jpg">
			<!--
		        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

		        Tip 2: you can also add an image using data-image tag
		    -->

			<div class="logo">
				<a href="#" class="simple-text">
					<?php echo $website_name; ?>
				</a>
			</div>
    
	    	<div class="sidebar-wrapper">
	            <ul class="nav">
                    <li>
                        <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                            <span>
                            <i class="material-icons">face</i>
                            <p><?php echo $name; ?>
                            <b class="caret"></b>
                            </p>
                            </span>
                        </a>
                        <div class="clearfix"></div>
                        <div class="collapse" id="collapseExample">
                            <ul class="nav">
                                <?php if($occupation == 'Admin'){ ?>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="cms.php"'>
                                        <p> CMS </p>
                                    </a>
                                </li>
                                <?php } elseif($occupation == 'Manager'){ ?>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="cms.php"'>
                                        <p> CMS </p>
                                    </a>
                                </li>
                                <?php } ?>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="settings.php"'>
                                        <p> Settings </p>
                                    </a>
                                </li>
                                <li>
                                    <a href="signout.php">
                                        <p> Log Out </p>
                                    </a>
                                </li>
                            </ul>
                        </div>
	                </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="dashboard.php"'>
	                        <i class="material-icons">dashboard</i>
	                        <p>Dashboard</p>
	                    </a>
	                </li>
	               
                      <!-- Super -->

                    <?php if ($occupation == "Admin") { ?>
                     <li>
	                    <a href="#" onClick='document.getElementById("frame").src="booking.php"'>
	                        <i class="material-icons">date_range</i>
	                        <p>Booking Schedule</p>
	                    </a>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="counter_reservation.php"'>
	                        <i class="material-icons">store</i>
	                        <p>Counter Reservation</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="discount_coupon.php"'>
	                        <i class="material-icons">local_offer</i>
	                        <p>Discount Coupon</p>
	                    </a>
	                </li>
					<li>
                        <a data-toggle="collapse" href="#fleet">
                            <i class="material-icons">assignment</i>
                            <p> Fleet Management 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="fleet">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_accident.php"'>
                                        <span> Accident </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_cost.php"'>
                                        <span> Cost </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_gps.php"'>
                                        <span> GPS </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_insurance.php"'>
                                        <span> Insurance </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_maintenance.php"'>
                                        <span> Maintenance </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_summon.php"'>
                                        <span> Summon </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#manage">
                            <i class="material-icons">edit</i>
                            <p> Manage 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="manage">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_agent.php"'>
                                        <span> Agent </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_classes.php"'>
                                        <span> Class </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_customer.php"'>
                                        <span> Customer </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_job.php"'>
                                        <span>Job List</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_location.php"'>
                                        <span> Location </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_user.php"'>
                                        <span> User </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_vehicle.php"'>
                                        <span> Vehicle </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#rental">
                            <i class="material-icons">subject</i>
                            <p> Rental 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="rental">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_options.php"'>
                                        <span> Options </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_seasons.php"'>
                                        <span> Seasons </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#report">
                            <i class="material-icons">assessment</i>
                            <p> Report 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="report">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="report_car_status.php"'>
                                        <span> Car Status </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="report_daily_pay.php"'>
                                        <span> Daily Pay </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="report_profit.php"'>
                                        <span> Profit </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="report_monthly.php"'>
                                        <span> Monthly </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="reservation_list.php"'>
	                        <i class="material-icons text-gray">content_paste</i>
	                        <p>Reservation List</p>
	                    </a>
	                </li>
                </ul>

                 <!-- End of Super -->
                <!-- Manager -->

                    <?php 
                } elseif ($occupation == "Manager") { ?>
                     <li>
	                    <a href="#" onClick='document.getElementById("frame").src="booking.php"'>
	                        <i class="material-icons">date_range</i>
	                        <p>Booking Schedule</p>
	                    </a>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="counter_reservation.php"'>
	                        <i class="material-icons">store</i>
	                        <p>Counter Reservation</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="discount_coupon.php"'>
	                        <i class="material-icons">local_offer</i>
	                        <p>Discount Coupon</p>
	                    </a>
	                </li>
					<li>
                        <a data-toggle="collapse" href="#fleet">
                            <i class="material-icons">assignment</i>
                            <p> Fleet Management 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="fleet">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_accident.php"'>
                                        <span> Accident </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_cost.php"'>
                                        <span> Cost </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_gps.php"'>
                                        <span> GPS </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_insurance.php"'>
                                        <span> Insurance </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_maintenance.php"'>
                                        <span> Maintenance </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_summon.php"'>
                                        <span> Summon </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#manage">
                            <i class="material-icons">edit</i>
                            <p> Manage 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="manage">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_agent.php"'>
                                        <span> Agent </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_classes.php"'>
                                        <span> Class </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_customer.php"'>
                                        <span> Customer </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_job.php"'>
                                        <span>Job List</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_location.php"'>
                                        <span> Location </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_user.php"'>
                                        <span> User </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_vehicle.php"'>
                                        <span> Vehicle </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#rental">
                            <i class="material-icons">subject</i>
                            <p> Rental 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="rental">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_options.php"'>
                                        <span> Options </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_seasons.php"'>
                                        <span> Seasons </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="reservation_list.php"'>
	                        <i class="material-icons text-gray">content_paste</i>
	                        <p>Reservation List</p>
	                    </a>
	                </li>
                </ul>

                 <!-- End of Manager -->
                 <!-- Branch Manager -->
                <?php 
            } elseif ($occupation == "Branch Manager") { ?>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="booking.php"'>
	                        <i class="material-icons">date_range</i>
	                        <p>Booking Schedule</p>
	                    </a>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="counter_reservation.php"'>
	                        <i class="material-icons">store</i>
	                        <p>Counter Reservation</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="discount_coupon.php"'>
	                        <i class="material-icons">local_offer</i>
	                        <p>Discount Coupon</p>
	                    </a>
	                </li>
					<li>
                        <a data-toggle="collapse" href="#fleet">
                            <i class="material-icons">assignment</i>
                            <p> Fleet Management 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="fleet">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_accident.php"'>
                                        <span> Accident </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_cost.php"'>
                                        <span> Cost </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_gps.php"'>
                                        <span> GPS </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_insurance.php"'>
                                        <span> Insurance </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_maintenance.php"'>
                                        <span> Maintenance </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_summon.php"'>
                                        <span> Summon </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#manage">
                            <i class="material-icons">edit</i>
                            <p> Manage 
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="manage">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_agent.php"'>
                                        <span> Agent </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_classes.php"'>
                                        <span> Class </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_customer.php"'>
                                        <span> Customer </span>
                                    </a>
                                </li>
                                  <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_job.php"'>
                                        <span>Job List</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_location.php"'>
                                        <span> Location </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_user.php"'>
                                        <span> User </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="manage_vehicle.php"'>
                                        <span> Vehicle </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#rental">
                            <i class="material-icons">subject</i>
                            <p> Rental 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="rental">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_options.php"'>
                                        <span> Options </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_seasons.php"'>
                                        <span> Seasons </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="reservation_list.php"'>
	                        <i class="material-icons text-gray">content_paste</i>
	                        <p>Reservation List</p>
	                    </a>
	                </li>
                </ul>

                 <!-- End of Branch Manager -->
                <!-- Sales -->
                
                <?php 
            } elseif ($occupation == "Sales") { ?>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="booking.php"'>
	                        <i class="material-icons">date_range</i>
	                        <p>Booking Schedule</p>
	                    </a>
                    </li>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="counter_reservation.php"'>
	                        <i class="material-icons">store</i>
	                        <p>Counter Reservation</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="discount_coupon.php"'>
	                        <i class="material-icons">local_offer</i>
	                        <p>Discount Coupon</p>
	                    </a>
	                </li>
					<li>
                        <a data-toggle="collapse" href="#rental">
                            <i class="material-icons">subject</i>
                            <p> Rental 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="rental">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_seasons.php"'>
                                        <span> Seasons </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="reservation_list.php"'>
	                        <i class="material-icons text-gray">content_paste</i>
	                        <p>Reservation List</p>
	                    </a>
	                </li>
                </ul>

                <!-- End of Sales -->
                <!-- Operation -->
    
                <?php 
            } elseif ($occupation == "Operation") { ?>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="booking.php"'>
	                        <i class="material-icons">date_range</i>
	                        <p>Booking Schedule</p>
	                    </a>
                    </li>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="counter_reservation.php"'>
	                        <i class="material-icons">store</i>
	                        <p>Counter Reservation</p>
	                    </a>
	                </li>
					<li>
                        <a data-toggle="collapse" href="#fleet">
                            <i class="material-icons">assignment</i>
                            <p> Fleet Management 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="fleet">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_accident.php"'>
                                        <span> Accident </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_cost.php"'>
                                        <span> Cost </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_maintenance.php"'>
                                        <span> Maintenance </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="reservation_list.php"'>
	                        <i class="material-icons text-gray">content_paste</i>
	                        <p>Reservation List</p>
	                    </a>
	                </li>
                </ul>

                <!-- End of Operation -->
                <!-- Sales / Operation -->
                <?php 
            } elseif ($occupation == "Sale Operation") { ?>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="booking.php"'>
	                        <i class="material-icons">date_range</i>
	                        <p>Booking Schedule</p>
	                    </a>
                    </li>
                    <li>
	                    <a href="#" onClick='document.getElementById("frame").src="counter_reservation.php"'>
	                        <i class="material-icons">store</i>
	                        <p>Counter Reservation</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="discount_coupon.php"'>
	                        <i class="material-icons">local_offer</i>
	                        <p>Discount Coupon</p>
	                    </a>
	                </li>
					<li>
                        <a data-toggle="collapse" href="#fleet">
                            <i class="material-icons">assignment</i>
                            <p> Fleet Management 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="fleet">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_accident.php"'>
                                        <span> Accident </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_cost.php"'>
                                        <span> Cost </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="fleet_management_maintenance.php"'>
                                        <span> Maintenance </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
					<li>
                        <a data-toggle="collapse" href="#rental">
                            <i class="material-icons">subject</i>
                            <p> Rental 
                            <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="rental">
                            <ul class="nav">
                                <li>
                                    <a href="#" onClick='document.getElementById("frame").src="rental_seasons.php"'>
                                        <span> Seasons </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
	                <li>
	                    <a href="#" onClick='document.getElementById("frame").src="reservation_list.php"'>
	                        <i class="material-icons text-gray">content_paste</i>
	                        <p>Reservation List</p>
	                    </a>
	                </li>
                </ul>
                <?php 
            } ?>

                <!-- End of Sale / Operation -->
            
                <div class="text-center">
                    <small>Ver. 1.2.0</small>
                </div>
            </div>
		</div>

        <div class="main-panel">
            <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"> Car Rental Management System </a>
                    </div>
                </div>
            </nav>