	<!--   Core JS Files   -->
	<script language="JavaScript" type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <script language="JavaScript" type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script language="JavaScript" type="text/javascript" src="assets/js/material.min.js"></script>

    <!-- jQuery UI -->
    <script language="JavaScript" type="text/javascript" src="assets/js/jquery-ui.js"></script>
   
    <!-- Ajax -->
    <script language="JavaScript" type="text/javascript" src="assets/js/ajax.js"></script>

    <!--  Notifications Plugin    -->
    <script language="JavaScript" type="text/javascript" src="assets/js/bootstrap-notify.js"></script>

    <!-- Material Dashboard javascript methods -->
    <script language="JavaScript" type="text/javascript" src="assets/js/material-dashboard.js"></script>

    <!-- Datepicker -->
    <script language="JavaScript" type="text/javascript" src="assets/js/bootstrap-datepicker.js"></script>

    <!-- Maps  -->
    <sript language="JavaScript" type="text/javascript" src="assets/js/maps.js"></sript>

    <!-- Demo Maps -->
    <sript language="JavaScript" type="text/javascript" src="assets/js/demo.js"></sript>