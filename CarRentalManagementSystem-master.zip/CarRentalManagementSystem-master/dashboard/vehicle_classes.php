<?php
include("_header.php");

func_setReqVar();

if (isset($btn_clear)) {
	vali_redirect('counter_reservation.php');
}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Vehicle Classes</h4>
                </div>
            <div class="card-content">
			<form>
			<div class="form-group">
				<label class="control-label">Classes</label>
					<input type="text" class="form-control" name="search_classes" value="<?php echo $search_classes;?>">
			</div>

			<div class="form-group">
				<div class="text-center">
					<button type="submit" class="btn btn-success" name="btn_search">Search</button>
				</div>
			</div>

			<div class="table-responsive">
			<table class="table">
				<thead>
					<tr>
					<th>No</th>
					<th>Class</th>
					<th>Description</th>
					<th>Status</th>
					<th>Action</th>
					</tr>
				</thead>
				<tbody>
				<?php
					func_setPage();
					func_setOffset();
					func_setLimit(10);
				
					if(isset($btn_search)){
					
						if($search_classes!=""){
							$where=" AND class like '%".$search_classes."%'";
						}
					}
				
					$sql = "SELECT id, desc_1, desc_2, desc_3, desc_4, class_name, case status when 'A' then 'Active' when 'I' then 'Inactive' end as status from class where id is not NULL" .$where;
					db_select($sql);
					
					func_setTotalPage(db_rowcount());
					db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
					
					if(db_rowcount()>0){
						for($i=0;$i<db_rowcount();$i++){
							
							if(func_getOffset()>=10){
								$no=func_getOffset()+1+$i;
							}else{
								$no=$i+1;
							}
							
							echo "<tr>
									<td>".$no."</td>
									<td>".db_get($i,5)."</td>
									<td>".db_get($i,1)." ".db_get($i,2)." ".db_get($i,3)." ".db_get($i,4)."</td>
									<td>".db_get($i,6)."</td>
									<td><a href='vehicle_classes_edit.php?id=".db_get($i,0)."&search_classes=".$search_classes."&page=".$page."'><i class='material-icons'>mode_edit</i></a></td>
								</tr>";	
						}
					}else{
						echo "<tr><td colspan='5'>No records found</td></tr>";
					}
				?>
				<tr>
					<td colspan="5" align="center">
						<div class="form-group">
								<button type="button" class="btn btn-success" name="btn_save" onclick="location.href='vehicle_classes_new.php?btn_search=&search_classes=<?php echo $search_classes;?>&page=<?php echo $page;?>'">Add New</button>
						</div>
					</td>
				</tr>
				<tr>
					<td colspan="5" style="text-align:center">
					<?php 
						func_getPaging('vehicle_classes.php?x&search_classes='.$search_classes);
					?>
					</td>
				</tr>
				</tbody>
			</table>
			</div>
		</div>
	</div>
	</form>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php'); ?>

