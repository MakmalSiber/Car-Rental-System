<?php
include('_header.php');

func_setReqVar();

if (isset($btn_save)) {
    func_setValid("Y");
    
    func_isEmpty($vehicle_id, "vehicle_id");
    func_isEmpty($description, "description");
    func_isEmpty($status, "status");
    func_isNum($milleage, "milleage");
    if (func_isValid()) {if ($milleage == "") {$milleage = 0;}
        
    $sql = "UPDATE fleet_maintenance SET
			vehicle_id = '".$vehicle_id."',
			description = '".conv_text_to_dbtext3($description)."',
            milleage = '".$milleage."',
            cost = '".$cost."',
			date = '".conv_datetodbdate($date)."',
			status = '".$status."',
			mid = ".$_SESSION['cid'].",
			mdate = CURRENT_TIMESTAMP
			WHERE id =".$_GET['id'];
            db_update($sql);
        
    vali_redirect("fleet_management_maintenance.php?btn_search=Search&page=" . $page . "&search_vehicle=" . $search_vehicle);}

    } else if (isset($btn_delete)) {
        $sql = "DELETE from fleet_maintenance WHERE id = " . $_GET['id'];
        db_update($sql);
        vali_redirect("fleet_management_maintenance.php?btn_search=Search&page=" . $page . "&search_vehicle=" . $search_vehicle);
    } else { 
        $sql = "SELECT vehicle_id, description, milleage, cost, DATE_FORMAT(date, '%d/%m/%Y') as date, status
		FROM fleet_maintenance
		WHERE id=" . $_GET['id'];
        db_select($sql);
        if (db_rowcount() > 0) {
            func_setSelectVar();
            }
    }
    
    ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="red">
					<h4 class="title">Maintenance</h4>
                </div>
            <div class="card-content">
            <form method="POST">

                        <span style="color:red"><?php echo func_getErrMsg(); ?></span>

                            <div class="form-group label-floating">
                                <label class="control-label">Vehicle</label>
                                    <select class="form-control" name="vehicle_id" <?php echo $disabled; ?>>
                                        <?php $value = "";
                                        $sql = "SELECT id, reg_no, model, year from vehicle";
                                        db_select($sql);if (db_rowcount() > 0) {for ($j = 0; $j < db_rowcount(); $j++) {$value = $value . "<option value='" . db_get($j, 0) . "' " . vali_iif(db_get($j, 0) == $vehicle_id, 'Selected', '') . ">
                                                                                                                                " . db_get($j, 1) . " : " . db_get($j, 2) . " (" . db_get($j, 3) . ")</option>";}}
                                        echo $value;?>
                                    </select>
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Description</label>
                                <textarea type="text" class="form-control" name="description"><?php echo $description; ?></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Cost</label>
                                        <input type="text" class="form-control" name="cost" value="<?php echo $cost; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group label-floating">
                                    <label class="control-label">Milleage</label>
                                        <input type="text" class="form-control" name="milleage" value="<?php echo $milleage; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Date</label>
                                        <input type="text" class="form-control" id="date" name="date" value="<?php echo $date; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Status</label>
                                    <select name="status" class="form-control">
                                        <option value='O' <?php echo vali_iif('O' == $status, 'Selected', ''); ?>>Open</option>
                                        <option value='C' <?php echo vali_iif('C' == $status, 'Selected', ''); ?>>Close</option>
                                    </select>
                            </div>
                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                    <button type="submit" class="btn btn-danger" name="btn_delete">Delete</button>
                                    <button type="button" class="btn btn-warning" onclick="location.href='fleet_management_maintenance.php?btn_search=&search_vehicle=<?php echo $search_vehicle; ?>'">Cancel</button>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
    </div>

    <?php include '_footer.php';?>

        <script>
            $(document).ready(function () {
                var date_input = $('input[name="date"]');
                var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
                date_input.datepicker({
                    format: 'dd/mm/yyyy',
                    container: container,
                    todayHighlight: true,
                    autoclose: true,
                })
            })
        </script>