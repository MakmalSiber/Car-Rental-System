<?php

    include("_header.php"); 
    func_setReqVar(); 
    if (isset($btn_clear)) { vali_redirect('report_weekly.php'); } 
?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="purple">
                            <h4 class="title">Monthly</h4>
                        </div>
                        <div class="card-content">
                         <form>

                        <div class="row">
                            <div class="form-group">
                                <select class="form-control" name="search_month" <?php echo $disabled;?>>
                                   <option>Month</option>
                                   <option value="01">January</option>
                                   <option value="02">February</option>
                                   <option value="03">March</option>
                                   <option value="04">April</option>
                                   <option value="05">May</option>
                                   <option value="06">June</option>
                                   <option value="07">July</option>
                                   <option value="08">August</option>
                                   <option value="09">September</option>
                                   <option value="10">October</option>
                                   <option value="11">November</option>
                                   <option value="12">December</option>
                                </select>
                            </div>
						</div>   

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-success" name="btn_search">Search</button>
							<a href="report_weekly.php" class="btn btn-warning">Clear</a>
						</div>
						<div class="table-responsive">
                        <table class="table">
                        <thead class="text-primary">
											<th>No.</th>
											<th>Investor</th>
											<th>Car Details</th>
                                            <th>
                                            <?php 
                                                if($search_month != ''){
                                                    echo $search_month;
                                                } else {
                                                    echo "Month";
                                                }
                                            ?>
                                            </th>
											<th>Total</th>
										</thead>
										<tbody>
                                        <?php
                            func_setPage(); 
                            func_setOffset(); 
                            func_setLimit(10);
                            if(isset($btn_search)){ 
                                if($search_month!=""){ 
                                    $where=" AND MONTH(return_date) = '".$search_month."'"; 
                                } 
                            }
                            $sql = "SELECT 
                            vehicle.id,
                            investor_name,
                            reg_no,
                            make,
                            model,
                            sub_total,
                            SUM(sub_total) AS total_sum
                            FROM vehicle 
                            LEFT JOIN investor ON vehicle.id = investor.vehicle_id 
                            LEFT JOIN booking_trans ON vehicle.id = booking_trans.vehicle_id 
                            WHERE MONTH(return_date) = $search_month
                            GROUP BY vehicle.id " .$where;
                            db_select($sql); 
                            
                            func_setTotalPage(db_rowcount()); 
                            db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset()); 
                            if(db_rowcount()>0) { 
                                for($i=0;$i<db_rowcount();$i++){ 
                                    if(func_getOffset()>=10){ 
                                        $no=func_getOffset()+1+$i; 
                                    }else{ 
                                        $no=$i+1; 
                                    } 
                                    $totalcost = number_format(db_get($i,2) + db_get($i,7) + db_get($i,8),2);
                                    $totalprofit = number_format(db_get($i,9) - $totalcost,2);
                                    $investotprofit = number_format(($totalprofit*40)/100,2);
                                    $companyprotfit = number_format(($totalprofit*60)/100,2);

                                    echo "<tr>
										<td>".$no."</td>
										<td>".db_get($i,1)."</td>
										<td>".db_get($i,3).' '.db_get($i,4).' ('.db_get($i,2).')'."</td>
										<td>RM ".db_get($i,5)."</td>
										<td>RM ".db_get($i,6)."</td>
                                        </tr>"; } 
                                        }else{ 
                                            echo "<tr><td colspan='11'>No records found</td></tr>"; 
                                        } ?>
						<tr>
							<td colspan="11" style="text-align:center">
							<?php  func_getPaging('report_weekly.php?x&search_month='.$search_month); ?>
							</td>
						</tr>
						</tbody>
					</table>
					</div>
                         </form>
                    </div>
                </div>
			</div>
			
	<?php include('_footer.php'); ?>