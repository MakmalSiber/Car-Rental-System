<?php
	include("_header.php");
	
	func_setReqVar();

	if(isset($btn_save)){
		func_setValid("Y");
		func_isEmpty($vehicle_id, "vehicle_id");
		func_isEmpty($owner_name, "owner name");
		func_isEmpty($nric_no, "nric no");
		func_isEmpty($serial_no, "serial no");
		func_isEmpty($phone_no, "phone no");
		func_isEmpty($credit_balance, "credit balance");
		func_isEmpty($expiry_date, "expiry date");
		func_isEmpty($sim_expiry_date, "sim expiry date");
		func_isNum($credit_balance, "credit balance");
		
		if(func_isValid()){
			
			$sql = "UPDATE gps SET 
					vehicle_id = '".$vehicle_id."',
					owner_name = '".conv_text_to_dbtext3($owner_name)."',
					nric_no = '".conv_text_to_dbtext3($nric_no)."',
					serial_no = '".conv_text_to_dbtext3($serial_no)."',
					phone_no = '".$phone_no."', 
					credit_balance = ".$credit_balance.",
					expiry_date = '".conv_datetodbdate($expiry_date)."',
					sim_expiry_date = '".conv_datetodbdate($sim_expiry_date)."',
					mid = ".$_SESSION['cid'].",
					mdate = CURRENT_TIMESTAMP
					WHERE id = ".$_GET['id'];
			//echo $sql;
			db_update($sql);
			
			vali_redirect("fleet_management_gps.php?btn_search=Search&page=".$page."&search_vehicle=".$search_vehicle);
		}
	}else if(isset($btn_delete)){
		
		$sql = "DELETE from gps WHERE id = ".$_GET['id'];
		db_update($sql);
		
		vali_redirect("fleet_management_gps.php?btn_search=Search&page=".$page."&search_vehicle=".$search_vehicle);
		
	}else{
		$sql = "SELECT vehicle_id, 
		owner_name, 
		nric_no, 
		serial_no, 
		phone_no, 
		credit_balance, 
		DATE_FORMAT(expiry_date, '%d/%m/%Y') as expiry_date, 
		DATE_FORMAT(sim_expiry_date, '%d/%m/%Y') as sim_expiry_date 
		FROM gps 
		WHERE id=".$_GET['id'];
		//echo $sql;
		db_select($sql);
		if(db_rowcount()>0){
			func_setSelectVar();
		}
	}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="red">
					<h4 class="title">GPS</h4>
                </div>
            <div class="card-content">
            <form method="POST">
                <span style="color:red"><?php echo func_getErrMsg();?></span>
                
                <div class="row">
                    <div class="col-md-4"><div class="form-group label-floating">
							<label class="control-label">Vehicle</label>
								<select class="form-control" name="vehicle_id" <?php echo $disabled;?>>
									<?php 
									
									$value = "";
									
									$sql = "SELECT id, reg_no, model, year from vehicle";
									db_select($sql);
									if(db_rowcount()>0){
										for($j=0;$j<db_rowcount();$j++){
											$value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$vehicle_id,'Selected','').">
											".db_get($j,1)." : ".db_get($j,2). " (" .db_get($j,3). ")</option>";
										}
									}
									
									echo $value;
									
									?>
								</select>
						</div></div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Owner Name</label>
								<input type="text" class="form-control" name="owner_name" value="<?php echo $owner_name;?>">
						</div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">NRIC No</label>
								<input type="text" class="form-control" name="nric_no" value="<?php echo $nric_no;?>">
						</div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Serial No</label>
								<input type="text" class="form-control" name="serial_no" value="<?php echo $serial_no;?>">
						</div>
                    </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Phone No</label>
								<input type="text" class="form-control" name="phone_no" value="<?php echo $phone_no;?>">
						</div>
                    </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Credit Balance</label>
								<input type="text" class="form-control" name="credit_balance" value="<?php echo $credit_balance;?>">
						</div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                    <div class="form-group label-floating">
							<label class="control-label">Expiry Date</label>
							<input class="form-control" type="text" id="expiry_date" name="expiry_date" value="<?php echo $expiry_date;?>">
						</div>
                    </div>
                    <div class="col-md-6">
					<div class="form-group label-floating">
							<label class="control-label">Sim Expiry Date</label>
							<input class="form-control" type="text" id="sim_expiry_date" name="sim_expiry_date" value="<?php echo $sim_expiry_date;?>">
						</div>
					</div>
                </div>
						
						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save</button>
								<button type="submit" class="btn btn-danger" name="btn_delete">Delete</button>
								<button type="button" class="btn btn-warning" onclick="location.href='fleet_management_gps.php?btn_search=&search_vehicle=<?php echo $search_vehicle;?>'">Cancel</button>
							</div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

 <script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!-- Date Picker -->
    <script src="assets/js/bootstrap-datepicker.js"></script>


    <script>
        $(document).ready(function () {
            var date_input = $('input[name="expiry_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>

	    <script>
        $(document).ready(function () {
            var date_input = $('input[name="sim_expiry_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>



