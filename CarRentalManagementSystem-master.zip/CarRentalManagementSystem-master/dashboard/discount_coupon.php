<?php
include("_header.php");

func_setReqVar();

if (isset($btn_clear)) {
	vali_redirect('counter_reservation.php');
}
?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="blue">
                            <h4 class="title">Discount Coupon</h4>
                        </div>
                        <div class="card-content">
                         <form>
                        <div class="row">
							<div class="col-md-6">
							<div class="form-group">
						 <label class="control-label">Start Date</label>
						 <input type="text" class="form-control" id="search_start_date" name="search_start_date" value="<?php echo $search_start_date;?>">
						</div>    
							</div>
							<div class="col-md-6">
							<div class="form-group">
							<label class="control-label">End Date</label>
							<input type="text" class="form-control" id="search_end_date" name="search_end_date" value="<?php echo $search_end_date;?>">
						</div>   
							</div>
						</div>        
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-success" name="btn_search">Search</button>
						</div>
						<div class="table-responsive">
                        <table class="table">
                        <thead class="text-primary">
											<th>Number</th>
											<th>Code</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Value</th>
											<th>Rate</th>
											<th>Action</th>
										</thead>
										<tbody>
                                        <?php
							func_setPage();
							func_setOffset();
							func_setLimit(10);
						
							if(isset($btn_search)){
							
								if($search_start_date != "" AND $search_end_date != ""){
									$where=" AND start_date = '$search_start_date' AND end_date = '$search_end_date'";
								}
							}
						
							$sql = "SELECT id, 
									code, 
									DATE_FORMAT(start_date, '%d/%m/%Y') as start_date, 
									DATE_FORMAT(end_date, '%d/%m/%Y') as end_date, 
									value_in, 
									rate, 
									CASE value_in WHEN 'A' Then 'Amount' WHEN 'P' Then 'Percentage' END AS value_in 
									FROM discount 
									WHERE id IS NOT NULL" .$where;
							db_select($sql);
							//echo $sql;
							func_setTotalPage(db_rowcount());
							db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
							
							if(db_rowcount()>0){
								for($i=0;$i<db_rowcount();$i++){
									
									if(func_getOffset()>=10){
										$no=func_getOffset()+1+$i;
									}else{
										$no=$i+1;
									}
									
									echo "<tr>
											<td>".$no."</td>
											<td>".db_get($i,1)."</td>
											<td>".db_get($i,2)."</td>
											<td>".db_get($i,3)."</td>
											<td>".db_get($i,6)."</td>
											<td>".db_get($i,5)."</td>
											<td><a href='discount_edit.php?id=".db_get($i,0)."&search_start_date=".$search_start_date."&search_end_date=".$search_end_date."'><i class='material-icons'>mode_edit</i></a></td>
										</tr>";	
								}
							}else{
								echo "<tr><td colspan='7'>No records found</td></tr>";
							}
						?>
						<tr>
							<td colspan="7" align="center">
								<div class="form-group">
										<button type="button" class="btn btn-primary" name="btn_save" onclick="location.href='discount_new.php?btn_search=&search_start_date=<?php echo $search_start_date;?>&search_end_date=<?php echo $search_end_date;?>&page=<?php echo $page;?>'">Add New</button>
								</div>
							</td>
						</tr>
						<tr>
							<td colspan="7" style="text-align:center">
							<?php 
								func_getPaging('discount_coupon.php?x&search_start_date='.$search_start_date.'&search_end_date='.$search_end_date);
							?>
							</td>
						</tr>
						</tbody>
					</table>
					</div>
                         </form>
                    </div>
                </div>
			</div>
			
	<?php include('_footer.php'); ?>

	
	<script>
        $(document).ready(function () {
            var date_input = $('input[name="search_start_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy/mm/dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>
	<script>
        $(document).ready(function () {
            var date_input = $('input[name="search_end_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy/mm/dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>