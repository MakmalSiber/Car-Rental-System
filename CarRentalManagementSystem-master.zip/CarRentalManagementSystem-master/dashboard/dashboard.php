<?php
 include('_header.php'); func_setReqVar(); ?>

<style>
    .title{
        font-weight: bold;
        color: #EB4845;
    }
</style>

<body>

<div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header" data-background-color="blue">
                                <h4 class="title">News</h4>
                                </div>
                            <div class="card-content">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="material-icons">trending_up</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Current Sales</p>
                                    <h3 class="title"></h3>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">more_horiz</i>
                                        <a href="#">Full Report</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="orange">
                                    <i class="material-icons">directions_car</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Car on Rent</p>
                                    <h3 class="title">
                                    <?php
                                    $sql = "SELECT * FROM booking_trans WHERE pickup_date = CURRENT_DATE"; db_select($sql); if (db_rowcount() > 0) { func_setSelectVar(); } echo db_rowcount();?>
                                    </h3>
                                    <div class="table-responsive">
                                    <table class="table">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Name</th>
                                            <th>Plate No.</th>
                                            <th>Pickup</th>
                                            <th>Return</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $sql = "SELECT
                                            reg_no,
                                            DATE_FORMAT(pickup_date, '%d/%m/%Y') as pickup_date,
                                            DATE_FORMAT(pickup_time, '%H:%i:%s') as pickup_time,
                                            DATE_FORMAT(return_date, '%d/%m/%Y') as return_date,
                                            DATE_FORMAT(return_time, '%H:%i:%s') as return_time,
                                            booking_trans.id,
                                            concat(firstname,' ' ,lastname) as name,
                                            nric_no
                                            FROM vehicle
                                            LEFT JOIN booking_trans ON vehicle.id = vehicle_id
                                            LEFT JOIN class ON class.id = class_id
                                            LEFT JOIN customer ON customer_id = customer.id
                                            WHERE pickup_date = CURRENT_DATE"; db_select($sql); if (db_rowcount() > 0) { for ($i = 0; $i < db_rowcount(); $i++) { $status = ""; if (func_getOffset() >= 10) { $no = func_getOffset() + 1 + $i; } else { $no = $i + 1; } echo "<tr>
                                                    <td>" . $no . "</td>
                                                    <td>" . db_get($i, 6) . "</td>
                                                    <td>" . db_get($i, 0) . "</td>
                                                    <td>" . db_get($i, 1) . " / " . db_get($i, 2) . "</td>
                                                    <td>" . db_get($i, 3) . " / " . db_get($i, 4) . "</td>
                                                </tr>"; } } ?>
                                </tbody>
                                </table>
                                </div>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">add</i>
                                        <a href="counter_reservation.php">Rent</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                    <i class="material-icons">assignment</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Job List</p>
                                    <h3 class="title">
                                    <?php
                                     $sql = "SELECT 
                                     job.id, 
                                     user_id, 
                                     job_title, 
                                     job_desc, 
                                     assign_by, 
                                     completed_by,
                                     username,
                                     due_date,
                                     DATE_FORMAT(date, '%d/%m/%Y') AS dates
                                     FROM job 
                                     LEFT JOIN user ON user_id = user.id
                                     WHERE job.id IS NOT NULL" .$where; db_select($sql); echo db_rowcount(); ?>
                                    </h3>
                                    <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                            <th>No</th>
                                            <th>Assigned to</th>
                                            <th>Title</th>
                                            <th>Desc</th>
                                            <th>Completed By</th>
                                            <th>Assign By</th>
                                            <th>Created</th>
                                            <th>Due Date</th>
                                            <th>Accept Job</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(db_rowcount()>0){ for($i=0;$i<db_rowcount();$i++){ if(func_getOffset()>=10){ $no=func_getOffset()+1+$i; }else{ $no=$i+1; } echo "<tr>
                                                            <td>".$no."</td>
                                                            <td>".db_get($i,6)."</td>
                                                            <td>".db_get($i,2)."</td>
                                                            <td>".db_get($i,3)."</td>
                                                            <td>".db_get($i,5)."</td>
                                                            <td>".db_get($i,4)."</td>
                                                            <td>".db_get($i,8)."</td>
                                                            <td>".db_get($i,7)."</td>";  
                                                    if(db_get($i,5) == '') {
                                                        echo "<td><a href='manage_job_quest.php?id=".db_get($i, 0)."'><i class='material-icons'>pageview</i></td>";
                                                    } else {
                                                        echo "<td><i class='material-icons' disabled>pageview</i></td>";
                                                    }   
                                                }
                                                    } ?>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">add</i>
                                        <a href="manage_job.php">Add Job</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="purple">
                                    <i class="material-icons">description</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Insurans & Roadtax</p>
                                    <h3 class="title">
                                    <?php
 $sql = "SELECT
                                      fleet_insurance.id,
                                      reg_no,
                                      model,
                                      year,
                                      date_format(renewal_date,'%d/%m/%Y'),
                                      amount,
                                      provider
                                      FROM fleet_insurance
                                      LEFT JOIN vehicle ON vehicle.id = vehicle_id
                                      WHERE fleet_insurance.id is not NULL " . $where; db_select($sql); echo db_rowcount();?>
                                    </h3>
                                    <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                            <th>No</th>
                                            <th>Vehicle</th>
                                            <th>Renewal Date</th>
                                            <th>Amount (MYR)</th>
                                            <th>Provider</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
 if (db_rowcount() > 0) { for ($i = 0; $i < db_rowcount(); $i++) { if (func_getOffset() >= 10) { $no = func_getOffset() + 1 + $i; } else { $no = $i + 1; } echo "<tr>
                                                            <td>" . $no . "</td>
                                                            <td>" . db_get($i, 1) . " : " . db_get($i, 2) . " (" . db_get($i, 3) . ")</td>
                                                            <td>" . db_get($i, 4) . "</td>
                                                            <td>" . db_get($i, 5) . "</td>
                                                            <td>" . db_get($i, 6) . "</td>
                                                        </tr>"; } } ?>
                                        </tbody>
                                    </table>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">more_horiz</i>
                                        <a href="#">Full Detail</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                     <div class="row">
                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="blue">
                                    <i class="material-icons">my_location</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">GPS</p>
                                    <h3 class="title">
                                    <?php
 $sql = "SELECT
                                         gps.id,
                                         reg_no,
                                         model,
                                         year,
                                         date_format(expiry_date,'%d/%m/%Y'),
                                         date_format(sim_expiry_date,'%d/%m/%Y'),
                                         credit_balance,
                                         owner_name,
                                         nric_no
                                         FROM gps
                                         LEFT JOIN vehicle ON vehicle.id = vehicle_id
                                         WHERE gps.id is not NULL"; db_select($sql); echo db_rowcount(); ?>
                                    </h3>
                                    <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Vehicle</th>
                                                <th>NRIC No</th>
                                                <th>Expiry Date</th>
                                                <th>Sim Card Expiry Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if (db_rowcount() > 0) { for ($i = 0; $i < db_rowcount(); $i++) { if (func_getOffset() >= 10) { $no = func_getOffset() + 1 + $i; } else { $no = $i + 1; } echo "<tr>
                                                            <td>" . $no . "</td>
                                                            <td>" . db_get($i, 1) . "</td>
                                                            <td>" . db_get($i, 8) . "</td>
                                                            <td>" . db_get($i, 4) . "</td>
                                                            <td>" . db_get($i, 5) . "</td>
                                                        </tr>"; } } ?>
                                        </tbody>
                                    </table>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">more_horiz</i>
                                        <a href="fleet_management_gps.php">Full Detail</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="material-icons">mood</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Top Perfomance</p>
                                    <h3 class="title">
                                    <?php
                                     $sql = "SELECT 
                                     job.id, 
                                     user_id, 
                                     username,
                                     SUM(point),
                                     branch
                                     FROM job 
                                     LEFT JOIN user ON user_id = user.id
                                     WHERE job.id IS NOT NULL
                                     GROUP BY user.id
                                     ORDER BY SUM(point) DESC" .$where; db_select($sql); echo db_rowcount(); ?>
                                    </h3>
                                    <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                            <th>No</th>
                                            <th>Username</th>
                                            <th>Branch</th>
                                            <th>Completed Quest</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(db_rowcount()>0){ for($i=0;$i<db_rowcount();$i++){ if(func_getOffset()>=10){ $no=func_getOffset()+1+$i; }else{ $no=$i+1; } echo "<tr>
                                                            <td>".$no."</td>
                                                            <td>".db_get($i,2)."</td>
                                                            <td>".db_get($i,4)."</td>
                                                            <td>".db_get($i,3)."</td>
                                                            </tr>";
                                                }
                                                    } ?>
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">more_horiz</i>
                                        <a href="#">Full Detail</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
</div>

</body>
<?php include('_footer.php');?>