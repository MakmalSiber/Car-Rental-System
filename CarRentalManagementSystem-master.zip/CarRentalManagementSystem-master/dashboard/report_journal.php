<?php
include("_header.php");

func_setReqVar();

if (isset($btn_clear)) {
	vali_redirect('counter_reservation.php');
}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="purple">
					<h4 class="title">Journal</h4>
                </div>
            <div class="card-content">
			<form>
			<div class="form-group">
				<label class="control-label">Date</label>
					<input type="text" class="form-control" name="search_agent" value="<?php echo $search_agent;?>">
			</div>
			<div class="form-group">
				<div class="text-center">
					<button type="submit" class="btn btn-success" name="btn_search">Search</button>
				</div>
			</div>
			<div class="table-responsive">
			<table class="table">
				<thead>
					<tr>
					<th>No</th>
					<th>Pickup Location</th>
					<th>Pickup Date</th>
					<th>Pickup Time</th>
					<th>Return Location</th>
					<th>Return Date</th>
					<th>Return Time</th>
					<th>Option Rental</th>
					<th>CDW</th>
					<th>Discount</th>
					<th>Vehicle</th>
					<th>Status</th>
					<th>Day</th>
					<th>Sub Total</th>
					<th>GST</th>
					<th>Estimate Total</th>
					<th>Customer</th>
					<th>Deposit</th>
					<th>Type</th>
					<th>Balance</th>
					</tr>
				</thead>
				<tbody>
				<?php
					func_setPage();
					func_setOffset();
					func_setLimit(10);
				
					if(isset($btn_search)){
					
						if($search_agent!=""){
							$where=" AND name like '%".$search_agent."%'";
						}
					}
				
					$sql = "SELECT 
					booking_trans.id, 
					DATE_FORMAT(pickup_date, '%d/%m/%Y') as pickup_date, 
					CASE pickup_location WHEN '4' THEN 'Port Dickson' WHEN '5' THEN 'Seremban' END AS pickup_location, 
					DATE_FORMAT(pickup_time, '%H:%i:%s') as pickup_time,
					DATE_FORMAT(return_date, '%d/%m/%Y') as return_date, 
					CASE return_location WHEN '4' THEN 'Port Dickson' WHEN '5' THEN 'Seremban' END AS return_location, 
					DATE_FORMAT(return_time, '%H:%i:%s') as return_time,
					option_rental_id, 
					cdw, 
					discount_id, 
					vehicle_id, 
					status, 
					day, 
					sub_total, 
					gst, 
					est_total, 
					customer_id, 
					refund_dep, 
					type, 
					balance
					FROM booking_trans 
					WHERE booking_trans.id IS NOT NULL" .$where;
					db_select($sql);
					
					func_setTotalPage(db_rowcount());
					db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
					
					if(db_rowcount()>0){
						for($i=0;$i<db_rowcount();$i++){
							
							if(func_getOffset()>=10){
								$no=func_getOffset()+1+$i;
							}else{
								$no=$i+1;
							}
							
							echo "<tr>
									<td>".$no."</td>
									<td>".db_get($i,2)."</td>
									<td>".db_get($i,1)."</td>
									<td>".db_get($i,3)."</td>
									<td>".db_get($i,5)."</td>
									<td>".db_get($i,4)."</td>
									<td>".db_get($i,6)."</td>
									<td>".db_get($i,7)."</td>
									<td>".db_get($i,8)."</td>
									<td>".db_get($i,9)."</td>
									<td>".db_get($i,10)."</td>
									<td>".db_get($i,11)."</td>
									<td>".db_get($i,12)."</td>
									<td>".db_get($i,13)."</td>
									<td>".db_get($i,14)."</td>
									<td>".db_get($i,15)."</td>
									<td>".db_get($i,16)."</td>
									<td>".db_get($i,17)."</td>
									<td>".db_get($i,18)."</td>
									<td>".db_get($i,19)."</td>
									<td>".db_get($i,20)."</td>
									<td>".db_get($i,21)."</td>
								</tr>";	
						}
					}else{
						echo "<tr><td colspan='20'>No records found</td></tr>";
					}
				?>
				<tr>
					<td colspan="20" style="text-align:center">
					<?php 
						func_getPaging('manage_agent.php?x&btn_search=&search_name='.$search_name.'&page'.$page);
					?>
					</td>
				</tr>
				</tbody>
			</table>
			</div>
		</div>
	</div>
	</form>
            </div>
        </div>
    </div>
</div>

