<?php
include("_header.php");

func_setReqVar();

if (isset($btn_clear)) {
	vali_redirect('counter_reservation.php');
}
?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="purple">
                            <h4 class="title">Sale Data</h4>
                        </div>
                        <div class="card-content">
                         <form>
                        <div class="row">
							<div class="col-md-6">
							<div class="form-group">
						 <label class="control-label">Start Date</label>
						 <input type="text" class="form-control" id="search_start_date" name="search_start_date" value="<?php echo $search_start_date;?>">
						</div>    
							</div>
							<div class="col-md-6">
							<div class="form-group">
							<label class="control-label">End Date</label>
							<input type="text" class="form-control" id="search_end_date" name="search_end_date" value="<?php echo $search_end_date;?>">
						</div>   
							</div>
						</div>        
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-success" name="btn_search">Search</button>
							<a href="report_car_status.php" class="btn btn-warning">Clear</a>
						</div>
						<div class="table-responsive">
                        <table class="table">
                        <thead class="text-primary">
											<th>No.</th>
											<th>Vehicle No.</th>
											<th>Reg No.</th>
											<th>Pickup Date</th>
											<th>Pickup Time</th>
											<th>Return Date</th>
											<th>Return Time</th>
											<th>Customer Name</th>
											<th>NRIC No.</th>
										</thead>
										<tbody>
                                        <?php
							func_setPage();
							func_setOffset();
							func_setLimit(10);
						
							if(isset($btn_search)){
							
								if($search_start_date != "" AND $search_end_date != ""){
									$where=" AND pickup_date = '$search_start_date' AND return_date = '$search_end_date'";
								}
							}
						
							$sql = "SELECT 
                            vehicle.id,
                            reg_no, 
							DATE_FORMAT(pickup_date, '%d/%m/%Y') as pickup_date, 
							DATE_FORMAT(pickup_time, '%H:%i:%s') as pickup_time, 
							DATE_FORMAT(return_date, '%d/%m/%Y') as return_date, 
							DATE_FORMAT(return_time, '%H:%i:%s') as return_time, 
                            booking_trans.id,
                            concat(firstname,' ' ,lastname) as name,
                            nric_no 
                            FROM vehicle 
                            LEFT JOIN booking_trans ON vehicle.id = vehicle_id 
                            LEFT JOIN class ON class.id = class_id 
                            LEFT JOIN customer ON customer_id = customer.id 
                            WHERE booking_trans.id IS NOT NULL" .$where;
                            db_select($sql);
                            
							//echo $sql;
							func_setTotalPage(db_rowcount());
							db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
							
							if(db_rowcount()>0){
								for($i=0;$i<db_rowcount();$i++){
									
									if(func_getOffset()>=10){
										$no=func_getOffset()+1+$i;
									}else{
										$no=$i+1;
									}
									
									echo "<tr>
										<td>".$no."</td>
										<td>".db_get($i,0)."</td>
										<td>".db_get($i,1)."</td>
										<td>".db_get($i,2)."</td>
										<td>".db_get($i,3)."</td>
										<td>".db_get($i,4)."</td>
										<td>".db_get($i,5)."</td>
										<td>".db_get($i,7)."</td>
										<td>".db_get($i,8)."</td>
										</tr>";	
								}
							}else{
								echo "<tr><td colspan='9'>No records found</td></tr>";
							}
						?>
						<tr>
							<td colspan="9" style="text-align:center">
							<?php 
								func_getPaging('report_car_status.php?x&search_start_date='.$search_start_date.'&search_end_date='.$search_end_date);
							?>
							</td>
						</tr>
						</tbody>
					</table>
					</div>
                         </form>
                    </div>
                </div>
			</div>
			
	<?php include('_footer.php'); ?>

	
	<script>
        $(document).ready(function () {
            var date_input = $('input[name="search_start_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy/mm/dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>
	<script>
        $(document).ready(function () {
            var date_input = $('input[name="search_end_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy/mm/dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>