# Car Rental Management System

## Created for [MYEZGO Travel &amp; Tours Sdn. Bhd.](http://www.myezgo.com/dashboard/) | [RocketLeisure Travel &amp; Tours Sdn. Bhd.](http://roketleisure.com/dashboard/)

MYEZGO Travel & Tours      |  Rocket Leisure Travel & Tours
:-------------------------:|:-------------------------:
![](https://raw.githubusercontent.com/DanishDanialZurkanain/CarRentalManagementSystem/master/assets/img/preview/showcase_myezgo.png?token=ACdf3Ii_nfcZpNDAzG9nDvuipvS9Utmnks5a1wkgwA%3D%3D)  |  ![](https://raw.githubusercontent.com/DanishDanialZurkanain/CarRentalManagementSystem/master/assets/img/preview/showcase_roketleisure.png?token=ACdf3IzLNVgTfRYMciMzuftvOw3AwGjbks5a1wkdwA%3D%3D)
