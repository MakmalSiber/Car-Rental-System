<?php
include("_header.php");

func_setReqVar();

?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">User</h4>
                </div>
            <div class="card-content">
			<form>
			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" class="form-control" name="search_name" value="<?php echo $search_name;?>">
			</div>
			<div class="form-group">
				<div class="text-center">
					<button type="submit" class="btn btn-success" name="btn_search">Search</button>
				</div>
			</div>

			<div class="table-responsive">
			<table class="table">
				<thead>
					<tr>
					<th>Number</th>
					<th>Username</th>
					<th>Name</th>
					<th>Branch</th>
					<th>Occupation</th>
					<th>Status</th>
					<th>Action</th>
					</tr>
				</thead>
				<tbody>
				<?php
					func_setPage();
					func_setOffset();
					func_setLimit(10);
				
					if(isset($btn_search)){
					
						if($search_name!=""){
							$where=" AND name like '%".$search_name."%'";
						}
					}
				
					$sql = "SELECT id, username, name, branch, occupation, status from user where id > 1" .$where;
					db_select($sql);
					
					func_setTotalPage(db_rowcount());
					db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset());
					
					if(db_rowcount()>0){
						for($i=0;$i<db_rowcount();$i++){
							
							if(func_getOffset()>=10){
								$no=func_getOffset()+1+$i;
							}else{
								$no=$i+1;
							}
							
							echo "<tr>
									<td>".$no."</td>
									<td>".db_get($i,1)."</td>
									<td>".db_get($i,2)."</td>
									<td>".db_get($i,3)."</td>
									<td>".db_get($i,4)."</td>
									<td>".db_get($i,5)."</td>
									<td><a href='manage_user_edit.php?id=".db_get($i,0)."&search_name=".$search_name."'><i class='material-icons'>mode_edit</i></a></td>
								</tr>";	
						}
					}else{
						echo "<tr><td colspan='8'>No records found</td></tr>";
					}
				?>
				<tr>
					<td colspan="8" align="center">
						<div class="form-group">
							<button type="button" class="btn btn-success" name="btn_save" onclick="location.href='manage_user_new.php?btn_search=&search_name=<?php echo $search_name;?>&page<?php echo $page;?>'">Add New</button>
						</div>
					</td>
				</tr>
				<tr>
					<td colspan="8" style="text-align:center">
					<?php 
						func_getPaging('manage_user.php?x&btn_search=&search_name='.$search_name.'&page'.$page);
					?>
					</td>
				</tr>
				</tbody>
			</table>
			</div>
		</div>
	</div>
	</form>
            </div>
        </div>
    </div>
</div>

