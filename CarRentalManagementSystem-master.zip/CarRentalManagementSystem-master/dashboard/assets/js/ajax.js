//======================================================================
//======================================================================

function selectNRIC(nric) {
  var a = new myAjax();
  a.method = "GET";
  a.url = "ajax.php?t=selectNRIC&nric=" + nric;
  //alert(a.url);
  a.success = function() {
    var dt = a.myObject.GetResponse();
    var split = dt.split("|||");
    document.getElementById("firstname").value = split[0];
    document.getElementById("address").value = split[1];
    document.getElementById("postcode").value = split[2];
    document.getElementById("city").value = split[3];
    document.getElementById("country").value = split[4];
    //document.getElementById("title").selectedIndex=split[5];
    document.getElementById("title").value = split[5];
    document.getElementById("lastname").value = split[6];
    document.getElementById("age").value = split[7];
    document.getElementById("phone_no").value = split[8];
    document.getElementById("email").value = split[9];
    //document.getElementById("ref_name").value=split[10];
    //document.getElementById("ref_phoneno").value=split[11];
    document.getElementById("license_no").value = split[12];
    //document.getElementById("gl_code").value=split[13];
    //document.getElementById("ref_relationship").value=split[13];
    //document.getElementById("ref_address").value=split[14];
    //alert(dt);
    //if($(div)) $(result).innerHTML = dt;
    //document.getElementById(div).innerHTML=dt;
  };
  a.send();
}

function loadAjax2(page, elm) {
  var a = new myAjax();
  a.method = "GET";
  a.url = page;
  a.success = function() {
    var dt = a.myObject.GetResponse();
    if ($(elm)) $(elm).value = dt;
  };
  a.send();
}
//======================================================================
//======================================================================

function myAjax(arr) {
  var method = "POST";
  var url = "";
  var param = "";
  var asyn = true;
  var data = "";
  var success = function() {};
  var myObject = null;
  // for (var a in arr) this[a] = arr[a];

  this.send = function() {
    url = this.param ? this.url + "?" + this.param : this.url;
    this.myObject = new ajax();
    this.myObject.InitializeRequest(
      this.method ? this.method : "GET",
      url,
      this.asyn
    );

    if (this.success) this.myObject.OnSuccess = this.success;
    if (this.uninitialize) this.myObject.OnUninitialize = this.uninitialize;
    if (this.loading) this.myObject.OnLoading = this.loading;
    if (this.loaded) this.myObject.OnLoaded = this.loaded;
    if (this.interactive) this.myObject.OnInteractive = this.interactive;
    if (this.failure) this.myObject.OnFailure = this.failure;

    if (this.data) {
      this.myObject.Commit(this.data);
    } else {
      this.myObject.Commit("");
    }
  };
}

//================================================================================================================================================
//================================================================================================================================================
//================================================================================================================================================

function ajax() {
  //---------------------
  // Private Declarations
  //---------------------
  var _request = null;
  var _this = null;

  //--------------------
  // Public Declarations
  //--------------------
  this.GetResponseXML = function() {
    return _request ? _request.responseXML : null;
  };

  this.GetResponse = function() {
    if (_request) {
      var ct = _request.getResponseHeader("content-type");
      var c = ct.indexOf("xml") >= 0;
      data = c ? _request.responseXML : _request.responseText;
      return data;
    } else {
      return null;
    }
    // return (_request) ? _request.responseText : null;
  };

  this.GetRequestObject = function() {
    return _request;
  };

  this.InitializeRequest = function(Method, Uri, asyn) {
    _InitializeRequest();
    _this = this;
    switch (arguments.length) {
      case 2:
        _request.open(Method, Uri);
        break;

      case 3:
        _request.open(Method, Uri, arguments[2]);
        break;
    }

    if (arguments.length >= 4)
      _request.open(Method, Uri, arguments[2], arguments[3]);
    this.SetRequestHeader(
      "Content-Type",
      "application/x-www-form-urlencoded; charset=UTF-8"
    );
  };

  this.SetRequestHeader = function(Field, Value) {
    if (_request) _request.setRequestHeader(Field, Value);
  };

  this.Commit = function(Data) {
    if (_request) {
      _request.send(Data);
      _StateHandler();
    }
  };

  this.Close = function() {
    if (_request) _request.abort();
  };

  //---------------------------
  // Public Event Declarations.
  //---------------------------
  this.OnUninitialize = function() {};
  this.OnLoading = function() {};
  this.OnLoaded = function() {};
  this.OnInteractive = function() {};
  this.OnSuccess = function() {};
  this.OnFailure = function() {};

  //---------------------------
  // Private Event Declarations
  //---------------------------
  function _OnUninitialize() {
    _this.OnUninitialize();
  }
  function _OnLoading() {
    _this.OnLoading();
  }
  function _OnLoaded() {
    _this.OnLoaded();
  }
  function _OnInteractive() {
    _this.OnInteractive();
  }
  function _OnSuccess() {
    _this.OnSuccess();
  }
  function _OnFailure() {
    _this.OnFailure();
  }

  //------------------
  // Private Functions
  //------------------
  function _InitializeRequest() {
    _request = _GetRequest();
    _request.onreadystatechange = _StateHandler;
  }

  function _StateHandler() {
    switch (_request.readyState) {
      case 0:
        window.setTimeout("void(0)", 100);
        _OnUninitialize();
        break;

      case 1:
        window.setTimeout("void(0)", 100);
        _OnLoading();
        break;

      case 2:
        window.setTimeout("void(0)", 100);
        _OnLoaded();
        break;

      case 3:
        window.setTimeout("void(0)", 100);
        _OnInteractive();
        break;

      case 4:
        if (_request.status == 200) _OnSuccess();
        else _OnFailure();

        return;
        break;
    }
  }

  function _GetRequest() {
    var obj;

    try {
      obj = new XMLHttpRequest();
    } catch (error) {
      try {
        obj = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (error) {
        return null;
      }
    }

    return obj;
  }
}

//======================================================================
