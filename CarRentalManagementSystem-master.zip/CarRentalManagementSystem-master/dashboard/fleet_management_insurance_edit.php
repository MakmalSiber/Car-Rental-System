<?php
	include "_header.php";
	func_setReqVar();if (isset($btn_save)) {func_setValid("Y");
	func_isEmpty($vehicle_id, "vehicle");
	func_isEmpty($renewal_date, "renewal date");
	func_isEmpty($serial_no, "serial no");
	func_isEmpty($amount, "amount");
	func_isEmpty($provider, "provider");
	func_isEmpty($period, "period");
	func_isEmpty($note, "note");
	
	if (func_isValid()) {
		
		$sql = "UPDATE fleet_insurance SET
		vehicle_id = '" . $vehicle_id . "',
		renewal_date = '" . conv_datetodbdate($renewal_date) . "',
		serial_no = '" . conv_text_to_dbtext3($serial_no) . "',
		amount = " . $amount . ",
		period = " . $period . ",
		note = '" . conv_text_to_dbtext3($note) . "',
		provider = '" . $provider . "',
		cid = " . $_SESSION['cid'] . ",
		cdate = CURRENT_TIMESTAMP
		WHERE id = " . $_GET['id'];
		db_update($sql);
		vali_redirect("fleet_management_insurance.php?btn_search=Search&page=" . $page . "&search_vehicle=" . $search_vehicle);
	}
	} else if (isset($btn_delete)) {
		$sql = "DELETE from fleet_insurance WHERE id = " . $_GET['id'];
		db_update($sql);
		
		vali_redirect("fleet_management_insurance.php?btn_search=Search&page=" . $page . "&search_vehicle=" . $search_vehicle);
	} else { 
		$sql = "SELECT vehicle_id, DATE_FORMAT(renewal_date, '%d/%m%/%Y') as renewal_date, serial_no, amount, period, note, provider FROM fleet_insurance WHERE id=" . $_GET['id'];
		db_select($sql);if (db_rowcount() > 0) {func_setSelectVar();}
	}?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="red">
					<h4 class="title">Insurance</h4>
                </div>
            <div class="card-content">

            <form method="POST">
				<span style="color:red"><?php echo func_getErrMsg(); ?></span>

                <div class="row">

                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Vehicle</label>
								<select class="form-control" name="vehicle_id" <?php echo $disabled; ?>>									<option value="">Please Select</option>
									<?php $value = "";
									$sql = "SELECT id, reg_no, model, year from vehicle";
									db_select($sql);if (db_rowcount() > 0) {for ($j = 0; $j < db_rowcount(); $j++) {$value = $value . "<option value='" . db_get($j, 0) . "' " . vali_iif(db_get($j, 0) == $vehicle_id, 'Selected', '') . ">
																				" . db_get($j, 1) . " : " . db_get($j, 2) . " (" . db_get($j, 3) . ")</option>";}}
									echo $value;?>
								</select>
						</div>
                    </div>
                    <div class="col-md-4">
						<div class="form-group label-floating">
							<label class="control-label">Renewal Date</label>
                            <input class="form-control" type="text" id="renewal_date" name="renewal_date" value="<?php echo $renewal_date; ?>">
						</div>
                    </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Serial No</label>
								<input type="text" class="form-control" name="serial_no" value="<?php echo $serial_no; ?>">
						</div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Amount</label>
								<input type="text" class="form-control" name="amount" value="<?php echo $amount; ?>">
						</div>
                    </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Provider</label>
								<select name="provider" class="form-control">
									<option value=''>Please Select</option>
									<option value='AIA' <?php echo vali_iif('AIA' == $provider, 'Selected', ''); ?>>AIA</option>
									<option value='AIG' <?php echo vali_iif('AIG' == $provider, 'Selected', ''); ?>>AIG</option>
									<option value='Allianz' <?php echo vali_iif('Allianz' == $provider, 'Selected', ''); ?>>Allianz</option>
									<option value='Etiqa Takaful' <?php echo vali_iif('Etiqa Takaful' == $provider, 'Selected', ''); ?>>Etiqa Takaful</option>
									<option value='Kurnia' <?php echo vali_iif('Kurnia' == $provider, 'Selected', ''); ?>>Kurnia</option>
									<option value='Takaful Ikhlas' <?php echo vali_iif('Takaful Ikhlas' == $provider, 'Selected', ''); ?>>Takaful Ikhlas</option>
									<option value='Takaful Malaysia' <?php echo vali_iif('Takaful Malaysia' == $provider, 'Selected', ''); ?>>Takaful Malaysia</option>
									<option value='Tokio Marine' <?php echo vali_iif('Tokio Marine' == $provider, 'Selected', ''); ?>>Tokio Marine</option>
									<option value='MAA Takaful' <?php echo vali_iif('MAA Takaful' == $provider, 'Selected', ''); ?>>MAA Takaful</option>
									<option value='Zurich' <?php echo vali_iif('Zurich' == $provider, 'Selected', ''); ?>>Zurich</option>
									<option value='Other' <?php echo vali_iif('Other' == $provider, 'Selected', ''); ?>>Other</option>
								</select>
							</div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Period</label>
								<select name="period" class="form-control m-b" style="width: 15em">
									<option value='1' <?php echo vali_iif('1' == $period, 'Selected', ''); ?>>1 years</option>
									<option value='2' <?php echo vali_iif('2' == $period, 'Selected', ''); ?>>2 years</option>
									<option value='3' <?php echo vali_iif('3' == $period, 'Selected', ''); ?>>3 years</option>
									<option value='4' <?php echo vali_iif('4' == $period, 'Selected', ''); ?>>4 years</option>
									<option value='5' <?php echo vali_iif('5' == $period, 'Selected', ''); ?>>5 years</option>
									<option value='6' <?php echo vali_iif('6' == $period, 'Selected', ''); ?>>6 months</option>
								</select>
						</div>
                    </div>
                </div>

                <div class="form-group label-floating">
						<label class="control-label">Note (If any)</label>
						<textarea class="form-control" name="note"><?php echo $note; ?></textarea>
				</div>

						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save</button>
								<button type="submit" class="btn btn-danger" name="btn_delete">Delete</button>
								<button type="button" class="btn btn-warning" onclick="location.href='fleet_management_insurance.php?btn_search=&search_vehicle=<?php echo $search_vehicle; ?>'">Cancel</button>
							</div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

	<?php include('_footer.php'); ?>
	
    <script>
        $(document).ready(function () {
            var date_input = $('input[name="renewal_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>