<?php
include ("_header.php");

func_setReqVar();

// User
$sql = "SELECT * FROM user WHERE id=".$_SESSION['cid'];

//echo $sql;
db_select($sql);
if (db_rowcount() > 0) {
	func_setSelectVar();
}

$id = $_GET['id'];

$class_id = $_GET['class_id'];
	
// Checkbox equal to "X" when not selected

if(!isset($_POST['start_engine'])){
	$start_engine = "X";
} 

if(!isset($_POST['no_alarm'])) {
	$no_alarm = "X";
} 

if(!isset($_POST['air_conditioner'])){
	$air_conditioner = "X";
} 

if(!isset($_POST['radio'])){
	$radio = "X";
} 

if(!isset($_POST['power_window'])){
	$power_window = "X";
} 
if(!isset($_POST['window_condition'])){
	$window_condition = "X";
} 
if(!isset($_POST['perfume'])){
	$perfume = "X";
} 
if(!isset($_POST['carpet'])){
	$carpet = "X";
} 
if(!isset($_POST['sticker'])){
	$sticker = "X";
} 
if(!isset($_POST['lamp'])){
	$lamp = "X";
} 
if(!isset($_POST['engine_condition'])){
	$engine_condition = "X";
} 
if(!isset($_POST['tyres_condition'])){
	$tyres_condition = "X";
} 
if(!isset($_POST['jack'])){
	$jack = "X";
} 
if(!isset($_POST['tools'])){
	$tools = "X";
} 
if(!isset($_POST['signage'])){
	$signage = "X";
} 
if(!isset($_POST['child_seat'])){
	$child_seat = "X";
} 
if(!isset($_POST['wiper'])){
	$wiper = "X";
} 
if(!isset($_POST['gps'])){
	$gps = "X";
} 
if(!isset($_POST['tyre_spare'])){
	$tyre_spare = "X";
} 
if(!isset($_POST['usb_charger'])){
	$usb_charger = "X";
} 
if(!isset($_POST['touch_n_go'])){
	$touch_n_go = "X";
} 
if(!isset($_POST['smart_tag'])){
	$smart_tag = "X";
} 
	

if (isset($_POST['btn_in'])) {

	$upload_dir = "assets/img/";
	$img = $_POST['hidden_data'];
	$img = str_replace('data:image/png;base64,', '', $img);
	$img = str_replace(' ', '+', $img);
	$data = base64_decode($img);
	$file = $upload_dir . mktime() . ".png";
	$success = file_put_contents($file, $data);
	print $success ? $file : 'Unable to save the file.';

	$sql = "UPDATE checklist SET car_in_start_engine = '$start_engine', car_in_no_alarm = '$no_alarm', car_in_air_conditioner = '$air_conditioner', car_in_radio = '$radio', car_in_power_window = '$power_window', car_in_window_condition = '$window_condition', car_in_perfume = '$perfume', car_in_carpet = '$carpet', car_in_sticker_p = '$sticker', car_in_lamp = '$lamp', car_in_engine_condition = '$engine_condition', car_in_tyres_condition = '$tyres_condition', car_in_jack = '$jack', car_in_tools = '$tools', car_in_signage = '$signage', car_in_child_seat = '$child_seat', car_in_wiper = '$wiper', car_in_gps = '$gps', car_in_tyre_spare = '$tyre_spare', car_in_usb_charger = '$usb_charger', car_in_touch_n_go = '$touch_n_go', car_in_smart_tag = '$smart_tag', car_in_seat_condition = '$car_seat_condition', car_in_cleanliness = '$cleanliness', car_in_fuel_level = '$fuel_level', car_in_image = '$file', car_in_remark = '$remark_return' WHERE booking_trans_id = $id";
	db_update($sql);

	$sql = "UPDATE booking_trans SET other_details = '$other_details', other_details_payment_type = '$payment_status', other_details_price = '$other_details_price', refund_dep_status = '$deposit_status', damage_charges = '$damage_charges', damage_charges_details = '$damage_charges_details', damage_charges_payment_type = '$damage_charges_payment_type', missing_items_charges = '$missing_items_charges', missing_items_charges_details = '$missing_items_charges_details', missing_items_charges_payment_type = '$missing_items_charges_payment_type', additional_cost = '$additional_cost', additional_cost_details = '$additional_cost_details', additional_cost_payment_type = '$additional_cost_payment_type', outstanding_extend_cost = '$outstanding_extend_charges', outstanding_extend_type_of_payment = '$outstanding_extend_payment_type', outstanding_extend = '$outstanding_extend' WHERE id = $id";
	db_update($sql);


	$sql = "UPDATE vehicle SET availability = 'Available' WHERE id=".$_GET['vehicle_id'];
	db_update($sql);

	echo "<script type='text/javascript'>window.open('returnreceipt.php?id=".$_GET['id']."');</script>";
	
	vali_redirect("reservation_list_view.php?id=".$_GET['id']);

} else {
	$sql = "SELECT * FROM booking_trans WHERE id = $id";
	db_select($sql);
	if (db_rowcount() > 0) {
		func_setSelectVar();
	}
}

if (isset($_POST['btn_out'])) {

	$upload_dir = "assets/img/";
	$img = $_POST['hidden_datas'];
	$img = str_replace('data:image/png;base64,', '', $img);
	$img = str_replace(' ', '+', $img);
	$data = base64_decode($img);
	$file = $upload_dir . mktime() . ".png";
	$success = file_put_contents($file, $data);
	print $success ? $file : 'Unable to save the file.';

    $sql = "UPDATE checklist SET car_out_start_engine = '$start_engine', car_out_no_alarm = '$no_alarm', car_out_air_conditioner = '$air_conditioner', car_out_radio = '$radio', car_out_power_window = '$power_window', car_out_window_condition = '$window_condition' , car_out_perfume = '$perfume', car_out_carpet = '$carpet', car_out_sticker_p = '$sticker', car_out_lamp = '$lamp', car_out_engine_condition = '$engine_condition', car_out_tyres_condition = '$tyres_condition', car_out_jack = '$jack', car_out_tools = '$tools', car_out_signage = '$signage', car_out_child_seat = '$child_seat' , car_out_wiper = '$wiper', car_out_gps = '$gps' , car_out_tyre_spare = '$tyre_spare', car_out_usb_charger = '$usb_charger', car_out_touch_n_go = '$touch_n_go', car_out_smart_tag = '$smart_tag', car_out_seat_condition = '$car_seat_condition', car_out_cleanliness = '$cleanliness', car_out_fuel_level = '$fuel_level', car_out_image = '$file', car_out_remark = '$remark_pickup' WHERE booking_trans_id = $id";
	db_update($sql);

	$sql = "UPDATE booking_trans SET vehicle_id = '$change_vehicle', reason = '$reason_chg_car' WHERE id = $id";
	db_update($sql);

	if(isset($_FILES['files'])){
	foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
		$file_name = $key.$_FILES['files']['name'][$key];
		$file_size =$_FILES['files']['size'][$key];
		$file_tmp =$_FILES['files']['tmp_name'][$key];
		$file_type=$_FILES['files']['type'][$key];	
		if($file_size > 2097152){
			$errors[]='File size must be less than 2 MB';
		}	
		$sql = "INSERT INTO upload_data (`BOOKING_TRANS_ID`,`FILE_NAME`,`FILE_SIZE`,`FILE_TYPE`) VALUES ('$id','$file_name','$file_size','$file_type'); ";	
		$desired_dir="assets/img/car_state";
		if(empty($errors)==true){
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 0700);		// Create directory if it does not exist
            }
            if(is_dir("$desired_dir/".$file_name)==false){
                move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
            }else{									// rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;				
            }
			db_update($sql);			
		}
	}
	}
	
		vali_redirect("reservation_list_view.php?id=".$_GET['id']);

} else {
	$sql = "SELECT * FROM booking_trans WHERE id = $id";
	db_select($sql);
	if (db_rowcount() > 0) {
		func_setSelectVar();
	}
}

if(isset($_POST['btn_extend'])) {

	func_setReqVar();

	$day = dateDifference(conv_datetodbdate($extend_from_date), conv_datetodbdate($extend_to_date),'%d'); 
	$time = dateDifference($extend_from_time, $extend_to_time, '%h'); 
	
	$rate = "SELECT * FROM car_rate WHERE class_id = '$class_id'"; 
	db_select($rate); 
	if(db_rowcount()>0){ 
		func_setSelectVar(); 
	} 

	if ($day == 0) {
		$subtotal = $time * $hour;
		if ($time == 12) {
			$subtotal = $halfday ;
		} 
	} 
	elseif ($day == 1) {
		$subtotal = $oneday + ($time * $hour);
		if ($time == 12) {
			$subtotal = $oneday + $halfday ;
		} 
	} 
	elseif ($day == 2) {
		$subtotal = $twoday + ($time * $hour);
		if ($time == 12) {
			$subtotal = $twoday + $halfday ;
		} 
	}
	elseif ($day == 3) {
		$subtotal = $threeday + ($time * $hour);
		if ($time == 12) {
			$subtotal = $threeday + $halfday ;
		} 
	}
	elseif ($day == 4) {
		$subtotal = $fourday + ($time * $hour);
		if ($time == 12) {
			$subtotal = $fourday + $halfday ;
		} 
	}
	elseif ($day == 5) {
		$subtotal = $fiveday + ($time * $hour);
		if ($time == 12) {
			$subtotal = $fiveday + $halfday ;
		} 
	}
	elseif ($day == 6) {
		$subtotal = $sixday + ($time * $hour);
		if ($time == 12) {
			$subtotal = $sixday + $halfday ;
		} 
	} 
	elseif ($day == 7) {
		$subtotal = $weekly + ($time * $hour);
		if ($time == 12) {
			$subtotal = $weekly + $halfday ;
		}  	
	}
	elseif ($day = 30) {
		$subtotal = $mothly + ($time * $hour);
	} else {
		echo "Non-available";
	} 
	
	$sql = "SELECT * FROM extend WHERE booking_trans_id=".$_GET['id'];
	db_select($sql);

	if(db_rowcount() < 9){
	$sql = "INSERT INTO 
	extend 
	(
	booking_trans_id, 
	extend_from_date,
	extend_from_time,
	extend_to_date,
	extend_to_time,
	payment_status,
	payment_type,
	price,
	total
	) 
	VALUES 
	(
	'".$_GET['id']."', 
	'".conv_datetodbdate($extend_from_date)."',
	'$extend_from_time',
	'".conv_datetodbdate($extend_to_date)."',
	'$extend_to_time',
	'$payment_status',
	'$payment_type',
	'$subtotal',
	'$subtotal'
	)";
	db_update($sql);
	} else {
		echo "<script>alert('Extend has reach their limit.')</script>";
	}

	vali_redirect("reservation_list.php");
}

?>

<style>
.small .btn, .navbar .navbar-nav > li > a.btn {
	padding: 10px 10px;
}

.color-background {
	background-color: #eeeeee;
	border-radius: 5px 5px;
	padding: 10px;
}

.modal-backdrop, .modal-backdrop.fade.in {
	opacity: 0;
}

#canvas
{
width: 100%;
height: 100%;
background: url('assets/img/car.png');
background-repeat:no-repeat;
background-size:contain;
background-position:center;
}

#board
{
width: 100%;
height: 100%;
background: url('assets/img/car.png');
background-repeat:no-repeat;
background-size:contain;
background-position:center;
}

#return_sign 
{
width: 100%;
height: 100%;
border: 1px solid #000;
}
</style>

<script src="assets/js/fabric.min.js"></script>
<script src="assets/js/jquery-3.3.1.min.js"></script>

	<!-- Modal In-->
		<form method="post" name="modalIn">
			<div class="modal fade" id="modalIn" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Return</h4>
				</div>
				<div class="modal-body">

					<div class="form-group">
						<label class="control-label">Payment</label>
						<input type="text" class="form-control" name="payment" value=<?php echo $balance; ?>>
					</div>

					<div class="color-background">

						<div class="row">
							<div class="col-md-12">
								<center>
									<div class="alert alert-info" role="alert">
										<b>Payment to Customer</b>
									</div>
								</center>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Deposit Status</label>
									<select name="deposit_status" class="form-control">
										<option value='Paid' <?php echo vali_iif('Paid' == $deposit_status, 'Selected', ''); ?>>Paid</option>
										<option value='Unpaid' <?php echo vali_iif('Unpaid' == $deposit_status, 'Selected', ''); ?>>Unpaid</option>
									</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Other Details</label>
									<input class="form-control" name="other_details" value="<?php echo $other_details; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Payment Status</label>
									<select name="payment_status" class="form-control">
										<option value='Paid' <?php echo vali_iif('Paid' == $payment_status, 'Selected', ''); ?>>Paid</option>
										<option value='Unpaid' <?php echo vali_iif('Unpaid' == $payment_status, 'Selected', ''); ?>>Unpaid</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Price</label>
									<input class="form-control" name="other_details_price" value="<?php echo $other_details_price; ?>">
								</div>
							</div>
						</div>

						<br>

						<div class="row">
							<div class="col-md-12">
								<center>
									<div class="alert alert-info" role="alert">
										<b>Payment from Customer</b>
									</div>
								</center>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Outstanding Extend</label>
									<select name="outstanding_extend" class="form-control">
										<option value="No Outstanding Extend">No Outstanding Extend</option>
										<?php  $value = ""; $sql = "SELECT DATE_FORMAT(extend_from_date, '%d/%m/%Y'), DATE_FORMAT(extend_from_time, '%H:%i'), DATE_FORMAT(extend_to_date, '%d/%m/%Y'), DATE_FORMAT(extend_to_time, '%H:%i') FROM extend WHERE booking_trans_id=$id"; 
										db_select($sql); 
										if(db_rowcount()>0){
											 for($j=0;$j<db_rowcount();$j++) {
												 $value = $value."<option value='".db_get($j,0).' - '.db_get($j,1).' @ '.db_get($j,2).' - '.db_get($j,3)."' ".vali_iif(db_get($j,0).' - '.db_get($j,1).' @ '.db_get($j,2).' - '.db_get($j,3)==$outstanding_extend,'Selected','').">".db_get($j,0)." - ".db_get($j,1)." @ ".db_get($j,2)." - ".db_get($j,3)."</option>"; 
											}
										} echo $value; ?>
                                    </select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label">Charges for Extend (RM)</label>
									<input class="form-control" name="outstanding_extend_charges" value="<?php echo $outstanding_extend_charges; ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label">Type of Payment </label>
									<select name="outstanding_extend_payment_type" class="form-control">
										<option value='Cash' <?php echo vali_iif('Cash' == $outstanding_extend_payment_type, 'Selected', ''); ?>>Cash</option>
										<option value='Online' <?php echo vali_iif('Online' == $outstanding_extend_payment_type, 'Selected', ''); ?>>Online</option>
										<option value='Card' <?php echo vali_iif('Card' == $outstanding_extend_payment_type, 'Selected', ''); ?>>Card</option>
									</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Damages Details</label>
									<input class="form-control" name="damage_charges_details" value="<?php echo $damage_charges_details; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Charges for Damages (RM)</label>
									<input class="form-control" name="damage_charges" value="<?php echo $damage_charges; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Type of Payment </label>
									<select name="damage_charges_payment_type" class="form-control">
										<option value='Cash' <?php echo vali_iif('Cash' == $damage_charges_payment_type, 'Selected', ''); ?>>Cash</option>
										<option value='Online' <?php echo vali_iif('Online' == $damage_charges_payment_type, 'Selected', ''); ?>>Online</option>
										<option value='Card' <?php echo vali_iif('Card' == $damage_charges_payment_type, 'Selected', ''); ?>>Card</option>
									</select>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Missing Items Details</label>
									<input class="form-control" name="missing_items_charges_details" value="<?php echo $missing_items_charges_details; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Charges for Missing Items </label>
									<input class="form-control" name="missing_items_charges" value="<?php echo $missing_items_charges; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Type of Payment </label>
									<select name="missing_items_charges_payment_type" class="form-control">
										<option value='Cash' <?php echo vali_iif('Cash' == $missing_items_charges_payment_type, 'Selected', ''); ?>>Cash</option>
										<option value='Online' <?php echo vali_iif('Online' == $missing_items_charges_payment_type, 'Selected', ''); ?>>Online</option>
										<option value='Card' <?php echo vali_iif('Card' == $missing_items_charges_payment_type, 'Selected', ''); ?>>Card</option>
									</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Additional Cost Details</label>
									<input class="form-control" name="additional_cost_details" value="<?php echo $additional_cost_details; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Additional Cost</label>
									<input class="form-control" name="additional_cost" value="<?php echo $additional_cost; ?>">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Type of Payment </label>
									<select name="additional_cost_payment_type" class="form-control">
										<option value='Cash' <?php echo vali_iif('Cash' == $additional_cost_payment_type, 'Selected', ''); ?>>Cash</option>
										<option value='Online' <?php echo vali_iif('Online' == $additional_cost_payment_type, 'Selected', ''); ?>>Online</option>
										<option value='Card' <?php echo vali_iif('Card' == $additional_cost_payment_type, 'Selected', ''); ?>>Card</option>
									</select>
								</div>
							</div>
						</div>

					</div>

					<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Start Engine</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="start_engine" <?php echo vali_iif('Y' == $start_engine, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">No Alarm</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="no_alarm" <?php echo vali_iif('Y' == $no_alarm, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Air Conditioner</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="air_conditioner" <?php echo vali_iif('Y' == $air_conditioner, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Radio</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="radio" <?php echo vali_iif('Y' == $radio, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Power Window</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="power_window" <?php echo vali_iif('Y' == $power_window, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Window Condition</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="window_condition" <?php echo vali_iif('Y' == $window_condition, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Perfume</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="perfume" <?php echo vali_iif('Y' == $perfume, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Carpet (RM20/pcs)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="carpet" <?php echo vali_iif('Y' == $carpet, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Sticker P (RM5)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="sticker" <?php echo vali_iif('Y' == $sticker, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
				</div>

					<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Lamp</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="lamp" <?php echo vali_iif('Y' == $lamp, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Engine Condition</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="engine_condition" <?php echo vali_iif('Y' == $engine_condition, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Tyres Condition</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="tyres_condition" <?php echo vali_iif('Y' == $tyres_condition, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					</div>

					<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Jack (RM70)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="jack" <?php echo vali_iif('Y' == $jack, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Tools (RM30)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="tools" <?php echo vali_iif('Y' == $tools, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Signage (RM30)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="signage" <?php echo vali_iif('Y' == $signage, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					</div>

					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Child Seat</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="child_seat" <?php echo vali_iif('Y' == $child_seat, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Wiper</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="wiper" <?php echo vali_iif('Y' == $wiper, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">GPS</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="gps" <?php echo vali_iif('Y' == $gps, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Tyre Spare(RM200)</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="tyre_spare" <?php echo vali_iif('Y' == $tyre_spare, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
									<div class="form-check">
										<label class="control-label">USB Charger(RM50)</label>
											<div class="checkbox">
												<label>
													<input type="checkbox" value="Y" name="usb_charger" <?php echo vali_iif('Y' == $usb_charger, 'Checked', ''); ?>> &nbsp;
												</label>
											</div>
									</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
									<div class="form-check">
										<label class="control-label">Touch n Go(RM50)</label>
											<div class="checkbox">
												<label>
													<input type="checkbox" value="Y" name="touch_n_go" <?php echo vali_iif('Y' == $touch_n_go, 'Checked', ''); ?>> &nbsp;
												</label>
											</div>
									</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
									<div class="form-check">
										<label class="control-label">Smart Tag(RM150)</label>
											<div class="checkbox">
												<label>
													<input type="checkbox" value="Y" name="smart_tag" <?php echo vali_iif('Y' == $smart_tag, 'Checked', ''); ?>> &nbsp;
												</label>
											</div>
									</div>
							</div>
						</div>
					</div>
					
					<div class="color-background">
						<div class="row">
							<div class="col-md-4">
								<label class="control-label">Car Seat Condition</label>
								<select name="car_seat_condition" class="form-control">
                                    <option value='Clean' <?php echo vali_iif('Clean' == $car_seat_condition, 'Selected', ''); ?>>Clean</option>
                                    <option value='Dirty' <?php echo vali_iif('Dirty' == $car_seat_condition, 'Selected', ''); ?>>Dirty</option>
                                    <option value='1 Cigarettes Bud' <?php echo vali_iif('1 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>1 Cigarettes Bud</option>
                                    <option value='2 Cigarettes Bud' <?php echo vali_iif('2 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>2 Cigarettes Bud</option>
                                    <option value='3 Cigarettes Bud' <?php echo vali_iif('3 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>3 Cigarettes Bud</option>
                                    <option value='4 Cigarettes Bud' <?php echo vali_iif('4 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>4 Cigarettes Bud</option>
                                    <option value='5 Cigarettes Bud' <?php echo vali_iif('5 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>5 Cigarettes Bud</option>
								</select>
							</div>
							<div class="col-md-4">
								<label class="control-label">Cleanliness</label>
								<select name="cleanliness" class="form-control">
                                    <option value='Clean' <?php echo vali_iif('Clean' == $cleanliness, 'Selected', ''); ?>>Clean</option>
                                    <option value='Dirty' <?php echo vali_iif('Dirty' == $cleanliness, 'Selected', ''); ?>>Dirty</option>
								</select>
							</div>
							<div class="col-md-4">
								<label class="control-label">Fuel Level</label>
								<select name="fuel_level" class="form-control">
                                    <option value='0' <?php echo vali_iif('0' == $fuel_level, 'Selected', ''); ?>>Empty</option>
                                    <option value='1' <?php echo vali_iif('1' == $fuel_level, 'Selected', ''); ?>>1 Bar</option>
                                    <option value='2' <?php echo vali_iif('2' == $fuel_level, 'Selected', ''); ?>>2 Bar</option>
                                    <option value='3' <?php echo vali_iif('3' == $fuel_level, 'Selected', ''); ?>>3 Bar</option>
                                    <option value='4' <?php echo vali_iif('4' == $fuel_level, 'Selected', ''); ?>>4 Bar</option>
                                    <option value='5' <?php echo vali_iif('5' == $fuel_level, 'Selected', ''); ?>>5 Bar</option>
                                    <option value='6' <?php echo vali_iif('6' == $fuel_level, 'Selected', ''); ?>>6 Bar</option>
								</select>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Remark</label>
									<input class="form-control" name="remark_return" value="<?php echo $remark_return; ?>">
								</div>
							</div>
						</div>

						<table>
                            <tbody>
                                <tr>
                                    <td>
									<br>
									<div class="form-check">
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="smart_tag" <?php echo vali_iif('Y' == $smart_tag, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
									</div>
                                    </td>
                                    <td>
										<div class="form-group">
											<label class="muted-text">
												I (Renter) received this car in <b>CLEAN</b> condition without any <b>FORBIDDEN STUFF</b> or <b>CRIMINAL ACTIVITY STUFF.</b>
											</label>
										</div>
									</td>
                                </tr>
							</tbody>
						</table>

					</div>

					<br>

					<div class="row">
						<div class="col-md-12">
							<center>
								<canvas id="canvas" class="img-responsive">canvas</canvas>
								<div class="form-group">
										<a type="button" class="btn btn-sm btn-info" id="addCircle">+ Broken</span></a>
										<a type="button" class="btn btn-sm btn-info" id="addEqual">+ Scratch</a>
										<a type="button" class="btn btn-sm btn-info" id="addRect">+ Missing</a>
										<a type="button" class="btn btn-sm btn-info" id="addTriangle">+ Dent</a>
								</div>
										<script type="text/javascript">
										var canvas = new fabric.Canvas('canvas');
										$("#addCircle").click(function(){
											canvas.add(new fabric.Circle({radius: 10, fill: '#000', left: 22, top: 10}));
											canvas.item(0).hasControls = false;
  											canvas.setActiveObject(canvas.item(0));
										});
										$("#addEqual").click(function(){
											canvas.add(new fabric.Text('=', { left: 20, top: 35, fill: '#000'}));
											canvas.item(1).hasControls = false;
  											canvas.setActiveObject(canvas.item(1));
										});
										$("#addRect").click(function(){
											canvas.add(new fabric.Rect({top: 75, left: 22, width: 18, height: 18, fill: '#000'}));
											canvas.item(2).hasControls = false;
  											canvas.setActiveObject(canvas.item(2));
										});
										$("#addTriangle").click(function(){
											canvas.add(new fabric.Triangle({top: 115, left: 22, width: 18, height: 18,fill: '#000'}));
											canvas.item(3).hasControls = false;
  											canvas.setActiveObject(canvas.item(3));
										});
								</script>
							</center>
							<input name="hidden_data" id='hidden_data' type="hidden"/>
							<script>
								function uploadEx() {
									var canvas = document.getElementById("canvas");
									var dataURL = canvas.toDataURL("image/png");
									document.getElementById('hidden_data').value = dataURL;
									var fd = new FormData(document.forms["modalIn"]);

									var xhr = new XMLHttpRequest();
									xhr.open('POST', 'reservation_list_view.php', true);
								
									xhr.upload.onprogress = function(e) {
										if (e.lengthComputable) {
											var percentComplete = (e.loaded / e.total) * 100;
											console.log(percentComplete + '% uploaded');
											alert('Succesfully uploaded');
										}
									};

									xhr.onload = function() {

									};
									xhr.send(fd);
								};
							</script>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<input class="form-control" name="username" value="<?php echo $name;?>" disabled>
							</div>
						</div>
					</div>

				</div>

				<div class="modal-footer">
					<div class="text-center">
						<button class="btn btn-success" name="btn_in" onClick="uploadEx()" value="upload" type="submit">Update</button>
					</div>
				</div>
				
				</div>
			</div>
			</div>
			</div>
			</form>
			<!-- Modal In -->
			
			<!-- Modal Out -->
			<form method="post" name="modalOut" enctype="multipart/form-data">
			<div class="modal fade" id="modalOut" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Pickup</h4>
				</div>
				<div class="modal-body">
					<div class="color-background">
						<div class="row">
						<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Change Vehicle</label>
									<select name="change_vehicle" class="form-control">
										<?php  $value = ""; $sql = "SELECT id, reg_no, make, model FROM vehicle WHERE  availability  = 'Available'"; 
										db_select($sql); 
										if(db_rowcount()>0){
											 for($j=0;$j<db_rowcount();$j++){ 
												 $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$change_vehicle,'Selected','').">".db_get($j,1)."&nbsp;".db_get($j,2)."&nbsp;".db_get($j,3)."</option>"; 
											}
										} echo $value; ?>
                                    </select>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Reason for Change Vehicle</label>
									<input class="form-control" name="reason_chg_car" value="<?php echo $reason_chg_car; ?>">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<div class="form-contol">
										<label class="control-label">Total Sale</label>
										<input class="form-control" name="total_sale">
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<div class="form-contol">
										<label class="control-label">Amount Collected</label>
										<input class="form-control" name="amount_collected" value="<?php echo $balance; ?>" disabled>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<div class="form-contol">
										<label class="control-label">Balance</label>
										<?php $total_balance = ($balance - $sub_total); ?> 
										<input class="form-control" name="balance" value="<?php echo $total_balance; ?>" disabled>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label">Type of Payment</label>
									<input class="form-control" name="payment">
								</div>
							</div>
						</div>
					</div>
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Start Engine</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="start_engine" <?php echo vali_iif('Y' == $start_engine, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>	
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">No Alarm</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="no_alarm" <?php echo vali_iif('Y' == $no_alarm, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Air Conditioner</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="air_conditioner" <?php echo vali_iif('Y' == $air_conditioner, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Radio</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="radio" <?php echo vali_iif('Y' == $radio, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Power Window</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="power_window" <?php echo vali_iif('Y' == $power_window, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Window Condition</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="window_condition" <?php echo vali_iif('Y' == $window_condition, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Perfume</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="perfume" <?php echo vali_iif('Y' == $perfume, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Carpet (RM20/pcs)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="carpet" <?php echo vali_iif('Y' == $carpet, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Sticker P (RM5)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="sticker" <?php echo vali_iif('Y' == $sticker, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
				</div>

					<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Lamp</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="lamp" <?php echo vali_iif('Y' == $lamp, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Engine Condition</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="engine_condition" <?php echo vali_iif('Y' == $engine_condition, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Tyres Condition</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="tyres_condition" <?php echo vali_iif('Y' == $tyres_condition, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					</div>

					<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Jack (RM70)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="jack" <?php echo vali_iif('Y' == $jack, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Tools (RM30)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="tools" <?php echo vali_iif('Y' == $tools, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<div class="form-check">
								<label class="control-label">Signage (RM30)</label>
                                	<div class="checkbox">
										<label>
											<input type="checkbox" value="Y" name="signage" <?php echo vali_iif('Y' == $signage, 'Checked', ''); ?>> &nbsp;
										</label>
									</div>
							</div>
						</div>
					</div>
					</div>

					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Child Seat</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="child_seat" <?php echo vali_iif('Y' == $child_seat, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Wiper</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="wiper" <?php echo vali_iif('Y' == $wiper, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">GPS</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="gps" <?php echo vali_iif('Y' == $gps, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<div class="form-check">
									<label class="control-label">Tyre Spare(RM200)</label>
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="tyre_spare" <?php echo vali_iif('Y' == $tyre_spare, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
									<div class="form-check">
										<label class="control-label">USB Charger(RM50)</label>
											<div class="checkbox">
												<label>
													<input type="checkbox" value="Y" name="usb_charger" <?php echo vali_iif('Y' == $usb_charger, 'Checked', ''); ?>> &nbsp;
												</label>
											</div>
									</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
									<div class="form-check">
										<label class="control-label">Touch n Go(RM50)</label>
											<div class="checkbox">
												<label>
													<input type="checkbox" value="Y" name="touch_n_go" <?php echo vali_iif('Y' == $touch_n_go, 'Checked', ''); ?>> &nbsp;
												</label>
											</div>
									</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
									<div class="form-check">
										<label class="control-label">Smart Tag(RM150)</label>
											<div class="checkbox">
												<label>
													<input type="checkbox" value="Y" name="smart_tag" <?php echo vali_iif('Y' == $smart_tag, 'Checked', ''); ?>> &nbsp;
												</label>
											</div>
									</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="control-label">Car Images</label>
							</div>
						</div>
						<center>
							<div class="small">
								<div class="col-md-6">
									<input class="btn btn-default" type="file" name="files[]" multiple/>
								</div>
								<div class="col-md-6">
									<input class="btn btn-default" type="file" name="files[]" multiple/>
								</div>
								<div class="col-md-6">
									<input class="btn btn-default" type="file" name="files[]" multiple/>
								</div>
								<div class="col-md-6">
									<input class="btn btn-default" type="file" name="files[]" multiple/>
								</div>
								<div class="col-md-6">
									<input class="btn btn-default" type="file" name="files[]" multiple/>
								</div>
								<div class="col-md-6">
									<input class="btn btn-default" type="file" name="files[]" multiple/>
								</div>
							</div>
						</center>
					</div>

					<br>

					<div class="color-background">
						<div class="row">
						<div class="col-md-4">
								<label class="control-label">Car Seat Condition</label>
								<select name="car_seat_condition" class="form-control">
                                    <option value='Clean' <?php echo vali_iif('Clean' == $car_seat_condition, 'Selected', ''); ?>>Clean</option>
                                    <option value='Dirty' <?php echo vali_iif('Dirty' == $car_seat_condition, 'Selected', ''); ?>>Dirty</option>
                                    <option value='1 Cigarettes Bud' <?php echo vali_iif('1 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>1 Cigarettes Bud</option>
                                    <option value='2 Cigarettes Bud' <?php echo vali_iif('2 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>2 Cigarettes Bud</option>
                                    <option value='3 Cigarettes Bud' <?php echo vali_iif('3 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>3 Cigarettes Bud</option>
                                    <option value='4 Cigarettes Bud' <?php echo vali_iif('4 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>4 Cigarettes Bud</option>
                                    <option value='5 Cigarettes Bud' <?php echo vali_iif('5 Cigarettes Bud' == $car_seat_condition, 'Selected', ''); ?>>5 Cigarettes Bud</option>
								</select>
							</div>
							<div class="col-md-4">
								<label class="control-label">Cleanliness</label>
								<select name="cleanliness" class="form-control">
                                    <option value='Clean' <?php echo vali_iif('Clean' == $cleanliness, 'Selected', ''); ?>>Clean</option>
                                    <option value='Dirty' <?php echo vali_iif('Dirty' == $cleanliness, 'Selected', ''); ?>>Dirty</option>
								</select>
							</div>
							<div class="col-md-4">
								<label class="control-label">Fuel Level</label>
								<select name="fuel_level" class="form-control">
                                    <option value='0' <?php echo vali_iif('0' == $fuel_level, 'Selected', ''); ?>>Empty</option>
                                    <option value='1' <?php echo vali_iif('1' == $fuel_level, 'Selected', ''); ?>>1 Bar</option>
                                    <option value='2' <?php echo vali_iif('2' == $fuel_level, 'Selected', ''); ?>>2 Bar</option>
                                    <option value='3' <?php echo vali_iif('3' == $fuel_level, 'Selected', ''); ?>>3 Bar</option>
                                    <option value='4' <?php echo vali_iif('4' == $fuel_level, 'Selected', ''); ?>>4 Bar</option>
                                    <option value='5' <?php echo vali_iif('5' == $fuel_level, 'Selected', ''); ?>>5 Bar</option>
                                    <option value='6' <?php echo vali_iif('6' == $fuel_level, 'Selected', ''); ?>>6 Bar</option>
								</select>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Remark</label>
									<input class="form-control" name="remark_pickup" value="<?php echo $remark_pickup; ?>">
								</div>
							</div>
						</div>

						<table>
                            <tbody>
                                <tr>
                                    <td>
									<br>
									<div class="form-check">
										<div class="checkbox">
											<label>
												<input type="checkbox" value="Y" name="smart_tag" <?php echo vali_iif('Y' == $smart_tag, 'Checked', ''); ?>> &nbsp;
											</label>
										</div>
									</div>
                                    </td>
                                    <td>
										<div class="form-group">
											<label class="muted-text">
												I (Renter) received this car in <b>CLEAN</b> condition without any <b>FORBIDDEN STUFF</b> or <b>CRIMINAL ACTIVITY STUFF.</b>
											</label>
										</div>
									</td>
                                </tr>
							</tbody>
						</table>
					
					</div>

					<br>

					<div class="row">
						<div class="col-md-12" id="canvas-holder2">
							<center>
								<canvas id="board" class="img-responsive">canvas</canvas>
								<div class="form-group">
										<a type="button" class="btn btn-sm btn-info" id="addCircles">+ Broken</span></a>
										<a type="button" class="btn btn-sm btn-info" id="addEquals">+ Scratch</a>
										<a type="button" class="btn btn-sm btn-info" id="addRects">+ Missing</a>
										<a type="button" class="btn btn-sm btn-info" id="addTriangles">+ Dent</a>
								</div>
								<script type="text/javascript">
										var board = new fabric.Canvas('board');
										$("#addCircles").click(function(){
											board.add(new fabric.Circle({radius: 10, fill: '#000', left: 22, top: 10}));
											board.item(0).hasControls = false;
											board.setActiveObject(board.item(0));
										});
										$("#addEquals").click(function(){
											board.add(new fabric.Text('=', { left: 20, top: 35, fill: '#000'}));
											board.item(1).hasControls = false;
											board.setActiveObject(board.item(1));
										});
										$("#addRects").click(function(){
											board.add(new fabric.Rect({top: 75, left: 22, width: 18, height: 18, fill: '#000'}));
											board.item(2).hasControls = false;
											board.setActiveObject(board.item(2));
										});
										$("#addTriangles").click(function(){
											board.add(new fabric.Triangle({top: 115, left: 22, width: 18, height: 18,fill: '#000'}));
											board.item(3).hasControls = false;
											board.setActiveObject(board.item(3));
										});
								</script>
							</center>
							<div>
							<input name="hidden_datas" id='hidden_datas' type="hidden"/>
							<script>
								function upload() {
									var board = document.getElementById("board");
									var dataURL = board.toDataURL("image/png");
									document.getElementById('hidden_datas').value = dataURL;
									var fd = new FormData(document.forms["modalOut"]);

									var xhr = new XMLHttpRequest();
									xhr.open('POST', 'reservation_list_view.php', true);
								
									xhr.upload.onprogress = function(e) {
										if (e.lengthComputable) {
											var percentComplete = (e.loaded / e.total) * 100;
											console.log(percentComplete + '% uploaded');
											alert('Succesfully uploaded');
										}
									};

									xhr.onload = function() {

									};
									xhr.send(fd);
								};
							</script>
						</div>
					</div>

					<div class="col-md-12">
						<div class="form-group">
							<input class="form-control" name="username" value="<?php echo $name;?>" disabled>
						</div>
					</div>
				</div>

				<div class="modal-footer">
					<div class="text-center">
						<button class="btn btn-success" name="btn_out" onClick="upload()" value="upload" type="submit">Update</button>
					</div>
				</div>
			</div>
			</div>
			</div>
			</div>
			</form>
			<!-- Modal Out -->

			<!-- Modal Extend-->
			<form method="post">
			<div class="modal fade" id="modalExtend" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Extend</h4>
				</div>
				<div class="modal-body">
				<div class="row">
					<div class="col-md-3">
						<div class="form-group">
							<label class="control-label">Extend from Date</label>
							<input type="text" class="form-control" id="extend_from_date" name="extend_from_date" value="<?php echo $extend_from_date; ?>">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<label class="control-label">Extend from Time</label>
							<select name="extend_from_time" class="form-control">
										<option value="00:00">00.00</option>
										<option value="00:30">00.30</option>
										<option value="01:00">01.00</option>
										<option value="01:30">01.30</option>
										<option value="02:00">02.00</option>
										<option value="02:30">02.30</option>
										<option value="03:00">03.00</option>
										<option value="03:30">03.30</option>
										<option value="04:00">04.00</option>
										<option value="04:30">04.30</option>
										<option value="05:00">05.00</option>
										<option value="05:30">05.30</option>
										<option value="06:00">06.00</option>
										<option value="06:30">06.30</option>
										<option value="07:00">07.00</option>
										<option value="07:30">07.30</option>
										<option value="08:00">08.00</option>
										<option value="08:30">08.30</option>
										<option value="09:00">09.00</option>
										<option value="09:30">09.30</option>
										<option value="10:00">10.00</option>
										<option value="10:30">10.30</option>
										<option value="11:00">11.00</option>
										<option value="11:30">11.30</option>
										<option selected="" value="12:00">12.00</option>
										<option value="12:30">12.30</option>
										<option value="13:00">13.00</option>
										<option value="13:30">13.30</option>
										<option value="14:00">14.00</option>
										<option value="14:30">14.30</option>
										<option value="15:00">15.00</option>
										<option value="15:30">15.30</option>
										<option value="16:00">16.00</option>
										<option value="16:30">16.30</option>
										<option value="17:00">17.00</option>
										<option value="17:30">17.30</option>
										<option value="18:00">18.00</option>
										<option value="18:30">18.30</option>
										<option value="19:00">19.00</option>
										<option value="19:30">19.30</option>
										<option value="20:00">20.00</option>
										<option value="20:30">20.30</option>
										<option value="21:00">21.00</option>
										<option value="21:30">21.30</option>
										<option value="22:00">22.00</option>
										<option value="22:30">22.30</option>
										<option value="23:00">23.00</option>
										<option value="23:30">23.30</option>
									</select>
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<label class="control-label">Extend to Date</label>
							<input type="text" class="form-control" id="extend_to_date" name="extend_to_date" value="<?php echo $extend_to_date; ?>">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<label class="control-label">Extend to Time</label>
							<select name="extend_to_time" class="form-control">
										<option value="00:00">00.00</option>
										<option value="00:30">00.30</option>
										<option value="01:00">01.00</option>
										<option value="01:30">01.30</option>
										<option value="02:00">02.00</option>
										<option value="02:30">02.30</option>
										<option value="03:00">03.00</option>
										<option value="03:30">03.30</option>
										<option value="04:00">04.00</option>
										<option value="04:30">04.30</option>
										<option value="05:00">05.00</option>
										<option value="05:30">05.30</option>
										<option value="06:00">06.00</option>
										<option value="06:30">06.30</option>
										<option value="07:00">07.00</option>
										<option value="07:30">07.30</option>
										<option value="08:00">08.00</option>
										<option value="08:30">08.30</option>
										<option value="09:00">09.00</option>
										<option value="09:30">09.30</option>
										<option value="10:00">10.00</option>
										<option value="10:30">10.30</option>
										<option value="11:00">11.00</option>
										<option value="11:30">11.30</option>
										<option selected="" value="12:00">12.00</option>
										<option value="12:30">12.30</option>
										<option value="13:00">13.00</option>
										<option value="13:30">13.30</option>
										<option value="14:00">14.00</option>
										<option value="14:30">14.30</option>
										<option value="15:00">15.00</option>
										<option value="15:30">15.30</option>
										<option value="16:00">16.00</option>
										<option value="16:30">16.30</option>
										<option value="17:00">17.00</option>
										<option value="17:30">17.30</option>
										<option value="18:00">18.00</option>
										<option value="18:30">18.30</option>
										<option value="19:00">19.00</option>
										<option value="19:30">19.30</option>
										<option value="20:00">20.00</option>
										<option value="20:30">20.30</option>
										<option value="21:00">21.00</option>
										<option value="21:30">21.30</option>
										<option value="22:00">22.00</option>
										<option value="22:30">22.30</option>
										<option value="23:00">23.00</option>
										<option value="23:30">23.30</option>
									</select>
						</div>
					</div>
				</div>	

				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
						<label class="control-label">Payment Status</label>
						<select name="payment_status" class="form-control">
							<option value='Collect' <?php echo vali_iif('Collect' == $payment_status, 'Selected', ''); ?>>Collect</option>
                            <option value='Paid' <?php echo vali_iif('Paid' == $payment_status, 'Selected', ''); ?>>Paid</option>
						</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
						<label class="control-label">Payment Type</label>
						<select name="payment_type" class="form-control">
							<option value='Cash' <?php echo vali_iif('Cash' == $payment_type, 'Selected', ''); ?>>Cash</option>
                            <option value='Online' <?php echo vali_iif('Online' == $payment_type, 'Selected', ''); ?>>Online</option>
                            <option value='Cheque' <?php echo vali_iif('Cheque' == $payment_type, 'Selected', ''); ?>>Cheque</option>
                            <option value='Credit / Debit' <?php echo vali_iif('Credit / Debit' == $payment_type, 'Selected', ''); ?>>Credit / Debit</option>
						</select>
						</div>
					</div>
					<!-- <div class="col-md-4">
						<div class="form-group">
						<label class="control-label">Price</label>
						<input type="text" class="form-control" name="price" value="<?php echo $price; ?>">
						</div>
					</div> -->
				</div>
				<div class="modal-footer">
					<button class="btn btn-success" name="btn_extend" type="submit">Update</button>
				</div>
				</div>
			</div>
			</div>
			</div>
			</form>
			<!-- Modal Extend-->

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card card-nav-tabs">
				<div class="card-header" data-background-color="blue">
                <div class="nav-tabs-navigation">
			<div class="nav-tabs-wrapper">
				<ul class="nav nav-tabs">
					<li class="">
						<a href="agreement.php?id=<?php echo $_GET['id']; ?>" target="_blank">
							<i class="material-icons">assignment</i>
							Agreement
						<div class="ripple-container"></div></a>
					</li>
					<li class="">
						<a href="#messages" data-toggle="modal" data-target="#modalOut">
							<i class="material-icons">call_received</i>
							Pickup
						<div class="ripple-container"></div></a>
					</li>
                    <li class="">
						<a href="#" data-toggle="modal" data-target="#modalIn">
							<i class="material-icons">call_made</i>
							Return
						<div class="ripple-container"></div></a>
					</li>
					<li class="">
						<a href="returnreceipt.php?id=<?php echo $_GET['id']; ?>" target="_blank">
							<i class="material-icons">description</i>
							Return Receipt
						<div class="ripple-container"></div></a>
					</li>
					<li class="">
						<a href="#messages" data-toggle="modal" data-target="#modalExtend">
							<i class="material-icons">exit_to_app</i>
							Extend
						<div class="ripple-container"></div></a>
					</li>
				</ul>
			</div>
		</div>
	</div>

	<?php
	$sql = "SELECT
	vehicle.id AS vehicle_id,
	DATE_FORMAT(pickup_date, '%d/%m/%Y') as pickup_date,
	DATE_FORMAT(pickup_time, '%H:%i:%s') as pickup_time,
	CASE pickup_location WHEN '4' THEN 'Port Dickson' WHEN '5' THEN 'Seremban' END AS pickup_location,
	DATE_FORMAT(return_date, '%d/%m/%Y') as return_date,
	DATE_FORMAT(return_time, '%H:%i:%s') as return_time,
	CASE return_location WHEN '4' THEN 'Port Dickson' WHEN '5' THEN 'Seremban' END AS return_location,
	concat(firstname,' ' ,lastname) AS fullname,
	concat(make, ' ', model) AS car,
	reg_no,
	nric_no,
	address,
	phone_no,
	email,
	license_no,
	sub_total,
	refund_dep,
	car_in_image,
	car_in_start_engine,
	car_in_no_alarm,
	car_in_air_conditioner,
	car_in_radio,
	car_in_power_window,
	car_in_window_condition,
	car_in_perfume,
	car_in_carpet,
	car_in_sticker_p,
	car_in_lamp,
	car_in_engine_condition,
	car_in_tyres_condition,
	car_in_jack,
	car_in_tools,
	car_in_signage,
	car_in_child_seat,
	car_in_wiper,
	car_in_gps,
	car_in_tyre_spare,
	car_in_usb_charger,
	car_in_touch_n_go,
	car_in_smart_tag,
	car_in_seat_condition,
	car_in_cleanliness,
	car_in_fuel_level,
	car_in_remark,
	car_out_image,
	car_out_start_engine,
	car_out_no_alarm,
	car_out_air_conditioner,
	car_out_radio,
	car_out_power_window,
	car_out_window_condition,
	car_out_perfume,
	car_out_carpet,
	car_out_sticker_p,
	car_out_lamp,
	car_out_engine_condition,
	car_out_tyres_condition,
	car_out_jack,
	car_out_tools,
	car_out_signage,
	car_out_child_seat,
	car_out_wiper,
	car_out_gps,
	car_out_tyre_spare,
	car_out_usb_charger,
	car_out_touch_n_go,
	car_out_smart_tag,
	car_out_seat_condition,
	car_out_cleanliness,
	car_out_fuel_level,
	car_out_remark,
	agreement_no
	FROM customer
	JOIN booking_trans ON customer.id = customer_id 
	JOIN vehicle ON vehicle_id = vehicle.id
	JOIN checklist ON booking_trans_id = booking_trans.id
	WHERE booking_trans.id=".$_GET['id'];
	//echo $sql;
	db_select($sql);
	if (db_rowcount() > 0) {
	func_setSelectVar();
	}
	?>
            <div class="card-content">
               <div class="row">
                    <div class="col-md-4">
                        <?php echo "<img src='assets/img/$company_image'>"; ?>
                    </div>
                    <div class="col-md-4">
                          <div class="form-group">
							<div class="row">
								<h4><?php echo $company_name; ?></h4>
								<p><?php echo $website_name; ?></p>
								<p><?php echo $company_address; ?></p>
								<p><?php echo $company_phone_no; ?></p>
								<p><?php echo $registration_no; ?></p>
							</div>
                          </div>
                    </div>
                    <div class="col-md-4">
                           <div class="form-group">
                                <label class="label-control">Reference Number</labe;>
                                <p><input class="form-control" type="text" name="refno" value="<?php echo $agreement_no;?>"></p>
                           </div>
                    </div>
               </div>

			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<center>
						<div class="alert alert-info" role="alert">
							<b>Customer Information</b>
						</div>
						</center>
					</div>
				</div>
			</div>

			   <div class="row">
					<div class="col-md-4">
					<div class="form-group">
							<label class="contorl-label">Name</label>
							<input class="form-control" value="<?php echo $fullname; ?>" disabled>
						</div>
					</div>
					<div class="col-md-4">
					<div class="form-group">
							<label class="contorl-label">NRIC</label>
							<input class="form-control" value="<?php echo $nric_no; ?>" disabled>
						</div>
					</div>
					<div class="col-md-4">
					<div class="form-group">
							<label class="contorl-label">Driving License</label>
							<input class="form-control" value="<?php echo $license_no; ?>" disabled>
						</div>
					</div>
			   </div>

			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Address</label>
						<input class="form-control" value="<?php echo $address; ?>" disabled>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Phone No</label>
						<input class="form-control" value="<?php echo $phone_no; ?>" disabled>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Email</label>
						<input class="form-control" value="<?php echo $email; ?>" disabled>
					</div>
				</div>
			</div>	

			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<center>
						<div class="alert alert-info" role="alert">
							<b>Payment Information</b>
						</div>
						</center>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label class="contorl-label">Amount</label>
						<input class="form-control" value="<?php echo $sub_total; ?>" disabled>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="contorl-label">Deposit</label>
						<input class="form-control" value="<?php echo $refund_dep; ?>" disabled>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<center>
						<div class="alert alert-info" role="alert">
							<b>Vehicle Information</b>
						</div>
						</center>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label class="contorl-label">Model</label>
						<input class="form-control" value="<?php echo $car; ?>" disabled>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="contorl-label">Register Number</label>
						<input class="form-control" value="<?php echo $reg_no; ?>" disabled>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Pickup Date</label>
						<input class="form-control" value="<?php echo $pickup_date; ?>" disabled>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Pickup Time</label>
						<input class="form-control" value="<?php echo $pickup_time; ?>" disabled>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Pickup Location</label>
						<input class="form-control" value="<?php echo $pickup_location; ?>" disabled>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Return Date</label>
						<input class="form-control" value="<?php echo $return_date; ?>" disabled>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Return Time</label>
						<input class="form-control" value="<?php echo $return_time; ?>" disabled>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="contorl-label">Return Location</label>
						<input class="form-control" value="<?php echo $return_location; ?>" disabled>
					</div>
				</div>
			</div>

				<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<center>
						<div class="alert alert-info" role="alert">
							<b>Extend Information</b>
						</div>
						</center>
					</div>
				</div>
			</div>

			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>Number</th>
							<th>Extend Date</th>
							<th>Payment Status</th>
							<th>Payment Type</th>
							<th>Payment Date</th>
							<th>Payment Price</th>
						</tr>
					</thead>
					<tbody>
					<?php
			
					$sql= "SELECT 
					DATE_FORMAT(extend_from_date, '%d/%m/%Y'),
					DATE_FORMAT(extend_from_time, '%H:%i'), 
					DATE_FORMAT(extend_to_date, '%d/%m/%Y') AS extend_to_date,
					DATE_FORMAT(extend_to_time, '%H:%i'),
					payment_status,
					payment_type,
					DATE_FORMAT(c_date, '%d/%m/%Y'),
					price
					FROM extend
					WHERE booking_trans_id=".$_GET['id'];
					
					//echo $sql;
					db_select($sql); 
					if (db_rowcount() > 0) { 
						for ($i = 0; $i < db_rowcount(); $i++) { 
							$status = ""; if (func_getOffset() >= 10) {
								$no = func_getOffset() + 1 + $i; 
								} else { 
									$no = $i + 1; 
								}

					echo "
						<tr>
							<td>$no</td>
							<td>".db_get($i,0)." @ ".db_get($i,1)." - ".db_get($i,2)." @ ".db_get($i,3)."</td>
							<td>".db_get($i,4)."</td>
							<td>".db_get($i,5)."</td>
							<td>".db_get($i,6)."</td>
							<td>RM ".db_get($i,7)."</td>
						</tr>";
					
						}
					}
					?>
				
					</tbody>
					</thead>
				</table>
			</div>

			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<center>
						<div class="alert alert-info" role="alert">
							<b>Vehicle Checklist</b>
						</div>
						</center>
					</div>
				</div>
			</div>

			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>Checklist</th>
							<th>Pickup</th>
							<th>Return</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Start Engine</td>
							<td><?php echo $car_out_start_engine; ?></td>
							<td><?php echo $car_in_start_engine; ?></td>
						</tr>
						<tr>
							<td>No Alarm</td>
							<td><?php echo $car_out_no_alarm; ?></td>
							<td><?php echo $car_in_no_alarm; ?></td>
						</tr>
						<tr>
							<td>Wiper</td>
							<td><?php echo $car_out_wiper; ?></td>
							<td><?php echo $car_in_wiper; ?></td>
						</tr>
						<tr>
							<td>Air Conditioner</td>
							<td><?php echo $car_out_air_conditioner; ?></td>
							<td><?php echo $car_in_air_conditioner; ?></td>
						</tr>
						<tr>
							<td>Radio</td>
							<td><?php echo $car_out_radio; ?></td>
							<td><?php echo $car_in_radio; ?></td>
						</tr>
						<tr>
							<td>Power Window</td>
							<td><?php echo $car_out_power_window; ?></td>
							<td><?php echo $car_in_power_window; ?></td>
						</tr>
						<tr>
							<td>Perfumed</td>
							<td><?php echo $car_out_perfume; ?></td>
							<td><?php echo $car_in_perfume; ?></td>
						</tr>
						<tr>
							<td>Carpet</td>
							<td><?php echo $car_out_carpet; ?></td>
							<td><?php echo $car_in_carpet; ?></td>
						</tr>
						<tr>
							<td>Lamp</td>
							<td><?php echo $car_out_lamp; ?></td>
							<td><?php echo $car_in_lamp; ?></td>
						</tr>
						<tr>
							<td>Engine Condition</td>
							<td><?php echo $car_out_engine_condition; ?></td>
							<td><?php echo $car_in_engine_condition; ?></td>
						</tr>
						<tr>
							<td>Tyres Condition</td>
							<td><?php echo $car_out_tyres_condition; ?></td>
							<td><?php echo $car_in_tyres_condition; ?></td>

						</tr>
						<tr>
							<td>Jack</td>
							<td><?php echo $car_out_jack; ?></td>
							<td><?php echo $car_in_jack; ?></td>
						</tr>
						<tr>
							<td>Tools</td>
							<td><?php echo $car_out_tools; ?></td>
							<td><?php echo $car_in_tools; ?></td>
						</tr>
						<tr>
							<td>Signage</td>
							<td><?php echo $car_out_signage; ?></td>
							<td><?php echo $car_in_signage; ?></td>
						</tr>
						<tr>
							<td>Tyre Spare</td>
							<td><?php echo $car_out_tyre_spare; ?></td>
							<td><?php echo $car_in_tyre_spare; ?></td>
						</tr>
						<tr>
							<td>Sticker P</td>
							<td><?php echo $car_out_sticker_p; ?></td>
							<td><?php echo $car_in_sticker_p; ?></td>
						</tr>
						<tr>
							<td>USB Charger</td>
							<td><?php echo $car_out_usb_charger; ?></td>
							<td><?php echo $car_in_usb_charger; ?></td>
						</tr>
						<tr>
							<td>Touch N Go</td>
							<td><?php echo $car_out_touch_n_go; ?></td>
							<td><?php echo $car_in_touch_n_go; ?></td>
						</tr>
						<tr>
							<td>SmartTag</td>
							<td><?php echo $car_out_smart_tag; ?></td>
							<td><?php echo $car_in_smart_tag; ?></td>
						</tr>
						<tr>
							<td>Child Seat</td>
							<td><?php echo $car_out_child_seat; ?></td>
							<td><?php echo $car_in_child_seat; ?></td>
						</tr>
						<tr>
							<td>GPS</td>
							<td><?php echo $car_out_gps; ?></td>
							<td><?php echo $car_in_gps; ?></td>
						</tr>
					</tbody>
				</table>
			</div>

            </div>

            </div>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php'); ?>

	<script>
        $(document).ready(function () {
            var date_input = $('input[name="extend_from_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>

    <script>
        $(document).ready(function () {
            var date_input = $('input[name="extend_to_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>


