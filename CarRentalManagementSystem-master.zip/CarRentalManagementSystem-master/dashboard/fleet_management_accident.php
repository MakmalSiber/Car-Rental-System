<?php  include('_header.php'); func_setReqVar(); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" data-background-color="red">
                        <h4 class="title">Accident</h4>
                    </div>
                    <div class="card-content">
                        <form>

                            <div class="form-group">
                                <label class="control-label">Vehicle</label>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="search_vehicle" <?php echo $disabled;?>>
                                    <?php  $value = ""; $sql = "SELECT id, reg_no, model, year from vehicle"; db_select($sql); if(db_rowcount()>0){ for($j=0;$j<db_rowcount();$j++){ $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$search_vehicle,'Selected','').">
								".db_get($j,1)." : ".db_get($j,2). " (" .db_get($j,3). ")</option>"; } } echo $value; ?>
                                </select>
                            </div>

                            <div class="form-group text-center">
                                <div>
                                    <button type="submit" class="btn btn-success" name="btn_search">Search</button>
                                </div>


                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Number</th>
                                                <th>Vehicle</th>
                                                <th>Car Status</th>
                                                <th>Accident Date</th>
                                                <th>PIC (Police/Workshop)</th>
                                                <th>Car Location</th>
                                                <th>Accident Image</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
 func_setPage(); func_setOffset(); func_setLimit(10); if(isset($btn_search)){ if($search_vehicle!=""){ $where=" AND vehicle_id = '".$search_vehicle."'"; } } $sql = "SELECT 
							reg_no,
							model, 
							year, 
							DATE_FORMAT(accident_date, '%d/%m/%Y'), 
							pic, 
							car_location, 
							car_status, 
							fleet_accident.id, 
							accident_image 
							FROM fleet_accident 
							LEFT JOIN vehicle ON vehicle.id = vehicle_id 
							WHERE fleet_accident.id is not NULL " .$where; db_select($sql); func_setTotalPage(db_rowcount()); db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset()); if(db_rowcount()>0){ for($i=0;$i<db_rowcount();$i++){ if(func_getOffset()>=10){ $no=func_getOffset()+1+$i; }else{ $no=$i+1; } echo "<tr>
									<td>".$no."</td>
									<td>".db_get($i,1)." : ".db_get($i,2)." (".db_get($i,3).")</td>
									<td>".db_get($i,6)."</td>
									<td>".db_get($i,3)."</td>
									<td>".db_get($i,4)."</td>
									<td>".db_get($i,5)."</td>
									<td><a class='fancybox' href='#".db_get($i,7)."'><i class='icon-magnifier'></i></a></td>
									<td><a href='fleet_management_accident_edit.php?id=".db_get($i,7)."&search_vehicle=".$search_vehicle."'><i class='material-icons'>mode_edit</i></a></td>
									<td style='display:none'>				
											<div id='".db_get($i,7)."' style='display:none;width:800px' class='card__body'>
												<img src='img/".db_get($i,8)."'>
											</div>
										</td>
								</tr>"; } }else{ echo "<tr><td colspan='8'>No records found</td></tr>"; } ?>
                                                <tr>
                                                    <td colspan="8" align="center">
                                                        <div class="form-group">
                                                            <button type="button" class="btn btn-info" name="btn_save" onclick="location.href='fleet_management_accident_new.php?btn_search=&search_vehicle=<?php echo $search_vehicle;?>&page=<?php echo $page;?>'">Add New</button>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="8" style="text-align:center">
                                                        <?php  func_getPaging('fleet_management_accident.php?x&search_vehicle='.$search_vehicle); ?>
                                                    </td>
                                                </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>