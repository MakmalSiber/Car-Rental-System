<!-- <div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<input class="form-control" name="username" value="<?php echo $name;?>" disabled>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<center>
							<canvas id="return_sign" class="img-responsive"></canvas>
							</center>
							<script>
							var canvas;

							$(function () {
								signature = window._signature = new fabric.Canvas('return_sign');
								signature.isDrawingMode= 1;
								signature.freeDrawingBrush.color = "#000";
								signature.freeDrawingBrush.width = 1;
								signature.renderAll();
								clearEl = $('clear-canvas');
  								clearEl.onclick = function() { canvas.clear() };
							});
							</script>
							<input name="f_sign" id='f_sign' type="hidden"/>
							<script>
								function uploadEx() {
									var signature = document.getElementById("return_sign");
									var dataURL = signature.toDataURL("image/png");
									document.getElementById('f_sign').value = dataURL;
									var fd = new FormData(document.forms["modalIn"]);

									var xhr = new XMLHttpRequest();
									xhr.open('POST', 'reservation_list_view.php', true);
								
									xhr.upload.onprogress = function(e) {
										if (e.lengthComputable) {
											var percentComplete = (e.loaded / e.total) * 100;
											console.log(percentComplete + '% uploaded');
											alert('Succesfully uploaded');
										}
									};

									xhr.onload = function() {

									};
									xhr.send(fd);
								};
							</script>
						</div>
					</div> -->
