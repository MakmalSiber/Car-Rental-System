<?php
include('_header.php');
func_setReqVar(); ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Counter Reservation</h4>
                </div>
            <div class="card-content">

			<form action="#" onsubmit="return validateForm()" name="myForm">
						<div class="form-group">
							<label class="control-label" style="text-align:left"><span style="color:red" id="err"><?php echo func_getErrMsg(); ?></span></label>
						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
								<label class="control-label">Pickup Date</label>
								<input type="text" autocomplete="off" class="form-control" id="search_pickup_date" name="search_pickup_date" value="<?php echo $search_pickup_date; ?>" onkeydown="return false">
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Pickup Time</label>
									<select name="search_pickup_time" class="form-control">
										<option value="00:00">00.00</option>
										<option value="00:30">00.30</option>
										<option value="01:00">01.00</option>
										<option value="01:30">01.30</option>
										<option value="02:00">02.00</option>
										<option value="02:30">02.30</option>
										<option value="03:00">03.00</option>
										<option value="03:30">03.30</option>
										<option value="04:00">04.00</option>
										<option value="04:30">04.30</option>
										<option value="05:00">05.00</option>
										<option value="05:30">05.30</option>
										<option value="06:00">06.00</option>
										<option value="06:30">06.30</option>
										<option value="07:00">07.00</option>
										<option value="07:30">07.30</option>
										<option value="08:00">08.00</option>
										<option value="08:30">08.30</option>
										<option value="09:00">09.00</option>
										<option value="09:30">09.30</option>
										<option value="10:00">10.00</option>
										<option value="10:30">10.30</option>
										<option value="11:00">11.00</option>
										<option value="11:30">11.30</option>
										<option selected="" value="12:00">12.00</option>
										<option value="12:30">12.30</option>
										<option value="13:00">13.00</option>
										<option value="13:30">13.30</option>
										<option value="14:00">14.00</option>
										<option value="14:30">14.30</option>
										<option value="15:00">15.00</option>
										<option value="15:30">15.30</option>
										<option value="16:00">16.00</option>
										<option value="16:30">16.30</option>
										<option value="17:00">17.00</option>
										<option value="17:30">17.30</option>
										<option value="18:00">18.00</option>
										<option value="18:30">18.30</option>
										<option value="19:00">19.00</option>
										<option value="19:30">19.30</option>
										<option value="20:00">20.00</option>
										<option value="20:30">20.30</option>
										<option value="21:00">21.00</option>
										<option value="21:30">21.30</option>
										<option value="22:00">22.00</option>
										<option value="22:30">22.30</option>
										<option value="23:00">23.00</option>
										<option value="23:30">23.30</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Pickup Location</label>
										<select class="form-control" name="search_pickup_location" <?php echo $disabled; ?>>
										<?php
									$value = "";
									$sql = "SELECT id, description FROM location WHERE status = 'A'";
									db_select($sql);
									if (db_rowcount() > 0) {
										for ($j = 0; $j < db_rowcount(); $j++) {
											$value = $value . "<option value=" . db_get($j, 0) . " " . vali_iif(db_get($j, 0) == $class_id, 'Selected', '') . ">" . db_get($j, 1) . "</option>";
										}
									}
									echo $value;
									?>
										</select>
									</div>
								</div>
							</div>

							<div class="row">
							<div class="col-md-4">
									<div class="form-group">
										<label class="control-label">Return Date</label>
										<input type="text" autocomplete="off" class="form-control" id="search_return_date" name="search_return_date" value="<?php echo $search_return_date; ?>" onkeydown="return false">
									</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Return Time</label>
									<select name="search_return_time" class="form-control">
										<option value="00:00">00.00</option>
										<option value="00:30">00.30</option>
										<option value="01:00">01.00</option>
										<option value="01:30">01.30</option>
										<option value="02:00">02.00</option>
										<option value="02:30">02.30</option>
										<option value="03:00">03.00</option>
										<option value="03:30">03.30</option>
										<option value="04:00">04.00</option>
										<option value="04:30">04.30</option>
										<option value="05:00">05.00</option>
										<option value="05:30">05.30</option>
										<option value="06:00">06.00</option>
										<option value="06:30">06.30</option>
										<option value="07:00">07.00</option>
										<option value="07:30">07.30</option>
										<option value="08:00">08.00</option>
										<option value="08:30">08.30</option>
										<option value="09:00">09.00</option>
										<option value="09:30">09.30</option>
										<option value="10:00">10.00</option>
										<option value="10:30">10.30</option>
										<option value="11:00">11.00</option>
										<option value="11:30">11.30</option>
										<option selected="" value="12:00">12.00</option>
										<option value="12:30">12.30</option>
										<option value="13:00">13.00</option>
										<option value="13:30">13.30</option>
										<option value="14:00">14.00</option>
										<option value="14:30">14.30</option>
										<option value="15:00">15.00</option>
										<option value="15:30">15.30</option>
										<option value="16:00">16.00</option>
										<option value="16:30">16.30</option>
										<option value="17:00">17.00</option>
										<option value="17:30">17.30</option>
										<option value="18:00">18.00</option>
										<option value="18:30">18.30</option>
										<option value="19:00">19.00</option>
										<option value="19:30">19.30</option>
										<option value="20:00">20.00</option>
										<option value="20:30">20.30</option>
										<option value="21:00">21.00</option>
										<option value="21:30">21.30</option>
										<option value="22:00">22.00</option>
										<option value="22:30">22.30</option>
										<option value="23:00">23.00</option>
										<option value="23:30">23.30</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
								<label class="control-label">Return Location</label>
									<select class="form-control" name="search_return_location" <?php echo $disabled; ?>>
										<?php
									$value = "";
									$sql = "SELECT id, description from location WHERE status = 'A'";
									db_select($sql);
									if (db_rowcount() > 0) {
										for ($j = 0; $j < db_rowcount(); $j++) {
											$value = $value . "<option value=" . db_get($j, 0) . " " . vali_iif(db_get($j, 0) == $class_id, 'Selected', '') . ">" . db_get($j, 1) . "</option>";
										}
									}
									echo $value;
									?>
									</select>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="control-label">Driver</label>
								<select class="form-control" name="search_driver">
									<optgroup label="Alaskan/Hawaiian Time Zone">
										<option value="AK">Alaska</option>
										<option value="HI">Hawaii</option>
									</optgroup>
									<optgroup label="Pacific Time Zone">
										<option value="CA">California</option>
										<option value="NV">Nevada</option>
										<option value="OR">Oregon</option>
										<option value="WA">Washington</option>
									</optgroup>
									<optgroup label="Mountain Time Zone">
										<option value="AZ">Arizona</option>
										<option value="CO">Colorado</option>
										<option value="ID">Idaho</option>
										<option value="MT">Montana</option>
										<option value="NE">Nebraska</option>
										<option value="NM">New Mexico</option>
										<option value="ND">North Dakota</option>
										<option value="UT">Utah</option>
										<option value="WY">Wyoming</option>
									</optgroup>
									<optgroup label="Central Time Zone">
										<option value="AL">Alabama</option>
										<option value="AR">Arkansas</option>
										<option value="IL">Illinois</option>
										<option value="IA">Iowa</option>
										<option value="KS">Kansas</option>
										<option value="KY">Kentucky</option>
										<option value="LA">Louisiana</option>
										<option value="MN">Minnesota</option>
										<option value="MS">Mississippi</option>
										<option value="MO">Missouri</option>
										<option value="OK">Oklahoma</option>
										<option value="SD">South Dakota</option>
										<option value="TX">Texas</option>
										<option value="TN">Tennessee</option>
										<option value="WI">Wisconsin</option>
									</optgroup>
									<optgroup label="Asian Time Zone">
										<option value="MY" selected>Malaysia</option>
										<option value="JPN">Japan</option>
										<option value="SGP">Singapore</option>
									<optgroup>
									<optgroup label="Eastern Time Zone">
										<option value="CT">Connecticut</option>
										<option value="DE">Delaware</option>
										<option value="FL">Florida</option>
										<option value="GA">Georgia</option>
										<option value="IN">Indiana</option>
										<option value="ME">Maine</option>
										<option value="MD">Maryland</option>
										<option value="MA">Massachusetts</option>
										<option value="MI">Michigan</option>
										<option value="NH">New Hampshire</option><option value="NJ">New Jersey</option>
										<option value="NY">New York</option>
										<option value="NC">North Carolina</option>
										<option value="OH">Ohio</option>
										<option value="PA">Pennsylvania</option><option value="RI">Rhode Island</option><option value="SC">South Carolina</option>
										<option value="VT">Vermont</option><option value="VA">Virginia</option>
										<option value="WV">West Virginia</option>
									</optgroup>
								</select>
							</div>

							<div class="row">
								<div class="col-md-3">
									<div class="form-group">
										<label class="label-control">Delivery Term</label>
										<select class="form-control" id="opt" onchange="change();">
											<option value="non">At Branch</option>
											<option value="delivery">Delivery</option>
											<option value="pickup">Pickup</option>
										</select>
									</div>
								</div>
								<div id="opt-cont">
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
								</div>
							</div>

						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_search">Search</button>
								<button type="button"  class="btn btn-warning" onclick="location.href='counter_reservation.php'">Clear</button>
							</div>
						</div>


				<div class="table-responsive">
			<table class="table">
				<thead>
					<tr>
						<th>No</th>
						<th>Reg No</th>
						<th>Make</th>
						<th>Model</th>
						<th>Color</th>
						<th>Year</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				<?php
			func_setPage();
			func_setOffset();
			func_setLimit(10);
			if (isset($btn_search)) {
				$where = "";
				$sql = "SELECT id, class_id, reg_no, make, model, color, year FROM vehicle WHERE availability = 'Available'";
				db_select($sql);
				func_setTotalPage(db_rowcount());
				db_select($sql . " LIMIT " . func_getLimit() . " OFFSET " . func_getOffset());
				if (db_rowcount() > 0) {
					for ($i = 0; $i < db_rowcount(); $i++) {
						if (func_getOffset() >= 10) {
							$no = func_getOffset() + 1 + $i;
						} else {
							$no = $i + 1;
						}
						echo "<tr>
								<td>" . $no . "</a></td>
										<td>" . db_get($i, 2) . "</td>
										<td>" . db_get($i, 3) . "</td>
										<td>" . db_get($i, 4) . "</td>
										<td>" . db_get($i, 5) . "</td>
										<td>" . db_get($i, 6) . "</td>
										<td>
											<a href='counter_reservation_view.php?vehicle_id=" . db_get($i, 0) . "&search_pickup_date=" . $search_pickup_date . "&search_pickup_time=" . $search_pickup_time . "&search_return_date=" . $search_return_date . "&search_return_time=" . $search_return_time . "&search_pickup_location=" . $search_pickup_location . "&search_return_location=" . $search_return_location . "&class_id=" . db_get($i, 1) . "&day=" . $day . "&delivery_cost=" . $delivery_cost . '&p_delivery_address=' . $p_delivery_address . '&r_delivery_address=' . $r_delivery_address . '&pickup_cost=' . $pickup_cost . '&p_pickup_address=' . $p_pickup_address . '&r_pickup_address=' . $r_pickup_address . "'>
											<i class='material-icons'>mode_edit</i>
												<span>Book Now</span>
											  </a>
										</td>
								<td style='display:none'>
									<div id='" . db_get($i, 0) . "' style='display:none;width:800px' class='card__body'>
										<img src='img/" . db_get($i, 1) . "'>
									</div>
								</td>
							</tr>";
					}
				} else {
					echo "<tr><td colspan='9'>No Records Found</td></tr>";
				}
				echo "
							<tr>
							<td colspan='10' style='text-align:center'>";
				func_getPaging('counter_reservation.php?x&btn_search=&search_pickup_date=' . $search_pickup_date . '&search_pickup_time=' . $search_pickup_time . '&search_return_date=' . $search_return_date . '&search_return_time=' . $search_return_time . '&search_pickup_location=' . $search_pickup_location . '&search_return_location=' . $search_return_location);
				echo "</td> </tr>";
			} ?>
							
		</tbody>
	</table>
	</div>
		</div>
	</div>
	</form>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php'); ?>

<script>
function validateForm() {
		var search_pickup_time = document.forms["myForm"]["search_pickup_time"].value;
		var search_pickup_date = document.forms["myForm"]["search_pickup_date"].value;
		var search_pickup_location = document.forms["myForm"]["search_pickup_location"].value;
		var search_return_date = document.forms["myForm"]["search_return_date"].value;
		var search_return_time = document.forms["myForm"]["search_return_time"].value;
		var search_driver = document.forms["myForm"]["search_driver"].value;
		var err = "";

		if (search_pickup_time == "") {
			err = err + "- Please provide pickup time<br/>";

		}
		if(search_pickup_date == ""){
			err = err + "- Please provide pickup date<br/>";
		}

		if(search_pickup_location == ""){
			err = err + "- Please provide pickup location<br/>";
		}
		if(search_return_date == ""){
			err = err + "- Please provide return date<br/>";
		}
		if(search_return_time == ""){
			err = err + "- Please provide return time<br/>";
		}
		if(search_driver == ""){
			err = err + "- Please provide driver<br/>";
		}

		if(err != ""){
			document.getElementById("err").innerHTML = err;
			return false;
		}
	}
</script>

<script type="text/javascript">
 function change() {
        var select = document.getElementById("opt");
        var divv = document.getElementById("opt-cont");
        var value = select.value;
        if (value == "delivery") {
            toAppend = "<div class='col-md-3'><div class='form-group'><label class='label-control'>Delivery Address for Pickup</label><input class='form-control' type='textbox' name='p_delivery_address' value='<?php echo $p_delivery_address; ?>' ></div></div><div class='col-md-3'><div class='form-group'><label class='label-control'>Delivery Address for Return</label><input class='form-control' type='textbox' name='r_delivery_address' value='<?php echo $r_delivery_address; ?>' ></div></div><div class='col-md-3'><div class='form-group'><label class='label-control'>Delivery Cost</label><input class='form-control' type='textbox' name='delivery_cost' value='<?php echo $delivery_cost; ?>'></div></div>"; divv.innerHTML=toAppend; return;
            }
            if (value == "pickup") {
                toAppend = "<div class='col-md-3'><div class='form-group'><label class='label-control' name='pickup-address'>Pickup Address for Pickup</label> <input class='form-control' type='textbox' name='p_pickup_address' value='<?php echo $p_pickup_address; ?>' ></div></div> <div class='col-md-3'><div class='form-group'><label class='label-control' name='pickup-address'>Pickup Address for Return</label> <input class='form-control' type='textbox' name='r_pickup_address' value='<?php echo $r_pickup_address; ?>' ></div></div><div class='col-md-3'><div class='form-group'><label class='label-control' name='pickup-cost'>Pickup Cost</label> <input class='form-control' type='textbox' name='pickup_cost' value='<?php echo $pickup_cost; ?>'></div></div>";divv.innerHTML = toAppend;  return;
            }
				if (value == "non") {
					toAppend = "<div class='col-md-4'><div class='form-group'></div></div> <div class='col-md-4'><div class='form-group'></div></div>";divv.innerHTML = toAppend;  return;
				}
     }
	 </script>


	<script>
        $(document).ready(function () {
            var date_input = $('input[name="search_pickup_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>

    <script>
        $(document).ready(function () {
            var date_input = $('input[name="search_return_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>
