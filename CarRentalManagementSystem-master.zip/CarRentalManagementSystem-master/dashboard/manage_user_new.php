<?php
	include("_header.php");
	
	func_setReqVar();

	if(isset($btn_save)){
		func_setValid("Y");
		func_isEmpty($username, "username");
		func_isEmpty($name, "name");
        func_isEmpty($password, "password");
        func_isEmpty($occupation, "occupation");
        func_isEmpty($branch, "branch");
	
		if(func_isValid()){
			$sql="INSERT INTO user
			(
			username,
            name,
            password,
            occupation,
            branch,
            status,
            dp
			)
			VALUES
			(
			'".conv_text_to_dbtext3($username)."', 
			'".conv_text_to_dbtext3($name)."',
            '".conv_text_to_dbtext3($password)."',
            '".conv_text_to_dbtext3($occupation)."',
            '".conv_text_to_dbtext3($branch)."',
            'Active',
            'defaultUsr.png'
			)
			";
			//echo $sql;
			db_update($sql);
			
			vali_redirect('manage_user.php?btn_search=&search_name='.$search_name.'&page='.$page);
		}
	}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">User</h4>
                </div>
            <div class="card-content">
            <form method="POST">
						<span style="color:red"><?php echo func_getErrMsg();?></span>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label class="control-label">Username</label>
                                    <input type="text" class="form-control" name="username" value="<?php echo $username;?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label class="control-label">Full Name</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo $name;?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                <label class="control-label">Password</label>
                                <input type="password" class="form-control" name="password" value="<?php echo $password;?>">
                                </div>
                            </div>
                        </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Branch</label>
                                    <select name="branch" class="form-control">
                                        <?php
                                            $sql = "SELECT description from location";
                                            db_select($sql);
                                            if(db_rowcount()>0){
                                            for($j=0;$j<db_rowcount();$j++){
                                            $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$branch,'Selected','').">".db_get($j,0)."&nbsp;&nbsp;".db_get($j,1)."</option>";
                                            }
                                            }
                                                
                                            echo $value;                                
                                        ?>
							        </select>
                            </div>

                                <div class="form-group label-floating">
                                <label class="control-label">Occupation</label>
                                <select name="occupation" class="form-control">
									<option <?php echo vali_iif('Manager'==$occupation,'Selected','');?> value='Manager'>Manager</option>
									<option <?php echo vali_iif('Branch Manager'==$occupation,'Selected','');?> value='Branch Manager'>Branch Manager</option>
									<option <?php echo vali_iif('Sales'==$occupation,'Selected','');?> value='Sales'>Sales</option>
									<option <?php echo vali_iif('Operation'==$occupation,'Selected','');?> value='Operation'>Operation</option>
                                    <option <?php echo vali_iif('Sale Operation'==$occupation,'Selected','');?> value='Sale Operation'>Sale / Operation</option>
								</select>
                            </div>

                        <div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save</button>
								<button type="button" class="btn btn-info" onclick="location.href='manage_user.php?btn_search=&search_name=<?php echo $search_name;?>&page=<?php echo $page;?>'" name="btn_cancel">Cancel</button>
                            </div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

