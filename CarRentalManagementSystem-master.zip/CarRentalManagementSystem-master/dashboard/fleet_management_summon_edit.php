<?php
	include("_header.php");
	
	func_setReqVar();

	if(isset($btn_save)){
		func_setValid("Y");
		func_isEmpty($nric_no, "NRIC No");
		func_isEmpty($name, "name");
		func_isEmpty($address, "address");
		func_isEmpty($date, "date");
		func_isEmpty($vehicle_id, "vehicle_id");
		func_isEmpty($booking_no, "booking no");
		func_isEmpty($amount, "amount");
		func_isEmpty($location_id, "location");
		func_isEmpty($issuer, "issuer");
		func_isEmpty($status, "status");
		func_isEmpty($ctos, "ctos");
		func_isEmpty($fault, "fault");
		func_isEmpty($phone_no, "phone_no");
		
		if(func_isValid()){
			$sql = "UPDATE fleet_summon SET 
					nric_no = '".$nric_no."',
					name = '".conv_text_to_dbtext3($name)."',
					address = '".conv_text_to_dbtext3($address)."',
					date = '".conv_datetodbdate($date)."',
					vehicle_id = '".$vehicle_id."', 
					booking_no = '".conv_text_to_dbtext3($booking_no)."',
					amount = ".$amount.",
					location = '".conv_text_to_dbtext3($location_id)."',
					issuer = '".$issuer."',
					status = '".$status."',
					fault = '".$fault."',
					phone_no = '".$phone_no."',
					ctos = '".$ctos."',
					mid = ".$_SESSION['cid'].",
					mdate = CURRENT_TIMESTAMP 
					WHERE id = ".$_GET['id'];
			//echo $sql;
			db_update($sql);
			
			vali_redirect("fleet_management_summon.php?btn_search=Search&page=".$page."&search_vehicle=".$search_vehicle);
		}
	}else if(isset($btn_delete)){
		
		$sql = "DELETE from fleet_summon WHERE id = ".$_GET['id'];
		db_update($sql);
		
		vali_redirect("fleet_management_summon.php?btn_search=Search&page=".$page."&search_vehicle=".$search_vehicle);
		
	}else{
		
		$sql = "SELECT id,
				nric_no,
				name,
				address,
				date,
				vehicle_id,
				booking_no,
				amount,
				location as location_id,
				issuer,
				status,
				fault,
				ctos,
				cid,
				cdate,
				mid,
				phone_no,
				mdate
			FROM fleet_summon 
			WHERE id=".$_GET['id'];
			db_select($sql);
			if(db_rowcount()>0){
				func_setSelectVar();
			}
	}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="red">
					<h4 class="title">Summon</h4>
                </div>
            <div class="card-content">
            <form method="POST">
				<span style="color:red"><?php echo func_getErrMsg();?></span>

                <div class="row">
                    <div class="col-md-3">
                    <div class="form-group label-floating">
							<label class="control-label">NRIC No</label>
								<select class="form-control" name="nric_no" <?php echo $disabled;?> onchange="getCustomerInfo(this.value)">
									<?php 
									
									$value = "";
									
									$sql = "SELECT nric_no, CONCAT(firstname, ' ' , lastname) as name  from customer WHERE status = 'A'";
									db_select($sql);
									if(db_rowcount()>0){
										for($j=0;$j<db_rowcount();$j++){
											$value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$nric_no,'Selected','').">
											".db_get($j,0)." : " .db_get($j,1)."</option>";
										}
									}
									
									echo $value;
									
									?>
								</select>
						</div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group label-floating">
                            <label class="control-label">Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo $name;?>" id="name">
						</div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group label-floating">
                            <label class="control-label">Phone Number</label>
                            <input type="text" class="form-control" name="phone_no" value="<?php echo $phone_no;?>">
						</div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group label-floating">
                            <label class="control-label">Address</label>
                            <input class="form-control" name="address" id="address" value="<?php echo $address;?>">
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Date</label>
                            <input type="text" class="form-control" id="date" name="date" value="<?php echo $date;?>">
						</div>
                    </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
						<label class="control-label">Location</label>
						<input type="text" class="form-control" name="location_id" value="<?php echo $location_id;?>">
						</div>
                    </div>
                    <div class="col-md-4">
                    <div class="form-group label-floating">
							<label class="control-label">Vehicle</label>
								<select class="form-control" name="vehicle_id" <?php echo $disabled;?>>
									<?php 
									
									$value = "";
									
									$sql = "SELECT id, reg_no, model, year from vehicle";
									db_select($sql);
									if(db_rowcount()>0){
										for($j=0;$j<db_rowcount();$j++){
											$value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$vehicle_id,'Selected','').">
											".db_get($j,1)." : ".db_get($j,2). " (" .db_get($j,3). ")</option>";
										}
									}
									
									echo $value;
									
									?>
								</select>
						</div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group label-floating">
                            <label class="control-label">Booking No</label>
                            <input type="text" class="form-control" name="booking_no" value="<?php echo $booking_no;?>">	
                    </div>
                   </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
                            <label class="control-label">Amount</label>
                            <input type="text" class="form-control" name="amount" value="<?php echo $amount;?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Issuer</label>
								<select name="issuer" class="form-control">
									<option value='JPJ' <?php echo vali_iif('JPJ'==$issuer,'Selected','');?>>JPJ</option>
									<option value='PDRM' <?php echo vali_iif('PDRM'==$issuer,'Selected','');?>>PDRM</option>
								</select>
						</div>
                    </div>
                </div>
					
				<div class="row">
					<div class="col-md-4">
						<div class="form-group label-floating">
							<label class="control-label">Fault</label>
							<input type="text" class="form-control" name="fault" value="<?php echo $fault ?>">
						</div>
					</div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
                                <label class="control-label">Status</label>
                                    <select name="status" class="form-control">
                                        <option value='New' <?php echo vali_iif('New'==$status,'Selected','');?>>New</option>
                                        <option value='First Transfer' <?php echo vali_iif('First Transfer'==$status,'Selected','');?>>First Transfer</option>
                                        <option value='Second Transfer' <?php echo vali_iif('Second Transfer'==$status,'Selected','');?>>Second Transfer</option>
                                        <option value='Third Transfer' <?php echo vali_iif('Third Transfer'==$status,'Selected','');?>>Third Transfer</option>
                                        <option value='Completed' <?php echo vali_iif('Completed'==$status,'Selected','');?>>Completed</option>
                                        <option value='Paid by Customer' <?php echo vali_iif('Paid by Customer'==$status,'Selected','');?>>Paid by Customer</option>
                                    </select>
						</div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">CTOS Action</label>
								<select name="ctos" class="form-control">
									<option value='1' <?php echo vali_iif('1'==$ctos,'Selected','');?>>1</option>
									<option value='2' <?php echo vali_iif('2'==$ctos,'Selected','');?>>2</option>
									<option value='3' <?php echo vali_iif('3'==$ctos,'Selected','');?>>3</option>
									<option value='B' <?php echo vali_iif('B'==$ctos,'Selected','');?>>B</option>
								</select>
						</div>
                    </div>
                </div>
				
                <div class="form-group">
					<div class="text-center">
					    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                        <button type="submit" class="btn btn-danger" name="btn_delete">Delete</button>
						<button type="button" class="btn btn-warning" onclick="location.href='fleet_management_summon.php?btn_search=&search_vehicle=<?php echo $search_vehicle;?>'">Cancel</button>
					</div>
				</div>

				</form>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
    
        <!-- Date Picker -->
        <script src="assets/js/bootstrap-datepicker.js"></script>
    
    
        <script>
            $(document).ready(function () {
                var date_input = $('input[name="date"]');
                var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
                date_input.datepicker({
                    format: 'dd/mm/yyyy',
                    container: container,
                    todayHighlight: true,
                    autoclose: true,
                })
            })
        </script>

