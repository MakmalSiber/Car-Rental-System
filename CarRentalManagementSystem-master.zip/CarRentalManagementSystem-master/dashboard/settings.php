<?php
 include ('_header.php'); func_setReqVar(); $sql = "SELECT * FROM user WHERE id=" . $_SESSION['cid']; db_select($sql); if (db_rowcount() > 0) { func_setSelectVar(); } ?>

<div class="card card-nav-tabs">
	<div class="card-header" data-background-color="default">
		<div class="nav-tabs-navigation">
			<div class="nav-tabs-wrapper">
                <?php if ($occupation == "Admin") { ?>
                <span class="nav-tabs-title">Settings</span>
				<ul class="nav nav-tabs" data-tabs="tabs">
					<li class="active">
						<a href="#account" data-toggle="tab">
							<i class="material-icons">account_box</i>
							Account
						<div class="ripple-container"></div></a>
					</li>
					<li class="">
						<a href="#company" data-toggle="tab">
							<i class="material-icons">account_balance</i>
							Company
						<div class="ripple-container"></div></a>
					</li>
            <?php } else { ?>
                <li style="list-style: none">
					<a href="#account" data-toggle="tab">
						<h4 class="title">Account</h4>
                    </a>
				</li>
				</ul>
            <?php } ?>
			</div>
		</div>
	</div>
	<div class="card-content">
		<div class="tab-content">

            <!-- Account Tab -->
			<div class="tab-pane active" id="account">

            <?php
 if (isset($btn_save)) { func_setValid("Y"); func_isEmpty($password, "password"); if(func_isValid() && $verify == $password){ $sql = "UPDATE user SET password = '$password' WHERE id =".$_SESSION['cid']; db_update($sql); echo "Password Updated"; vali_redirect('settings.php'); } } else { $sql = "SELECT * FROM user WHERE id=".$_SESSION['cid']; db_select($sql); if (db_rowcount() > 0) { func_setSelectVar(); } } ?>
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Username</label>
                                        <input type="text" class="form-control" name="description" value="<?php echo $username; ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Name</label>
                                        <input type="text" class="form-control" name="description" value="<?php echo $name; ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Occupation</label>
                                        <input type="text" class="form-control" name="description" value="<?php echo $occupation; ?>" disabled>
                                    </div>
                                </div>
                            </div>
                           <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                    <label class="control-label label-floating">Password</label>
                                    <input type="password" class="form-control" name="password" value="<?php echo $password; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label label-floating">Password Confirmation</label>
                                    <input type="password" class="form-control" name="verify" value="<?php echo $verify; ?>" required>
                                    </div>
                                </div>
                           </div>
                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                </div>
                            </div>
                        </form>
			</div>

            <!-- Company Tab -->
			<div class="tab-pane" id="company">
                
            <?php
            if (isset($_FILES['image'])) {
                $errors = array();
                $file_name = $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png");
                if (in_array($file_ext, $expensions) === false) {
                    $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
                }
                if ($file_size > 2097152) {
                    $errors[] = 'File size must be excately 2 MB';
                }
                if (empty($errors) == true) {
                    move_uploaded_file($file_tmp, "assets/img/" . $file_name);
                    echo "Success";
                } else {
                    print_r($errors);
                }
            }
            if (isset($btn_save)) {
                func_setValid("Y");
                if (func_isValid()) {
                    $sql = "INSERT INTO company (image, company_name, website_name, registration_no, address, phone_no) VALUES ('$file_name', '$website_name', '$company_name', '$registration_no', '$address', '$phone_no')";
                    db_update($sql);
                    $sql = "SELECT LAST_INSERT_ID() FROM company";
                    db_select($sql);
                    if (db_rowcount() > 0) {
                        $id = db_get(0, 0);
                    }
                    echo '<script language="javascript">';
                    echo 'alert("Company have been added to database")';
                    echo '</script>';
                    vali_redirect('settings.php');
                }
            } elseif (isset($btn_update)) {
                $sql = "UPDATE company 
                    SET image = '$file_name',
                    company_name = '$company_name', 
                    website_name = '$website_name',
                    registration_no = '$registration_no', 
                    address = '$address', 
                    phone_no = '$phone_no' 
                    WHERE id IS NOT NULL";
                db_update($sql);
                echo '<script language="javascript">';
                echo 'alert("Information updated!")';
                echo '</script>';
                vali_redirect('settings.php');
            } else {
                $sql = "SELECT * FROM company WHERE id IS NOT NULL";
                db_select($sql);
                if (db_rowcount() > 0) {
                    func_setSelectVar();
                }
            } ?>
            <form method="POST" enctype = "multipart/form-data">
               
                <div class="row">
                    <div class="col-md-4">
                       <label class="control-label">Image</label>
                        <input class="btn btn-small btn-default" type="file" name="image">
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Company Name</label>
                            <input class="form-control" name="company_name" value="<?php echo $company_name; ?>" required> 
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Website Name</label>
                            <input class="form-control" name="website_name" value="<?php echo $website_name; ?>" required> 
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Registration Number</label>
                            <input class="form-control" name="registration_no" value="<?php echo $registration_no; ?>" required> 
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Address</label>
                            <input class="form-control" name="address" value="<?php echo $address; ?>" required> 
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input class="form-control" name="phone_no" value="<?php echo $phone_no; ?>" required> 
                        </div>
                    </div>
                </div>
               
                <div class="form-group">
                    <div class="text-center">
                    <?php  $sql = "SELECT * FROM company WHERE id IS NOT NULL"; db_select($sql); if(db_rowcount() > 0) { echo "<button type='submit' class='btn btn-success' name='btn_update'>Update</button>"; } else { echo "<button type='submit' class='btn btn-success' name='btn_save'>Save</button>"; } ?>
                    </div>
                </div>
                </form>
			</div>
		</div>
	</div>

</div>

<?php include ('_footer.php');?>