<?php
	include('_header.php');
	
	func_setReqVar();
	
	if(isset($btn_save)){
		func_setValid("Y");
		func_isEmpty($description, "location description");
		func_isEmpty($status, "status");
		
		if($default == "D"){
			$sql = "SELECT * from location WHERE `default`='D'";
			db_select($sql);
			if(db_rowcount()>0){
				func_setErrMsg("- Invalid default location");
			}
		}
		
		if(func_isValid()){
			$sql="INSERT INTO 
			location
			(
			description, 
			status,  
			`default`, 
			address,
			phone_no,
			email,
			hint,
			cid, 
			cdate
			)
			VALUES
			(
			'$description',
			'$status',
			'$default',
			'$address',
			'$phone_no',
			'$email',
			'$hint',
			".$_SESSION['cid'].",
			CURRENT_TIMESTAMP
			)
			";
			//echo $sql;
			db_update($sql);
			
			vali_redirect("manage_location.php?search_description=". $_GET["search_description"]."&btn_search=Search&page=".$page);
		}
	}
?>

<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src='http://maps.google.com/maps/api/js?key=AIzaSyDOuS7nnbLUzHgx5JSPbx7x7FCMyZ_J7fI'></script>
<script src="assets/js/locationpicker.jquery.js"></script>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Location</h4>
                </div>
                    <div class="card-content">
					<form method="POST">
                            <span style="color:red"><?php echo func_getErrMsg(); ?></span>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Description</label>
                                        <input class="form-control" name="description" value="<?php echo $description; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Status</label>
                                        <select name="status" class="form-control">
                                            <option value='A' <?php echo vali_iif('A' == $status, 'Selected', ''); ?>>Active</option>
                                            <option value='I' <?php echo vali_iif('I' == $status, 'Selected', ''); ?>>In-Active</option>
                                        </select>
                                    </div>
                                </div>
                            </div> 

                           <div class="row">
                               <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Address</label>
                                        <input class="form-control" name="address" id="address" value="<?php echo $address; ?>">
                                    </div>
                               </div>
                               <div class="col-md-3">
                                   <div class="form-group">
                                       <label class="control-label label-floating">Radius</label>
                                       <input class="form-control" id="radius">
                                   </div>
                               </div>
                               <div class="col-md-2">
                                     <div class="form-group">
                                        <label class="control-label label-floating">Phone Number</label>
                                        <input class="form-control" name="phone_no" value="<?php echo $phone_no; ?>">
                                    </div>
                               </div>
                           </div>

                            <div class="row">
                                <div class="col-md-4">
                                   <div class="form-group">
                                       <label class="control-label label-floating">Email</label>
                                       <input type="email" class="form-control" name="email" value="<?php echo $email; ?>">
                                   </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label label-floating">Hint</label>
                                        <input class="form-control" name="hint" value="<?php echo $hint; ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Default</label>
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="default" value="D">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <label class="control-label">Latitude</label>
                                    <input class="form-control" name="latitude" id="latitude">     
                                </div>
                                <div class="col-md-6">
                                    <label class="control-label">Longitude</label>
                                    <input class="form-control" name="longitude" id="longitude">     
                                </div>
                            </div>

                            <div class="form-group">
                                <div id="location" style="width: 100%; height: 350px;"></div>
                            </div>
                           
                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                    <button type="button" class="btn btn-warning" onclick="location.href='manage_location.php?search_description=<?php echo $search_description; ?>&page=<?php echo $page; ?>'" name="btn_cancel">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('#location').locationpicker({
        location: {
            latitude: 2.682457,
            longitude: 101.903735
        },
        radius: 300,
        inputBinding: {
            latitudeInput: $('#latitude'),
            longitudeInput: $('#longitude'),
            radiusInput: $('#radius'),
            locationNameInput: $('#address')
        }
    });
</script>

<?php include ('_footer.php'); ?>