<?php
include("_header.php");
func_setReqVar();
if (isset($btn_save)) {
	func_setValid("Y");
	func_isEmpty($season_name, "season name");
	func_isEmpty($start_date, "start date");
	func_isEmpty($end_date, "end date");
	func_isNum($display_order, "display order");
	if (func_isValid()) {
		$sql = "INSERT INTO 
			season_rental
			(
			season_name, 
			start_date, 
			end_date, 
			status,
			display_order,
			cid, 
			cdate
			)
			VALUES
			(
			'" . conv_text_to_dbtext3($season_name) . "',
			'" . conv_datetodbdate($start_date) . "',
			'" . conv_datetodbdate($end_date) . "',
			'" . conv_text_to_dbtext3($status) . "',
			'" . $display_order . "',
			" . $_SESSION['cid'] . ",
			CURRENT_TIMESTAMP 			
			)";
		db_update($sql);
		vali_redirect("rental_seasons.php?btn_search=Search&page=" . $page . "&search_rental_seasons_name=" . $search_rental_seasons_name);
	}
} ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="green">
					<h4 class="title">Rental Seasons</h4>
                </div>
            <div class="card-content">
            <form method="POST">
                        <span style="color:red"><?php echo func_getErrMsg();?></span>
                        
						<div class="form-group label-floating">
							<label class="control-label">Season Name</label>
							<input type="text" class="form-control" name="season_name" value="<?php echo $season_name;?>">
                        </div>
                        
						<div class="form-group label-floating">
                            <label class="control-label">Start Date</label>
                            <input class="form-control" type="text" id="start_date" name="start_date" value="<?php echo $start_date;?>">
                        </div>
                        
						<div class="form-group label-floating">
                            <label class="control-label">End Date</label>
                            <input class="form-control" type="text" id="end_date" name="end_date" value="<?php echo $end_date;?>">
                        </div>
                        
						<div class="form-group label-floating">
							<label class="control-label">Display Order</label>
							<input type="text" class="form-control" name="display_order" value="<?php echo $display_order;?>">
                        </div>

						 <div class="form-group label-floating">
                                <label class="control-label">Status</label>
                                <select name="status" class="form-control">
									<option <?php echo vali_iif('1'==$status,'Selected','');?> value='1'>Active</option>
									<option <?php echo vali_iif('0'==$status,'Selected','');?> value='0'>Not Active</option>
								</select>
                        </div>
                        
						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save</button>
								<button type="button" class="btn btn-warning" onclick="location.href='rental_seasons.php?btn_search=&search_rental_seasons_name=<?php echo $search_rental_seasons_name;?>'">Cancel</button>
							</div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php'); ?>

 <script>
        $(document).ready(function () {
            var date_input = $('input[name="start_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>
 <script>
        $(document).ready(function () {
            var date_input = $('input[name="end_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>


