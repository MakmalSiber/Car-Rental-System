<?php
	include("_header.php");
	
	func_setReqVar();
		
	if(isset($btn_save)){
	
        func_setValid("Y");
        //func_isEmpty($gl_code, "GL code");
	
		if(func_isValid()){
			
			$sql="INSERT INTO agent
                    (
					company_name, 
                    name,
                    address, 
					state, 
					city,
					zipcode,
					country
                    )
                    VALUES
                    (
                    '$company_name',
                    '$name',
                    '$address',
                    '$state',
                    '$city', 
                    '$zipcode',
                    '$country'
                    )
                    ";

            //echo $sql;
			db_update($sql);
			
            vali_redirect('manage_agent.php?btn_search=&search_name='.$search_name.'&page='.$page);

        }
    }
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Agent</h4>
                </div>
            <div class="card-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group label-floating">
                        <label class="control-label">Company Name</label>
                        <input type="text" class="form-control" name="company_name" value="<?php echo $company_name; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group label-floating">
                        <label class="control-label">Name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo $name;?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group label-floating">
                            <label class="control-label">Address</label>             
                            <input type="text" class="form-control" name="address" value="<?php echo $address;?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group label-floating">
                            <label class="control-label">State</label>
                            <input type="text" class="form-control" name="state" value="<?php echo $state; ?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group label-floating">
                            <label class="control-label">City</label>
                            <input type="text" class="form-control" name="city" value="<?php echo $city;?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
                        <label class="control-label">Zip Code</label>
                        <input type="text" class="form-control" name="zipcode" value="<?php echo $zipcode; ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group label-floating">
                        <label class="control-label">Country</label>
                            <input type="text" class="form-control" name="country" value="<?php echo $country; ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="text-center">
                        <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                        <button type="button" class="btn btn-warning" onclick="location.href='agent_list.php?btn_search=&search_agent=<?php echo $search_agent;?>&page=<?php echo $page;?>'">Cancel</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

