<?php
include "_header.php";
func_setReqVar();?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="blue">
                            <h4 class="title">Reservation List</h4>
                        </div>
                        <div class="card-content">
                            <form>
                                <div class="row">
                                    <div class="col-md-10">
                                        <div class="form-group">
                                            <label class="control-label">NRIC No</label>
                                            <input type="text" class="form-control" name="search_nricno" value="<?php echo $search_nricno; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <div class="text-center">
                                                <button type="submit" class="btn btn-success" name="btn_search">Search</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Customer Name</th>
                                                <th>NRIC No.</th>
                                                <th>Vehicle Plate No</th>
                                                <th>From Date & Time</th>
                                                <th>To Date & Time</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            func_setPage();
                                            func_setOffset();
                                            func_setLimit(10);

                                            if (isset($btn_search)) {
                                                if ($search_nricno != "") {
                                                    $where = " AND nric_no like '%" . $search_nricno . "%'";
                                                }
                                            }
                                            $sql = "SELECT
                                            booking_trans.id,
                                            class_id,
                                            firstname,
                                            lastname,
                                            nric_no,
                                            reg_no,
                                            DATE_FORMAT(pickup_date, '%d/%m/%Y') as pickup_date,
                                            DATE_FORMAT(pickup_time, '%H:%i:%s') as pickup_time,
                                            DATE_FORMAT(return_date, '%d/%m/%Y') as return_date,
                                            DATE_FORMAT(return_time, '%H:%i:%s') as return_time,
                                            vehicle.id AS vehicle_id
                                            FROM vehicle
                                            LEFT JOIN booking_trans ON vehicle.id = vehicle_id
                                            LEFT JOIN class ON class.id = class_id
                                            LEFT JOIN customer ON customer.id = customer_id
                                            WHERE booking_trans.id IS NOT NULL
                                            ORDER BY booking_trans.id DESC" . $where;
                                            db_select($sql);
                                            func_setTotalPage(db_rowcount());
                                            db_select($sql . " LIMIT " . func_getLimit() . " OFFSET " . func_getOffset());
                                            if (db_rowcount() > 0) {
                                                for ($i = 0; $i < db_rowcount(); $i++) {
                                                    if (func_getOffset() >= 10) {
                                                        $no = func_getOffset() + 1 + $i;
                                                    } else {
                                                        $no = $i + 1;
                                                    }
                                    echo "<tr>
									<td>" . $no . "</td>
									<td>" . db_get($i, 2) . " " . db_get($i, 3) . "</td>
									<td>" . db_get($i, 4) . "</td>
									<td>" . db_get($i, 5) . "</td>
									<td>" . db_get($i, 6) . " " . db_get($i, 7) . "</td>
									<td>" . db_get($i, 8) . " " . db_get($i, 9) . "</td>
									<td><a href='reservation_list_view.php?id=" . db_get($i, 0) . "&class_id=" . db_get($i, 1) . "&vehicle_id=" . db_get($i, 10). "'><i class='material-icons'>pageview</i></td>
									</tr>";}} else {echo "<tr><td colspan='8'>No records found</td></tr>";}?>
                                                <tr>
                                                    <td colspan="8" style="text-align:center">
                                                        <?php func_getPaging('reservation_list.php?x');?>
                                                    </td>
                                                </tr>
                                        </tbody>
                                    </table>
                                </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include('_footer.php');?>