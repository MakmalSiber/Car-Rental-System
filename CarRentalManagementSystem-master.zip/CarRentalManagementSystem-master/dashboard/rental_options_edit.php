<?php
include "_header.php";

func_setReqVar();

if (isset($btn_save)) {

    func_setValid("Y");
    func_isEmpty($description, "description");
    func_isEmpty($calculation, "calculation");
    func_isEmpty($amount, "amount");
    func_isEmpty($taxable, "taxable");

    if (func_isValid()) {

        $sql = "UPDATE option_rental SET
			description = '" . conv_text_to_dbtext3($description) . "',
			calculation = '" . $calculation . "',
			amount = " . $amount . ",
			taxable = '" . $taxable . "',
			mid = " . $_SESSION['cid'] . ",
			mdate = CURRENT_TIMESTAMP
			WHERE id = " . $_GET['id'];
        //echo $sql;
        db_update($sql);

        vali_redirect("rental_options.php?btn_search=Search&page=" . $page . "&search_rental_description=" . $search_rental_description);
    }

} else if (isset($btn_delete)) {

    $sql = "DELETE FROM option_rental WHERE id = " . $_GET['id'];
    //echo $sql;
    db_update($sql);

    vali_redirect("rental_options.php?btn_search=Search&page=" . $page . "&search_rental_description=" . $search_rental_description);

} else {

    $sql = "SELECT id,
		description,
		case calculation WHEN 'H' Then 'Per Hour' WHEN 'D' Then 'Per Day' End as calculation,
		amount,
		case taxable WHEN 'Y' Then 'Yes' WHEN 'N' Then 'No' End as taxable
		FROM option_rental
		WHERE id is not NULL" . $where;
    //echo $sql;
    db_select($sql);
    if (db_rowcount() > 0) {
        func_setSelectVar();
    }

}
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="green">
					<h4 class="title">Rental Options</h4>
                </div>
                <div class="card-content">
                        <form method="POST">
                            <span style="color:red">
                                <?php echo func_getErrMsg(); ?>
                            </span>

                            <div class="form-group label-floating">
                                <label class="control-label">Description</label>
                                <textarea class="form-control" name="description"><?php echo $description; ?></textarea>
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Calculation</label>
                                <select name="calculation" class="form-control">
                                    <option value='H' <?php echo vali_iif( 'H'==$calculation, 'Selected', ''); ?>>Per Hour</option>
                                    <option value='D' <?php echo vali_iif( 'D'==$calculation, 'Selected', ''); ?>>Per Day</option>
                                </select>
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Amount</label>
                                <input type="text" class="form-control" name="amount" value="<?php echo $amount; ?>">
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Taxable</label>
                                <select name="taxable" class="form-control">
                                    <option value='Y' <?php echo vali_iif( 'Y'==$taxable, 'Selected', ''); ?>>Yes</option>
                                    <option value='N' <?php echo vali_iif( 'N'==$taxable, 'Selected', ''); ?>>No</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                    <button type="button" class="btn btn-warning" onclick="location.href='rental_options.php?btn_search=&search_rental_description=<?php echo $search_rental_description; ?>'">Cancel</button>
                                    <button type="submit" class="btn btn-danger" name="btn_delete">Delete</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php include('_footer.php'); ?>