<?php
include('_header.php');
func_setReqVar();

if (isset($_FILES['testimonial_image'])) {
    $errors = array();
    $file_name = $_FILES['testimonial_image']['name'];
    $file_size = $_FILES['testimonial_image']['size'];
    $file_tmp = $_FILES['testimonial_image']['tmp_name'];
    $file_type = $_FILES['testimonial_image']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['testimonial_image']['name'])));
    $expensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
    } if ($file_size > 2097152) {
        $errors[] = 'File size must be excately 2 MB';
    } if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "../dashboard/assets/img/cms/" . $file_name);
        echo "Success";
    } else {
        print_r($errors);
    }
}

if (isset($_FILES['testimonial_images'])) {
    $errors = array();
    $file_names = $_FILES['testimonial_images']['name'];
    $file_size = $_FILES['testimonial_images']['size'];
    $file_tmp = $_FILES['testimonial_images']['tmp_name'];
    $file_type = $_FILES['testimonial_images']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['testimonial_images']['name'])));
    $expensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
    } if ($file_size > 2097152) {
        $errors[] = 'File size must be excately 2 MB';
    } if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "../dashboard/assets/img/cms/" . $file_names);
        echo "Success";
    } else {
        print_r($errors);
    }
}

if (isset($_FILES['productone_img'])) {
    $errors = array();
    $file_name1 = $_FILES['productone_img']['name'];
    $file_size = $_FILES['productone_img']['size'];
    $file_tmp = $_FILES['productone_img']['tmp_name'];
    $file_type = $_FILES['productone_img']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['productone_img']['name'])));
    $expensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
    } if ($file_size > 2097152) {
        $errors[] = 'File size must be excately 2 MB';
    } if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "../dashboard/assets/img/cms/" . $file_name1);
        echo "Success";
    } else {
        print_r($errors);
    }
}

if (isset($_FILES['producttwo_img'])) {
    $errors = array();
    $file_name2 = $_FILES['producttwo_img']['name'];
    $file_size = $_FILES['producttwo_img']['size'];
    $file_tmp = $_FILES['producttwo_img']['tmp_name'];
    $file_type = $_FILES['producttwo_img']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['producttwo_img']['name'])));
    $expensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
    } if ($file_size > 2097152) {
        $errors[] = 'File size must be excately 2 MB';
    } if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "../dashboard/assets/img/cms/" . $file_name2);
        echo "Success";
    } else {
        print_r($errors);
    }
}

if (isset($_FILES['productthree_img'])) {
    $errors = array();
    $file_name3 = $_FILES['productthree_img']['name'];
    $file_size = $_FILES['productthree_img']['size'];
    $file_tmp = $_FILES['productthree_img']['tmp_name'];
    $file_type = $_FILES['productthree_img']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['productthree_img']['name'])));
    $expensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
    } if ($file_size > 2097152) {
        $errors[] = 'File size must be excately 2 MB';
    } if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "../dashboard/assets/img/cms/" . $file_name3);
        echo "Success";
    } else {
        print_r($errors);
    }
}

if(isset($btn_save)){
    func_setValid("Y"); 
    if (func_isValid()) {
    $sql = "UPDATE front_page 
    SET 
    hero_title = '$hero_title',
    hero_subtitle = '$hero_subtitle',
    hero_paragraph = '$hero_paragraph',
    heroes_title1 = '$heroes_title1',
    heroes_sub1 = '$heroes_sub1',
    heroes_title2 = '$heroes_title2',
    heroes_sub2 = '$heroes_sub1',
    heroes_title3 = '$heroes_title3',
    heroes_sub3 = '$heroes_sub3',
    productone_title = '$productone_title',
    productone_subtitle = '$productone_subtitle',
    productone_desc = '$productone_desc',
    productone_price = '$productone_price',
    productone_img = '$file_name1',
    producttwo_title = '$producttwo_title',
    producttwo_subtitle = '$producttwo_subtitle',
    producttwo_desc = '$producttwo_desc',
    producttwo_price = '$producttwo_price',
    producttwo_img = '$file_name2',
    productthree_title = '$productthree_title',
    productthree_subtitle = '$productthree_subtitle',
    productthree_desc = '$productthree_desc',
    productthree_price = '$productthree_price',
    productthree_img = '$file_name3',
    choose_titlebar = '$choose_titlebar',
    choose_sub_title = '$choose_sub_title',
    choose_desc = '$choose_desc',
    choose_card_title1 = '$choose_card_title1',
    choose_card_subtitle1 = '$choose_card_subtitle1',
    choose_card_title2 = '$choose_card_title2',
    choose_card_subtitle2 = '$choose_card_subtitle2',
    choose_card_title3 = '$choose_card_title3',
    choose_card_subtitle3 = '$choose_card_subtitle3',
    testimonial_pic = '$file_name',
    testimonial_feedback = '$testimonial_feedback',
    testimonial_origin = '$testimonial_origin',
    testimonial_user = '$testimonial_user',
    testimonial_users = '$testimonial_users',
    testimonial_feedbacks = '$testimonial_feedbacks',
    testimonial_origins = '$testimonial_origins',
    testimonial_img = '$file_names',
    testimonial_title = '$testimonial_title',
    testimonial_subtitle = '$testimonial_subtitle'
    WHERE id = 1";
    db_update($sql);

    echo "<script>alert('Updated')</script>";
    vali_redirect('cms.php');
    }

} else {
$sql = "SELECT * FROM front_page WHERE id = 1";
db_select($sql);
if (db_rowcount() > 0) {
    func_setSelectVar();
} 
}
?>

<style>
iframe {
    border: 1px solid rgba(0,0,0,0.16);
    border-radius: 5px;
    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
}
</style>

<div class="card card-nav-tabs">
    <div class="card-header" data-background-color="default">
        <h4 class="title">Content Management System</h4>
    </div>
	<div class="card-content">
		<form action="" method="post" enctype = "multipart/form-data">
            <div class="row">
                <!-- Hero Section -->
                <div class="col-md-4">
                <h4>How it Works</h4>
                    <div class="form-group">
                        <label class="control-label">Title</label>
                        <input class="form-control" name="hero_title" value="<?php echo $hero_title; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Sub Title</label>
                        <input class="form-control" name="hero_subtitle" value="<?php echo $hero_subtitle; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <input class="form-control" name="hero_paragraph" value="<?php echo $hero_paragraph; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description One - Title</label>
                        <input class="form-control" name="heroes_title1" value="<?php echo $heroes_title1; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description One - Description</label>
                        <input class="form-control" name="heroes_sub1" value="<?php echo $heroes_sub1; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description Two - Title</label>
                        <input class="form-control" name="heroes_title2" value="<?php echo $heroes_title2; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description Two - Description</label>
                        <input class="form-control" name="heroes_sub2" value="<?php echo $heroes_sub2; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description Three - Title</label>
                        <input class="form-control" name="heroes_title3" value="<?php echo $heroes_title3; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description Three - Description</label>
                        <input class="form-control" name="heroes_sub3" value="<?php echo $heroes_sub3; ?>">
                    </div>
                    <!-- End Hero Section -->
                    <hr>
                    <h4>Product</h4>
                    <div>
                        <label class="control-label">Product One - Picture</label>
                        <input class="btn btn-small btn-default" type="file" name="productone_img">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product One - Title</label>
                        <input class="form-control" name="productone_title" value="<?php echo $productone_title; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product One - Subtitle</label>
                        <input class="form-control" name="productone_subtitle" value="<?php echo $productone_subtitle; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product One - Description</label>
                        <input class="form-control" name="productone_desc" value="<?php echo $productone_desc; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product One - Price</label>
                        <input class="form-control" name="productone_price" value="<?php echo $productone_price; ?>">
                    </div>

                     <div>
                        <label class="control-label">Product Two - Picture</label>
                        <input class="btn btn-small btn-default" type="file" name="producttwo_img">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Two - Title</label>
                        <input class="form-control" name="producttwo_title" value="<?php echo $producttwo_title; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Two - Subtitle</label>
                        <input class="form-control" name="producttwo_subtitle" value="<?php echo $producttwo_subtitle; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Two - Description</label>
                        <input class="form-control" name="producttwo_desc" value="<?php echo $producttwo_desc; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Two - Price</label>
                        <input class="form-control" name="producttwo_price" value="<?php echo $producttwo_price; ?>">
                    </div>

                     <div>
                        <label class="control-label">Product Three - Picture</label>
                        <input class="btn btn-small btn-default" type="file" name="productthree_img">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Three - Title</label>
                        <input class="form-control" name="productthree_title" value="<?php echo $productthree_title; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Three - Subtitle</label>
                        <input class="form-control" name="productthree_subtitle" value="<?php echo $productthree_subtitle; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Three - Description</label>
                        <input class="form-control" name="productthree_desc" value="<?php echo $productthree_desc; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Product Three - Price</label>
                        <input class="form-control" name="productthree_price" value="<?php echo $productthree_price; ?>">
                    </div>

                    <hr>
                    <h4>Why Choose Us</h4>
                    <div class="form-group">
                        <label class="control-label">Title</label>
                        <input class="form-control" name="choose_titlebar" value="<?php echo $choose_titlebar; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Sub Title</label>
                        <input class="form-control" name="choose_sub_title" value="<?php echo $choose_sub_title; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <input class="form-control" name="choose_desc" value="<?php echo $choose_desc; ?>">
                    </div>
                    <hr>
                    <h4>First Card</h4>
                    <div class="form-group">
                        <label class="control-label">Title</label>
                        <input class="form-control" name="choose_card_title1" value="<?php echo $choose_card_title1; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Sub Title</label>
                        <input class="form-control" name="choose_card_subtitle1" value="<?php echo $choose_card_subtitle1; ?>">
                    </div>
                    <hr>
                    <h4>Second Card</h4>
                    <div class="form-group">
                        <label class="control-label">Title</label>
                        <input class="form-control" name="choose_card_title2" value="<?php echo $choose_card_title2; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Sub Title</label>
                        <input class="form-control" name="choose_card_subtitle2" value="<?php echo $choose_card_subtitle2; ?>">
                    </div>
                    <hr>
                    <h4>Third Card</h4>
                    <div class="form-group">
                        <label class="control-label">Title</label>
                        <input class="form-control" name="choose_card_title3" value="<?php echo $choose_card_title3; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Sub Title</label>
                        <input class="form-control" name="choose_card_subtitle3" value="<?php echo $choose_card_subtitle3; ?>">
                    </div>

                    <!-- Testimonial Section -->
                    <hr>
                    <h4>Testimonial</h4>
                    <div>
                        <label class="control-label">Title</label>
                        <input class="form-control" name="testimonial_title" value="<?php echo $testimonial_title; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Subtitle</label>
                        <input class="form-control" name="testimonial_subtitle" value="<?php echo $testimonial_subtitle; ?>">
                    </div>
                    <hr>
                    <h4>First Testimonial</h4>
                    <div>
                        <label class="control-label">Picture</label>
                        <input class="btn btn-small btn-default" type="file" name="testimonial_image">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Feedback</label>
                        <input class="form-control" name="testimonial_feedback" value="<?php echo $testimonial_feedback; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Origin</label>
                        <input class="form-control" name="testimonial_origin" value="<?php echo $testimonial_origin; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Name</label>
                        <input type="text" class="form-control" name="testimonial_user" value="<?php echo $testimonial_user; ?>">
                    </div>
                    <hr>
                    <h4>Second Testimonial</h4>
                    <div>
                        <label class="control-label">Picture</label>
                        <input class="btn btn-small btn-default" type="file" name="testimonial_images">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Feedback</label>
                        <input class="form-control" name="testimonial_feedbacks" value="<?php echo $testimonial_feedbacks; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Name</label>
                        <input class="form-control" name="testimonial_users" value="<?php echo $testimonial_users; ?>">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Origin</label>
                        <input class="form-control" name="testimonial_origins" value="<?php echo $testimonial_origins; ?>">
                    </div>
                </div>
                <!-- End Why Choose Us Section -->
                <div class="col-md-8">
                    <iframe id='frame' src="../index.php" width="100%" height="90%" ></iframe>
                </div>
            </div>

             <div class="form-group text-center">
                    <button class="btn btn-success" type="submit" name="btn_save">Save</button>
            </div>

        </form>
	</div>

</div>

<?php include ('_footer.php');?>