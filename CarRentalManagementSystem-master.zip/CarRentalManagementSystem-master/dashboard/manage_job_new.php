<?php
include("_header.php");
func_setReqVar();
$sql = "SELECT * FROM user WHERE id=" . $_SESSION['cid'];
db_select($sql);
if (db_rowcount() > 0) {
    func_setSelectVar();
}
if (isset($btn_save)) {
    func_setValid("Y");
    if (func_isValid()) {
        $sql = "INSERT INTO job
			(
			user_id,
            job_title,
            job_desc,
            assign_by,
            due_date
			)
			VALUES
			(
			'" . conv_text_to_dbtext3($user) . "', 
			'" . conv_text_to_dbtext3($job_title) . "',
            '" . conv_text_to_dbtext3($job_desc) . "',
            '" . conv_text_to_dbtext3($name) . "',
            '" . conv_datetodbdate($due_date) . "'
			)
			";
        db_update($sql);
        vali_redirect('manage_job.php?btn_search=&search_name=' . $search_name . '&page=' . $page);
    }
} ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Job List</h4>
                </div>
            <div class="card-content">
            <form method="POST">
						<span style="color:red"><?php echo func_getErrMsg();?></span>
                        <div class="form-group label-floating">
                                    <label class="control-label">Assigned to</label>
                                        <select name="user" class="form-control">
                                            <?php
                                            $sql = "SELECT id, name FROM user"; db_select($sql); if(db_rowcount()>0){ for($j=0;$j<db_rowcount();$j++){ $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$user,'Selected','').">".db_get($j,1)."</option>"; } } echo $value; ?>
                                        </select>
                                </div>

                                <div class="form-group label-floating">
                                    <label class="control-label">Due Date</label>
                                    <input class="form-control" name="due_date" type="text" value="<?php echo $due_date; ?>"> 
                                </div>
                                
                                <div class="form-group label-floating">
                                    <label class="control-label">Job Title</label>
                                    <input class="form-control" name="job_title" type="text" value="<?php echo $job_title; ?>"> 
                                </div>

                                <div class="form-group label-floating">
                                    <label class="control-label">Job Description</label>
                                    <input class="form-control" name="job_desc" type="text" value="<?php echo $job_desc; ?>"> 
                                </div>

                                   <div class="form-group">
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                            <button type="button" class="btn btn-info" onclick="location.href='manage_job.php?btn_search=&search_name=<?php echo $search_name;?>&page=<?php echo $page;?>'" name="btn_cancel">Cancel</button>
                                        </div>
                                    </div>
					</form>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php'); ?>

<script>
        $(document).ready(function () {
            var date_input = $('input[name="due_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
            date_input.datepicker(options);
        })
    </script>

