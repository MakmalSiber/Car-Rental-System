<?php
include("_header.php");
func_setReqVar();

if (isset($btn_save)) {
    func_setValid("Y");
    $id = $_GET['id'];
    if (func_isValid()) {
        if ($max_weight == "") {
            $max_weight = 0;
        }
        $sql = "UPDATE vehicle 
			SET reg_no ='$reg_no',
            class_id = '$class_id',
            engine_no = '$egn_no',
            chasis_no = '$chs_no',
            make ='$make',
            model ='$model',
            year ='$year',
            color ='$color',
            location_id ='$location_id',
            availability ='$availability',
			rate_type ='$rate_type', 
            power_type ='$power_type'
			WHERE id = '$id'";
        db_update($sql);
        if ($_POST['property'] == "company") {
            vali_redirect("manage_vehicle.php");
        } elseif ($_POST['property'] == "investor") {
            vali_redirect("investor_details_edit.php?id=$id");
        }
    }
} else {
    $sql = "SELECT * FROM vehicle WHERE id=" . $_GET['id'];
    db_select($sql);
    if (db_rowcount() > 0) {
        func_setSelectVar();
    }
} ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Vehicle</h4>
                </div>
            <div class="card-content">
            <form method="POST">
						<span style="color:red"><?php echo func_getErrMsg();?></span>

					    <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                            <label class="control-label">Vehicle Class</label>
                                            <select name="class_id" class="form-control">
                                            <?php  $value = ""; $sql = "SELECT id, class_name FROM class WHERE status = 'A'"; db_select($sql); if(db_rowcount()>0){ for($j=0;$j<db_rowcount();$j++){ $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$class_id,'Selected','').">".db_get($j,1). "</option>"; } } echo $value; ?>
                                            </select>
                                    </div>
                            </div>          
                        </div>
						
                        <div class="row">
                        <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Registration Number</label>
							<input type="text" class="form-control" name="reg_no" value="<?php echo $reg_no;?>">
						</div>
                        </div>
                        <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Engine Number</label>
								<input type="text" class="form-control" name="egn_no" value="<?php echo $engine_no;?>">
						</div>
                        </div>
                        <div class="col-md-4">
                        <div class="form-group label-floating">
							<label class="control-label">Chasis Number</label>
								<input type="text" class="form-control" name="chs_no" value="<?php echo $chasis_no;?>">
						</div>
                        </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group label-floating">
                                <label class="control-label">Make</label>
                                <input type="text" class="form-control" name="make" value="<?php echo $make;?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group label-floating">
                                    <label class="control-label">Model</label>
                                    <input type="text" class="form-control" name="model" value="<?php echo $model;?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Year</label>
                                        <input type="text" class="form-control" name="year" value="<?php echo $year;?>">
                                    </div>
                            </div>
                            <div class="col-md-3">
                                    <div class="form-group label-floating">
                                    <label class="control-label">Color</label>
                                    <input type="text" class="form-control" name="color" value="<?php echo $color;?>">
                                </div>
                            </div>
                        </div>
                           
                            <!-- <div class="col-md-6">
                                <div class="form-group label-floating">
                                    <label class="control-label">Transmission</label>
                                        <select name="transmission" class="form-control">
                                            <option value='A' <?php echo vali_iif('A'==$transmission,'Selected','');?>>Automatic</option>
                                            <option value='M' <?php echo vali_iif('M'==$transmission,'Selected','');?>>Manual</option>
                                        </select>                                    
                                </div>
                            </div> -->
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Location</label>
                                        <select class="form-control" name="location_id">
                                            <?php  $value = ""; $sql = "SELECT id, description, `default` from location"; db_select($sql); if(db_rowcount()>0){ for($j=0;$j<db_rowcount();$j++){ $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$location_id,'Selected','').">".db_get($j,1)."</option>"; } } echo $value; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Engine</label>
                                            <input type="text" class="form-control" name="engine" value="<?php echo $engine; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Power Type</label>
                                            <select name="power_type" class="form-control">
                                                <option value='Fuel' <?php echo vali_iif('Fuel' == $power_type, 'Selected', ''); ?>>Fuel</option>
                                                <option value='Diesel' <?php echo vali_iif('Diesel' == $power_type, 'Selected', ''); ?>>Diesel</option>
                                                <option value='Gas' <?php echo vali_iif('Gas' == $power_type, 'Selected', ''); ?>>Gas</option>
                                                <option value='Electric' <?php echo vali_iif('Electric' == $power_type, 'Selected', ''); ?>>Electric</option>
                                                <option value='Hybrid' <?php echo vali_iif('Hybrid' == $power_type, 'Selected', ''); ?>>Hybrid</option>
                                            </select>
                                        </div>
                                    </div>
                            </div>

                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group label-floating">
								<select name="availability" class="form-control">\
									<option value="">Availability</option>
									<option value='Available' <?php echo vali_iif('Available'==$availability,'Selected','');?>>Available</option>
									<option value='Maintenance' <?php echo vali_iif('Maintenance'==$availability,'Selected','');?>>Maintenance</option>
									<option value='Accident' <?php echo vali_iif('Accident'==$availability,'Selected','');?>>Accident</option>
									<option value='Accident Total Lost' <?php echo vali_iif('Accident Total Lost'==$availability,'Selected','');?>>Accident Total Lost</option>
									<option value='Sold' <?php echo vali_iif('Sold'==$availability,'Selected','');?>>Sold</option>
									<option value='Pending Sale' <?php echo vali_iif('Pending Sale'==$availability,'Selected','');?>>Pending Sale</option>
									<option value='List On Site For Sale' <?php echo vali_iif('List On Site For Sale'==$availability,'Selected','');?>>List On Site For Sale</option>
									<option value='Disposed' <?php echo vali_iif('Disposed'==$availability,'Selected','');?>>Disposed</option>
								</select>
						</div>
                            </div>
							<div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Car Owned By</label>
                                        <select name="property" class="form-control">
                                            <option name="company" value="company">Company</option>
                                            <option name="investor" value="investor">Investor</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
  
                        <div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save & Next</button>
								<button type="button" class="btn btn-warning" onclick="location.href='manage_vehicle.php?btn_search=Search&page=<?php echo $page;?>&search_name=<?php echo $search_name;?>'" name="btn_cancel">Cancel</button>
							</div>
						</div>
						
					</form>
            </div>
        </div>
    </div>
</div>

<?php
 include('_footer.php'); ?>