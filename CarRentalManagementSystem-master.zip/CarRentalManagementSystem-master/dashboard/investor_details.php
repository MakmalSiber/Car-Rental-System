<?php
include ('_header.php');

func_setReqVar();

if (isset($btn_save)) {

    func_setValid("Y");
    
    if(func_isValid()){
			
        $sql="INSERT INTO investor
                (
                vehicle_id, 
                name,
                address, 
                nric, 
                phone_no,
                loan_account_no,
                owner_account_no,
                cdate
                )
                VALUES
                (
                '$id',
                '$name',
                '$address',
                '$nric',
                '$phone_no', 
                '$loan_account_no',
                '$owner_account_no',
                CURRENT_TIMESTAMP 			
                )
                ";
            
        //echo $sql;
        db_update($sql);

        vali_redirect("vehicle_rate.php?id=".$id."&btn_search=Search&page=".$page."&search_name=".$search_name);
    }
} else {
    $sql = "SELECT * FROM investor WHERE vehicle_id=".$_GET['id'];
			db_select($sql);
			if(db_rowcount()>0){
				func_setSelectVar();
			}
}
?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" data-background-color="orange">
                        <h4 class="title">Rental Options</h4>
                    </div>
                    <div class="card-content">
                        <form method="POST">
                            <span style="color:red">
                                <?php echo func_getErrMsg(); ?>
                            </span>

                            <div class="form-group label-floating">
                                <label class="control-label">Name</label>
                                <textarea class="form-control" name="name"><?php echo $name; ?></textarea>
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Address</label>
                                <textarea class="form-control" name="address"><?php echo $address; ?></textarea>
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">NRIC</label>
                                <input type="text" class="form-control" name="nric" value="<?php echo $nric; ?>">
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Phone Number</label>
                                <input type="text" class="form-control" name="phone_no" value="<?php echo $phone_no; ?>">
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Loan Account Number</label>
                                <input type="text" class="form-control" name="loan_account_no" value="<?php echo $loan_account_no; ?>">
                            </div>

                            <div class="form-group label-floating">
                                <label class="control-label">Owner Account Number</label>
                                <input type="text" class="form-control" name="owner_account_no" value="<?php echo $owner_account_no; ?>">
                            </div>

                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                    <button type="button" class="btn btn-warning" onclick="location.href='manage_vehicle.php?btn_search=&search_rental_description=<?php echo $search_rental_description; ?>'">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php include('_footer.php'); ?>