<?php
include '_header.php';
require("lib/phpmailer/class.phpmailer.php");

$day = dateDifference(conv_datetodbdate($_GET['search_pickup_date']), conv_datetodbdate($_GET['search_return_date']), '%a');
$time = dateDifference($_GET['search_pickup_time'], $_GET['search_return_time'], '%h');

$sql = "SELECT * FROM car_rate WHERE class_id=" . $_GET['class_id'];

db_select($sql);

if (db_rowcount() > 0) {
	func_setSelectVar();
}

$difference_hour = $time - 12;

if ($day == 0) {
	$subtotal = $time * $hour;
	if ($time == 12) {
		$subtotal = $halfday;
	} elseif ($time >= 13){
		$subtotal = $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 1) {
	$subtotal = $oneday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $oneday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $oneday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 2) {
	$subtotal = $twoday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $twoday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $twoday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 3) {
	$subtotal = $threeday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $threeday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $threeday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 4) {
	$subtotal = $fourday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $fourday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $fourday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 5) {
	$subtotal = $fiveday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $fiveday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $fiveday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 6) {
	$subtotal = $sixday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $sixday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $sixday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 7) {
	$subtotal = $weekly + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $halfday + ($hour * $difference_hour);
	}
}  elseif ($day == 8) {
	$subtotal = $weekly + $oneday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $oneday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $oneday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 9) {
	$subtotal = $weekly + $twoday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $twoday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $twoday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 10) {
	$subtotal = $weekly + $threeday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $threeday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $threeday + $halfday + ($hour * $difference_hour);
	}	
} elseif($day == 11) {
	$subtotal = $weekly + $fourday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $fourday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $fourday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 12) {
	$subtotal = $weekly + $fiveday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $fiveday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $fiveday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 13) {
	$subtotal = $weekly + $sixday + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $sixday + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $sixday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 14) {
	$subtotal = $weekly + $weekly + ($time * $hour);
	if ($time == 12) {
		$subtotal = $weekly + $weekly + $halfday;
	} elseif ($time >= 13){
		$subtotal = $weekly + $weekly + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 15) {
	$subtotal = ($weekly * 2) + $oneday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $oneday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $oneday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 16) {
	$subtotal = ($weekly * 2) + $twoday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $twoday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $twoday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 17) {
	$subtotal = ($weekly * 2) + $threeday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $threeday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $threeday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 18) {
	$subtotal = ($weekly * 2) + $fourday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $fourday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $fourday + $halfday + ($hour * $difference_hour);
	}
} elseif($day == 19) {
	$subtotal = ($weekly * 2) + $fiveday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $fiveday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $fiveday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 20) {
	$subtotal = ($weekly * 2) + $sixday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $sixday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $sixday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 21) {
	$subtotal = ($weekly * 2) + $weekly + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 2) + $weekly + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 2) + $weekly + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 22) {
	$subtotal = ($weekly * 3) + $oneday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $oneday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $oneday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 23) {
	$subtotal = ($weekly * 3) + $twoday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $twoday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $twoday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 24) {
	$subtotal = ($weekly * 3) + $threeday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $threeday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $threeday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 25) {
	$subtotal = ($weekly * 3) + $fourday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $fourday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $fourday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 26) {
	$subtotal = ($weekly * 3) + $fiveday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $fiveday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $fiveday + $halfday + ($hour * $difference_hour);
	}
} else if ($day == 27) {
	$subtotal = ($weekly * 3) + $sixday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $oneday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $oneday + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 28) {
	$subtotal = ($weekly * 3) + $weekly + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 3) + $weekly + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 3) + $weekly + $halfday + ($hour * $difference_hour);
	}
} elseif ($day == 29) {
	$subtotal = ($weekly * 4) + $oneday + ($time * $hour);
	if ($time == 12) {
		$subtotal = ($weekly * 4) + $oneday + $halfday;
	} elseif ($time >= 13){
		$subtotal = ($weekly * 4) + $oneday + $halfday + ($hour * $difference_hour);
	}	
} elseif ($day == 30) {
	$subtotal = $monthly + ($time * $hour);
	if($time == 12){
		$subtotal = $monthly + $halfday;
	} elseif ($time >= 13){
		$subtotal = $monthly + $halfday + ($hour * $difference_hour);
	}
} 

$six_digit_random_number = mt_rand(100000, 999999);

func_setReqVar();
if (isset($btn_save)) {
	func_setValid("Y");
	func_isEmpty($nric_no, "nric no");
	func_isEmpty($title, "title");
	func_isEmpty($firstname, "first name");
	func_isEmpty($lastname, "last name");
	func_isEmpty($license_no, "license no");
	func_isEmpty($age, "age");
	func_isNum($age, "age");
	func_isEmpty($phone_no, "phone no");
	func_isEmpty($postcode, "postcode");
	func_isEmpty($city, "city");
	func_isEmpty($country, "country");
	func_isEmpty($payment_amount, "payment amount");
	func_isEmpty($ref_name, "reference name");
	func_isEmpty($ref_relationship, "reference relationship");
	func_isEmpty($ref_address, "reference address");
	func_isEmpty($ref_phoneno, "reference phone no");
	func_isNum($payment_amount, "payment amount");
	if (func_isValid()) {
		$sql = "UPDATE vehicle SET availability = 'Booked' WHERE vehicle.id=" . $_GET['vehicle_id'];
		db_update($sql);
		$sql = "INSERT INTO customer
			(
			title,
			firstname,
			lastname,
			nric_no,
			license_no,
			license_exp,
			age,
			phone_no,
			email,
			address,
			postcode,
			city,
			country,
			status,
			cid,
			cdate,
			ref_name,
			ref_phoneno,
			ref_relationship,
			ref_address,
			drv_name,
			drv_nric,
			drv_address,
			drv_phoneno,
			drv_license_no,
			drv_license_exp,
			survey_type,
			survey_details
			)
			VALUES
			(
			'" . conv_text_to_dbtext3($title) . "',
			'" . conv_text_to_dbtext3($firstname) . "',
			'" . conv_text_to_dbtext3($lastname) . "',
			'" . conv_text_to_dbtext3($nric_no) . "',
			'" . conv_text_to_dbtext3($license_no) . "',
			'" . conv_datetodbdate($license_exp) . "',
			" . $age . ",
			'" . conv_text_to_dbtext3($phone_no) . "',
			'" . conv_text_to_dbtext3($email) . "',
			'" . conv_text_to_dbtext3($address) . "',
			'" . conv_text_to_dbtext3($postcode) . "',
			'" . conv_text_to_dbtext3($city) . "',
			'" . conv_text_to_dbtext3($country) . "',
			'A',
			" . $_SESSION['cid'] . ",
			CURRENT_TIMESTAMP,
			'" . conv_text_to_dbtext3($ref_name) . "',
			'" . conv_text_to_dbtext3($ref_phoneno) . "',
			'" . conv_text_to_dbtext3($ref_relationship) . "',
			'" . conv_text_to_dbtext3($ref_address) . "',
			'" . conv_text_to_dbtext3($drv_name) . "',
			'" . conv_text_to_dbtext3($drv_nric) . "',
			'" . conv_text_to_dbtext3($drv_address) . "',
			'" . conv_text_to_dbtext3($drv_phoneno) . "',
			'" . conv_text_to_dbtext3($drv_license_no) . "',
			'" . conv_datetodbdate($drv_license_exp) . "',
			'$survey_type',
			'" . conv_text_to_dbtext3($survey_details) . "'
			)
			";
		db_update($sql);
		$sql = "SELECT LAST_INSERT_ID() FROM customer";
		db_select($sql);
		if (db_rowcount() > 0) {
			$id = db_get(0, 0);
		}

		if ($_GET['pickup_cost'] >= 1) {
			$sql = "INSERT INTO booking_trans
					   (
					agreement_no,
					   pickup_date,
					   pickup_location,
					   pickup_time,
					   return_date,
					   return_location,
					   return_time,
					   option_rental_id,
					   cdw,
					   discount_id,
					   vehicle_id,
					   status,
					   day,
					   sub_total,
					   gst,
					   est_total,
					   customer_id,
					   cdate,
					   refund_dep,
					   type,
					   balance,
					   p_cost,
					   p_address,
					   p_address2
					   )
					   VALUES
					   (
					'$six_digit_random_number',
					   '" . conv_datetodbdate($_GET['search_pickup_date']) . "',
					   '$search_pickup_location',
					   '$search_pickup_time',
					   '" . conv_datetodbdate($_GET['search_return_date']) . "',
					   '$search_return_location',
					   '$search_return_time',
					   0,
					   0,
					   0,
					   " . $_GET['vehicle_id'] . ",
					   'B',
					   '$day',
					   '$subtotal',
					   '$gsthidden',
					   '$grand_total',
					   '$id',
					   CURRENT_TIMESTAMP,
					   '$deposit',
					   0,
					   '$payment_amount',
					   " . $_GET['pickup_cost'] . ",
					   '" . conv_text_to_dbtext3($_GET['p_pickup_address']) . "',
					   '" . conv_text_to_dbtext3($_GET['r_pickup_address']) . "'
					   )
					   ";
			db_update($sql);
		} elseif ($_GET['delivery_cost'] >= 1) {
			$sql = "INSERT INTO booking_trans
					   (
					agreement_no,
					   pickup_date,
					   pickup_location,
					   pickup_time,
					   return_date,
					   return_location,
					   return_time,
					   option_rental_id,
					   cdw,
					   discount_id,
					   vehicle_id,
					   status,
					   day,
					   sub_total,
					   payment_details,
					   gst,
					   est_total,
					   customer_id,
					   cdate,
					   refund_dep,
					   refund_dep_payment,
					   type,
					   balance,
					   r_cost,
					   r_address,
					   r_address2
					   )
					   VALUES
					   (
					'$six_digit_random_number',
					   '" . conv_datetodbdate($_GET['search_pickup_date']) . "',
					   '$search_pickup_location',
					   '$search_pickup_time',
					   '" . conv_datetodbdate($_GET['search_return_date']) . "',
					   '$search_return_location',
					   '$search_return_time',
					   0,
					   0,
					   0,
					   " . $_GET['vehicle_id'] . ",
					   'B',
					   '$day',
					   '$subtotal',
					   '$payment_details',
					   '$gsthidden',
					   '$grand_total',
					   '$id',
					   CURRENT_TIMESTAMP,
					   '$deposit',
					   '$refund_dep_payment',
					   0,
					   '$payment_amount',
					   " . $_GET['delivery_cost'] . ",
					   '" . conv_text_to_dbtext3($_GET['p_delivery_address']) . "',
					   '" . conv_text_to_dbtext3($_GET['r_delivery_address']) . "'
					   )
					   ";
			db_update($sql);
		} else {
			$sql = "INSERT INTO booking_trans
					   (
					agreement_no,
					   pickup_date,
					   pickup_location,
					   pickup_time,
					   return_date,
					   return_location,
					   return_time,
					   option_rental_id,
					   cdw,
					   discount_id,
					   vehicle_id,
					   status,
					   day,
					   sub_total,
					   payment_details,
					   gst,
					   est_total,
					   customer_id,
					   cdate,
					   refund_dep,
					   refund_dep_payment,
					   type,
					   balance
					   )
					   VALUES
					   (
					'$six_digit_random_number',
					   '" . conv_datetodbdate($_GET['search_pickup_date']) . "',
					   '$search_pickup_location',
					   '$search_pickup_time',
					   '" . conv_datetodbdate($_GET['search_return_date']) . "',
					   '$search_return_location',
					   '$search_return_time',
					   0,
					   0,
					   0,
					   " . $_GET['vehicle_id'] . ",
					   'B',
					   '$day',
					   '$subtotal',
					   '$payment_details',
					   '$gsthidden',
					   '$grand_total',
					   '$id',
					   CURRENT_TIMESTAMP,
					   '$deposit',
					   '$refund_dep_payment',
					   0,
					   '$payment_amount'
					   )
					   ";
			db_update($sql);
		}

		$sql = "SELECT LAST_INSERT_ID() FROM booking_trans";
		db_select($sql);
		if (db_rowcount() > 0) {
			$booking_id = db_get(0, 0);
		}

		$sql = "INSERT INTO checklist (booking_trans_id) VALUES ($booking_id)";
		db_update($sql);

		echo '<script language="javascript">';
		echo 'alert("Successfully booking!")';
		echo '</script>';

		vali_redirect("mail.php?id=" . $booking_id);
	}

}
?>


<style>
.col-xs-5ths,
.col-sm-5ths,
.col-md-5ths,
.col-lg-5ths {
    position: relative;
    min-height: 1px;
    padding-right: 15px;
    padding-left: 15px;
}

.col-xs-5ths {
    width: 20%;
    float: left;
}

@media (min-width: 768px) {
    .col-sm-5ths {
        width: 20%;
        float: left;
    }
}

@media (min-width: 992px) {
    .col-md-5ths {
        width: 20%;
        float: left;
    }
}

@media (min-width: 1200px) {
    .col-lg-5ths {
        width: 20%;
        float: left;
    }
}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			    <div class="card">
                    <div class="card-header" data-background-color="orange">
                        <h4 class="title">Counter Reservation</h4>
                    </div>
                    <div class="card-content">
						<div class="row">
							 <div class="col-md-5ths col-xs-6">
										<div class="form-group">
											<label class="control-label">Base Rate</label>
											<input class="form-control" value="<?php echo dateDifference(conv_datetodbdate($search_pickup_date) . $search_pickup_time, conv_datetodbdate($search_return_date) . $search_return_time, '%a Day %h Hours'); ?>" disabled>
										</div>
							</div>
							<div class="col-md-5ths col-xs-6">
										<div class="form-group">
											<label class="control-label">Discount (MYR)</label>
											<label class="form-control" disabled>
										</div>
							</div>
							<div class="col-md-5ths col-xs-6">
										<div class="form-group">
											<label class="control-label">Sub Total (MYR)</label>
											<input class="form-control" type="text" value="<?php echo number_format($subtotal,2); ?>" name="subtotal" id="subtotal" disabled>
										</div>
							</div>
							<div class="col-md-5ths col-xs-6">
										<div class="form-group">
											<label class="control-label">GST (MYR)</label>
											<input class="form-control" type="text" value="<?php echo 'Non'; ?>" name="gsthidden" disabled>
										</div>
							</div>
							<div class="col-md-5ths col-xs-6">
										<div class="form-group">
											<label class="control-label">Grand Total (MYR)</label>
											<?php $est_total = $subtotal + $_GET['delivery_cost'] + $_GET['pickup_cost'];
											$grand_total = $est_total;
											?>
											<input class="form-control" type="text" value="<?php echo number_format($grand_total,2); ?>" name="est_total" disabled>
										</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="table-responsive">
										<table class="table">
											<thead>
											<?php
												$sql = "SELECT description, amount, taxable FROM option_rental";
												db_select($sql);
												if (db_rowcount() > 0) {
													for ($i = 0; $i < db_rowcount(); $i++) {
														echo "<tr>
																<td>
																	<input type='checkbox' value='Y' " . vali_iif('Y' == $description[$i], 'Checked', '') . " name='description[$i].' onclick='calcPrice(document.getElementById(\"subtotal\").value,\"" . db_get($i, 0) . "\",document.getElementById(\"qty[$i]\").value,\"" . db_rowcount() . "\")' id='description[$i]'></td>
																<td>" . db_get($i, 0) . "</td>
																<td>
																	<select name='number' class='form-control m-b' style='width:5em' id='qty[$i]'>
																		<option value='1' " . vali_iif('1' == $number, 'Selected', '') . ">1</option>
																		<option value='2' " . vali_iif('2' == $number, 'Selected', '') . ">2</option>
																		<option value='3' " . vali_iif('3' == $number, 'Selected', '') . ">3</option>
																		<option value='4' " . vali_iif('4' == $number, 'Selected', '') . ">4</option>
																		<option value='5' " . vali_iif('5' == $number, 'Selected', '') . ">5</option>
																	</select>
																</td>
																<td>
																	RM&nbsp;" . db_get($i, 1) . "
																</td>
															</tr>";
													}
												}
												?>
													<tr>
														<td><input type="checkbox" value='Y' <?php echo vali_iif('Y' == $cdw, 'Checked', ''); ?> name="cdw"></td>
														<td>C.D.W</td>
														<td colspan="2">13.00 % Per Day</td>
													</tr>
										</thead>
									</table>
								</div>
							</div>
						</div>

							<div class="row">

								<div class="col-md-3">
									<div class="form-group">
										<label class="control-label">Pickup Location</label>
											<?php
											$sql = "SELECT id, description from location WHERE id=" . $_GET['search_pickup_location'];
											db_select($sql);if (db_rowcount() > 0) {$pickup_location = db_get(0, 1);}
											?>
										<input class="form-control" value="<?php echo $pickup_location; ?>">
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label class="control-label">Pickup Date & Time</label>
										<input class="form-control" value="<?php echo $_GET['search_pickup_date'] . "@" . $_GET['search_pickup_time']; ?>">
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label class="control-label">Return Location</label>
											<?php
											$sql = "SELECT id, description from location WHERE id=" . $_GET['search_return_location'];
											db_select($sql);if (db_rowcount() > 0) {$return_location = db_get(0, 1);}
											?>
										<input class="form-control" value="<?php echo $return_location; ?>">
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label class="control-label">Return Date & Time</label>
										<input class="form-control" value="<?php echo $_GET['search_return_date'] . "@" . $_GET['search_return_time']; ?>">
									</div>
								</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Coupon Code</label>
									<input type="text" class="form-control" name="code" value="<?php echo $code; ?>">
									<div class="text-center">
										<button type="submit" class="btn btn-success" name="btn_redeem">Redeem</button>
									</div>
								</div>
							</div>
						</div>

							<form method="POST">

								<span style="color:red"><?php echo func_getErrMsg(); ?></span>

								<div class="row">
									<div class="col-md-12">
										<center>
											<div class="alert alert-warning" role="alert">
												<b>Customer Information</b>
											</div>
										</center>
									</div>
								</div>

								<div class="row">
									<div class="col-md-3">
											<div class="form-group">
												<label class="control-label">NRIC No</label>
												<input type="text" class="form-control" placeholder="NRIC No" name="nric_no" value="<?php echo $nric_no; ?>" onblur="selectNRIC(this.value)">
											</div>
										</div>
										<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Title</label>
											<select name="title" class="form-control" id="title">
												<option <?php echo vali_iif('Mr.' == $title, 'Selected', ''); ?> value='Mr.'>Mr.</option>
												<option <?php echo vali_iif('Mrs.' == $title, 'Selected', ''); ?> value='Mrs.'>Mrs.</option>
												<option <?php echo vali_iif('Miss.' == $title, 'Selected', ''); ?> value='Miss.'>Miss.</option>
											</select>
										</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label class="control-label">First Name</label>
												<input type="text" class="form-control" placeholder="First Name" name="firstname" id="firstname" value="<?php echo $firstname; ?>">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label class="control-label">Last Name</label>
												<input type="text" class="form-control" placeholder="Last Name" name="lastname" id="lastname" value="<?php echo $lastname; ?>" id="lastname">
											</div>
										</div>
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Driver's Age</label>
											<input type="text" class="form-control" placeholder="Age" name="age" value="<?php echo $age; ?>" id="age">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Phone No</label>
											<input type="text" class="form-control" placeholder="Phone No" name="phone_no" value="<?php echo $phone_no; ?>" id="phone_no">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Email</label>
											<input type="text" class="form-control" placeholder="Email" name="email" value="<?php echo $email; ?>" id="email">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">License Number</label>
											<input type="text" class="form-control" placeholder="License No" name="license_no" value="<?php echo $license_no; ?>" id="license_no">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">License Expired</label>
											<input type="text" class="form-control" placeholder="License No" name="license_exp" value="<?php echo $license_exp; ?>" id="license_no">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Address</label>
											<input class="form-control" placeholder="Address" name="address" id="address" value="<?php echo $address; ?>">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Postcode</label>
											<input type="text" class="form-control" placeholder=" Postcode" name="postcode" value="<?php echo $postcode; ?>" id="postcode">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
												<label class="control-label">City</label>
													<select name="city" class="form-control" id="city">
														<option value="">Please Select</option>
														<option <?php echo vali_iif('Perlis' == $city, 'Selected', ''); ?> value='Perlis'>Perlis</option>
														<option <?php echo vali_iif('Kedah' == $city, 'Selected', ''); ?> value='Kedah'>Kedah</option>
														<option <?php echo vali_iif('Pulau Pinang' == $city, 'Selected', ''); ?> value='Pulau Pinang'>Pulau Pinang</option>
														<option <?php echo vali_iif('Perak' == $city, 'Selected', ''); ?> value='Perak'>Perak</option>
														<option <?php echo vali_iif('Selangor' == $city, 'Selected', ''); ?> value='Selangor'>Selangor</option>
														<option <?php echo vali_iif('Wilayah Persekutuan Kuala Lumpur' == $city, 'Selected', ''); ?> value='Wilayah Persekutuan Kuala Lumpur'>Wilayah Persekutuan Kuala Lumpur</option>
														<option <?php echo vali_iif('Wilayah Persekutuan Putrajaya' == $city, 'Selected', ''); ?> value='Wilayah Persekutuan Putrajaya'>Wilayah Persekutuan Putrajaya</option>
														<option <?php echo vali_iif('Melaka' == $city, 'Selected', ''); ?> value='Melaka'>Melaka</option>
														<option <?php echo vali_iif('Negeri Sembilan' == $city, 'Selected', ''); ?> value='Negeri Sembilan'>Negeri Sembilan</option>
														<option <?php echo vali_iif('Johor' == $city, 'Selected', ''); ?> value='Johor'>Johor</option>
														<option <?php echo vali_iif('Pahang' == $city, 'Selected', ''); ?> value='Pahang'>Pahang</option>
														<option <?php echo vali_iif('Terengganu' == $city, 'Selected', ''); ?> value='Terengganu'>Terengganu</option>
														<option <?php echo vali_iif('Kelantan' == $city, 'Selected', ''); ?> value='Kelantan'>Kelantan</option>
														<option <?php echo vali_iif('Sabah' == $city, 'Selected', ''); ?> value='Sabah'>Sabah</option>
														<option <?php echo vali_iif('Sarawak' == $city, 'Selected', ''); ?> value='Sarawak'>Sarawak</option>
													</select>
											</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
												<label class="control-label">Country</label>
													<select ui-jq="chosen" name="country" class="form-control" id="country">
														<optgroup label="Alaskan/Hawaiian Time Zone">
															<option value="AK">Alaska</option>
															<option value="HI">Hawaii</option>
															<option value="MY" selected>Malaysia</option>
														</optgroup>
														<optgroup label="Pacific Time Zone">
															<option value="CA">California</option>
															<option value="NV">Nevada</option>
															<option value="OR">Oregon</option>
															<option value="WA">Washington</option>
														</optgroup>
														<optgroup label="Mountain Time Zone">
															<option value="AZ">Arizona</option>
															<option value="CO">Colorado</option>
															<option value="ID">Idaho</option>
															<option value="MT">Montana</option><option value="NE">Nebraska</option>
															<option value="NM">New Mexico</option>
															<option value="ND">North Dakota</option>
															<option value="UT">Utah</option>
															<option value="WY">Wyoming</option>
														</optgroup>
														<optgroup label="Central Time Zone">
															<option value="AL">Alabama</option>
															<option value="AR">Arkansas</option>
															<option value="IL">Illinois</option>
															<option value="IA">Iowa</option>
															<option value="KS">Kansas</option>
															<option value="KY">Kentucky</option>
															<option value="LA">Louisiana</option>
															<option value="MN">Minnesota</option>
															<option value="MS">Mississippi</option>
															<option value="MO">Missouri</option>
															<option value="OK">Oklahoma</option>
															<option value="SD">South Dakota</option>
															<option value="TX">Texas</option>
															<option value="TN">Tennessee</option>
															<option value="WI">Wisconsin</option>
														</optgroup>
														<optgroup label="Eastern Time Zone">
															<option value="CT">Connecticut</option>
															<option value="DE">Delaware</option>
															<option value="FL">Florida</option>
															<option value="GA">Georgia</option>
															<option value="IN">Indiana</option>
															<option value="ME">Maine</option>
															<option value="MD">Maryland</option>
															<option value="MA">Massachusetts</option>
															<option value="MI">Michigan</option>
															<option value="NH">New Hampshire</option><option value="NJ">New Jersey</option>
															<option value="NY">New York</option>
															<option value="NC">North Carolina</option>
															<option value="OH">Ohio</option>
															<option value="PA">Pennsylvania</option><option value="RI">Rhode Island</option><option value="SC">South Carolina</option>
															<option value="VT">Vermont</option><option value="VA">Virginia</option>
															<option value="WV">West Virginia</option>
														</optgroup>
													</select>
												</div>
											</div>
									</div>
								
								<div class="row">
									<div class="col-md-12">
										<center>
											<div class="alert alert-warning" role="alert">
												<b>Additional Driver Information</b>
											</div>
										</center>
									</div>
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Name</label>
											<input type="text" class="form-control" placeholder="Name" name="drv_name" value="<?php echo $drv_name; ?>">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">IC No. / Passport</label>
											<input type="text" class="form-control" placeholder="IC No. / Passport" name="drv_nric" value="<?php echo $drv_nric; ?>">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Address</label>
											<input class="form-control" placeholder="Address" name="drv_address" value="<?php echo $drv_address; ?>">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Phone No</label>
											<input type="text" class="form-control" placeholder="Phone No" name="drv_phoneno" value="<?php echo $drv_phoneno; ?>" id="ref_phoneno">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">License No.</label>
											<input class="form-control" type="text" placeholder="License No." name="drv_license_no" value="<?php echo $drv_license_no; ?>">
										</div>
									</div>
									<div class="col-md-4">
									<div class="form-group">
											<label class="control-label">License Expired </label>
											<input class="form-control" type="text" placeholder="License Expired" name="drv_license_exp" id="drv_license_exp" value="<?php echo $drv_license_exp; ?>">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-12">
										<center>
											<div class="alert alert-warning" role="alert">
												<b>Reference Information</b>
											</div>
										</center>
									</div>
								</div>

								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Reference Name</label>
											<input type="text" class="form-control" placeholder="Reference Name" name="ref_name" value="<?php echo $ref_name; ?>" id="ref_name">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
												<label class="control-label">Reference Relationship</label>
												<input type="text" class="form-control" placeholder="Reference Relationship" name="ref_relationship" value="<?php echo $ref_relationship; ?>" id="ref_relationship">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Reference Address</label>
											<input class="form-control" placeholder="Reference Address" name="ref_address" id="ref_address" value="<?php echo $ref_address; ?>">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Reference Phone No</label>
											<input type="text" class="form-control" placeholder="Reference Phone No" name="ref_phoneno" value="<?php echo $ref_phoneno; ?>" id="ref_phoneno">
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-12">
										<center>
											<div class="alert alert-warning" role="alert">
												<b>Payment Information</b>
											</div>
										</center>
									</div>
								</div>

								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Payment Amount (MYR)</label>
											<input type="text" class="form-control" placeholder="Payment Amount" name="payment_amount" value="<?php echo $payment_amount; ?>" id="payment_amount">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Payment Status</label>
											<select name="payment_details" class="form-control">
													<option value="">Please Select</option>
													<option <?php echo vali_iif('Cash' == $payment_details, 'Selected', ''); ?> value='Cash'>Cash</option>
													<option <?php echo vali_iif('Online' == $payment_details, 'Selected', ''); ?> value='Online'>Online</option>
													<option <?php echo vali_iif('Card' == $payment_details, 'Selected', ''); ?> value='Card'>Card</option>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Deposit (MYR)</label>
											<select name="deposit" class="form-control">
														<option value="">Please Select</option>
														<option <?php echo vali_iif('50' == $deposit, 'Selected', ''); ?> value='50'>RM50</option>
														<option <?php echo vali_iif('100' == $deposit, 'Selected', ''); ?> value='100' selected>RM100</option>
														<option <?php echo vali_iif('200' == $deposit, 'Selected', ''); ?> value='200'>RM200</option>
														<option <?php echo vali_iif('300' == $deposit, 'Selected', ''); ?> value='300'>RM300</option>
														<option <?php echo vali_iif('400' == $deposit, 'Selected', ''); ?> value='400'>RM400</option>
														<option <?php echo vali_iif('500' == $deposit, 'Selected', ''); ?> value='500'>RM500</option>
														<option <?php echo vali_iif('600' == $deposit, 'Selected', ''); ?> value='600'>RM600</option>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Deposit Status</label>
											<select name="refund_dep_payment" class="form-control">
													<option value="">Please Select</option>
													<option <?php echo vali_iif('Cash' == $refund_dep_payment, 'Selected', ''); ?> value='Cash'>Cash</option>
													<option <?php echo vali_iif('Online' == $refund_dep_payment, 'Selected', ''); ?> value='Online'>Online</option>
													<option <?php echo vali_iif('Card' == $refund_dep_payment, 'Selected', ''); ?> value='Card'>Card</option>
											</select>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-12">
										<center>
											<div class="alert alert-warning" role="alert">
												<b>Survey</b>
											</div>
										</center>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Survey</label>
												<select name="survey_type" class="form-control" id="survey" onchange="change();">
													<option <?php echo vali_iif('Banner' == $survey_type, 'Selected', ''); ?> value='Banner'>Banner</option>
													<option <?php echo vali_iif('Bunting' == $survey_type, 'Selected', ''); ?> value='Bunting'>Bunting</option>
													<option <?php echo vali_iif('Facebook Ads' == $survey_type, 'Selected', ''); ?> value='Freinds'>Facebook Ads</option>
													<option <?php echo vali_iif('Freind' == $survey_type, 'Selected', ''); ?> value='Freinds'>Freinds</option>
													<option <?php echo vali_iif('Google Ads' == $survey_type, 'Selected', ''); ?> value='Google Ads'>Google Ads</option>
													<option <?php echo vali_iif('Magazine' == $survey_type, 'Selected', ''); ?> value='Magazine'>Magazine</option>
													<option <?php echo vali_iif('Others' == $survey_type, 'Selected', ''); ?> value='Others'>Others</option>
												</select>
											</div>
									</div>
									<div id="survey_details">
											
									</div>
								</div>

								<div class="text-center">
									<div class="form-group">
										<button type="submit" class="btn btn-success" name="btn_save">Save</button>
										<a type="button" class="btn btn-warning" href="counter_reservation.php" name="btn_cancel">Cancel</a>
									</div>
								</div>
						</div>
						</div>
						</form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php');?>

<script type="text/javascript">
 function change() {
        var select = document.getElementById("survey");
        var divv = document.getElementById("survey_details");
        var value = select.value;
        if (value == "Others") {
            toAppend = "<div class='col-md-6'><div class='form-group'><label class='control-label'>Survey Details</label><input class='form-control' type='textbox' name='survey_details' value='<?php echo $survey_details; ?>' ></div></div>"; divv.innerHTML=toAppend; return;
			}
			if (value == "non") {
					toAppend = "<div class='col-md-6'><div class='form-group'></div></div>";divv.innerHTML = toAppend;  return;
				}
     }
</script>

<script>
    $(document).ready(function () {
        var date_input = $('input[name="license_exp"]');
        var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
        date_input.datepicker({
            format: 'dd/mm/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>

<script>
    $(document).ready(function () {
        var date_input = $('input[name="drv_license_exp"]');
        var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
        date_input.datepicker({
            format: 'dd/mm/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>
