<?php
include "_header.php";
func_setReqVar();

if (isset($_FILES['image'])) {
    $errors = array();
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
    $expensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
    } if ($file_size > 2097152) {
        $errors[] = 'File size must be excately 2 MB';
    } if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "assets/img/" . $file_name);
        echo "Success";
    } else {
        print_r($errors);
    }
}

if (isset($btn_save)) {
    func_setValid("Y");
    if (func_isValid()) {
        $sql = "UPDATE job
        SET
		completed_by = '$completed_by',
        quest_desc = '$quest_desc',
        quest_prove = '$file_name',
        point = point + 1
        WHERE id = " . $_GET['id'];
        db_update($sql);
        vali_redirect('dashboard.php');
    }
} else {
    $sql = "SELECT * FROM job WHERE id=" . $_GET['id'];
    db_select($sql);
    if (db_rowcount() > 0) {func_setSelectVar();
    }
}?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Job Quest</h4>
                </div>
            <div class="card-content">
            <form method="POST"  enctype="multipart/form-data">
						<span style="color:red"><?php echo func_getErrMsg(); ?></span>
                               
                                <div class="row">
                                    <div class="col-md-12">
                                        <center>
                                            <div>
                                                <label class="control-label">Image</label>
                                                <input class="btn btn-default" type="file" name="image">
                                            </div>
                                        </center>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Completed By</label>
                                            <select name="completed_by" class="form-control">
                                                <?php
                                                $sql = "SELECT id, name FROM user"; db_select($sql); if(db_rowcount()>0){ for($j=0;$j<db_rowcount();$j++){ $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$user,'Selected','').">".db_get($j,1)."</option>"; } } echo $value; ?>
                                            </select>   
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Description</label>
                                            <input class="form-control" name="quest_desc" type="text" value="<?php echo $quest_desc; ?>">
                                        </div>
                                    </div>
                                </div>

                                   <div class="form-group">
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                            <button type="button" class="btn btn-info" onclick="location.href=dashboard.php" name="btn_cancel">Cancel</button>
                                        </div>
                                    </div>
					</form>
            </div>
        </div>
    </div>
</div>

<?php include '_footer.php';?>
