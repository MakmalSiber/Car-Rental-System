<?php
include("_header.php");

func_setReqVar();

if(isset($btn_save)){
    func_setValid("Y");
    func_isEmpty($location_id, "location");
    func_isEmpty($vehicle_id, "vehicle");
    func_isEmpty($fleet_date, "fleet date");
    func_isEmpty($cost_type, "cost type");
    func_isEmpty($pic, "pic");
    func_isEmpty($amount, "amount");
    
    if(func_isValid()){
        $sql="INSERT INTO fleet_cost
        (
        location_id, 
        fleet_date, 
        vehicle_id, 
        cost_type, 
        pic, 
        amount, 
        cid, 
        mdate
        )
        VALUES
        (
        '$location_id',
        'conv_datetodbdate($fleet_date)',
        '$vehicle_id',
        '$cost_type',
        'conv_text_to_dbtext3($pic)',
        'conv_text_to_dbtext3($item)',
        '$amount', 
        " . $_SESSION['cid'] . ",
        CURRENT_TIMESTAMP		
        )";
        //echo $sql;
        db_update($sql);
        
        vali_redirect("fleet_management_cost.php?btn_search=Search&page=".$page."&search_vehicle=".$search_vehicle);
    }
}

?>

<link rel="stylesheet" href="assets/css/datepicker.css" />

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="red">
					<h4 class="title">Cost</h4>
                </div>
            <div class="card-content">
            <form method="POST" enctype="multipart/form-data">
						<span style="color:red"><?php echo func_getErrMsg();?></span>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                <label class="control-label">Location</label>
                                    <select class="form-control" name="location_id" <?php echo $disabled;?>>
                                        <?php 
                                        
                                        $value = "";
                                        
                                        $sql = "SELECT id, description from location WHERE status = 'A'";
                                        db_select($sql);
                                        if(db_rowcount()>0){
                                            for($j=0;$j<db_rowcount();$j++){
                                                $value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$location_id,'Selected','').">
                                                ".db_get($j,1)."</option>";
                                            }
                                        }
                                        
                                        echo $value;
                                        
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label class="control-label">Date</label>
                                    <input class="form-control" type="text" id="fleet_date" name="fleet_date" value="<?php echo $fleet_date;?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                
						<div class="form-group label-floating">
							<label class="control-label">Vehicle</label>
								<select class="form-control" name="vehicle_id" <?php echo $disabled;?>>
									<?php 
									
									$value = "";
									
									$sql = "SELECT id, reg_no, model, year from vehicle";
									db_select($sql);
									if(db_rowcount()>0){
										for($j=0;$j<db_rowcount();$j++){
											$value = $value."<option value='".db_get($j,0)."' ".vali_iif(db_get($j,0)==$vehicle_id,'Selected','').">
											".db_get($j,1)." : ".db_get($j,2). " (" .db_get($j,3). ")</option>";
										}
									}
									
									echo $value;
									
									?>
								</select>							
                        </div>
                    </div>
                </div>


					<div class="row">
                        <div class="col-md-4">
                            <div class="form-group label-floating">
                                <label class="control-label">Cost Type</label>
                                    <select name="cost_type" class="form-control">
                                        <option value='Fuel' <?php echo vali_iif('Fuel'==$cost_type,'Selected','');?>>Fuel</option>
                                        <option value='Service' <?php echo vali_iif('Service'==$cost_type,'Selected','');?>>Service</option>
                                        <option value='Wash' <?php echo vali_iif('Wash'==$cost_type,'Selected','');?>>Wash</option>
                                        <option value='Etc' <?php echo vali_iif('Etc'==$cost_type,'Selected','');?>>Etc</option>
                                    </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group label-floating">
                                <label class="control-label">Person In Charge (PIC)</label>
                                <input type="text" class="form-control" name="pic" value="<?php echo $pic;?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group label-floating">
                                <label class="control-label">Amount</label>
                                    <input type="text" class="form-control" name="amount" value="<?php echo $amount;?>">
                            </div>
                        </div>
                    </div>

						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-success" name="btn_save">Save</button>
								<button type="button" class="btn btn-warning" onclick="location.href='fleet_management_cost.php?btn_search=&search_vehicle=<?php echo $search_vehicle;?>'">Cancel</button>
							</div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

     <!--   Core JS Files   -->
     <script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!-- Date Picker -->
    <script src="assets/js/bootstrap-datepicker.js"></script>


<script>
    $(document).ready(function () {
        var date_input = $('input[name="fleet_date"]');
        var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
        date_input.datepicker({
            format: 'dd/mm/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>

