<?php
include("_header.php");
func_setReqVar();
if (isset($btn_save)) {
	func_setValid("Y");
	if (func_isValid()) {
		$sql = "SELECT id, season_name FROM season_rental";
		db_select($sql);
		if (db_rowcount() > 0) {
			for ($i = 0; $i < db_rowcount(); $i++) {
				$sql = "INSERT INTO 
					season_rental_rate
					(
					vehicle_id, 
					season_id,  
					rate, 
					cid, 
					cdate
					)
					VALUES
					(
					" . $_GET['id'] . ",
					" . db_get($i, 0) . ",
					" . $rate[$i] . ",
					" . $_SESSION['cid'] . ",
					CURRENT_TIMESTAMP
					)
					";
				db_update($sql);
			}
		}
		vali_redirect("manage_vehicle.php?btn_search=Search&page=" . $page . "&search_name=" . $search_name);
	}
} ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="orange">
					<h4 class="title">Under Construction</h4>
                </div>
            <div class="card-content">
            <form method="POST">
				<span style="color:red"><?php echo func_getErrMsg();?></span>
						
						<?php
 $sql = "SELECT season_rental.id, season_name, rate FROM season_rental LEFT JOIN season_rental_rate ON season_id=season_rental.id". $where; db_select($sql); if(db_rowcount()>0){ for($i=0;$i<db_rowcount();$i++){ echo "	<div class='form-group'>
												<label class='col-sm-2 control-label'>* ".db_get($i,1)."</label>
												<div class='col-sm-10'>
													<input type='hidden' value='".db_get($i,0)."' name='".db_get($i,1)."'>
													<input type='text' class='form-control' placeholder='".db_get($i,1)."' name='rate[$i]' style='width: 10em' value=''>
												</div>
											</div>"; } } ?>
						<div class="form-group">
							<div class="text-center">
								<button type="submit" class="btn btn-succes" name="btn_save">Save</button>
								<button type="button" class="btn btn-warning" onclick="location.href='manage_vehicle.php?page=<?php echo $page;?>&btn_search=&search_name=<?php echo $search_name;?>'" name="btn_cancel">Cancel</button>
							</div>
						</div>
					</form>
            </div>
        </div>
    </div>
</div>

