<?php

include('_header.php');

func_setReqVar();

if (isset($btn_save)) {
    func_setValid("Y");

    if (func_isValid()) {

        $vehicle_id = $_GET['id'];

        $sql = "INSERT INTO investor
        (
            vehicle_id,
            investor_name,
            phone_no,
            address,
            nric,
            bank_name,
            monthly_loan,
            loan_account_no,
            owner_account_no,
            value_in,
            rate
        )
        VALUES
        (
            '$vehicle_id',
            '$name',
            '$phone_no',
            '$address',
            '$nric',
            '$commercial_bank_name',
            '$monthly_loan',
            '$loan_account_no',
            '$owner_account_no',
            '$value_in',
            '$rate'
        )";
        db_update($sql);
        vali_redirect("manage_vehicle.php");
    }

}
?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" data-background-color="orange">
                        <h4 class="title">Rental Options</h4>
                    </div>
                    <div class="card-content">
                        <?php echo $_GET['id']; ?>
                        <form method="POST">
                            <span style="color:red">
                                <?php echo func_getErrMsg(); ?>
                            </span>

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Name</label>
                                        <input class="form-control" name="name" value="<?php echo $name; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Address</label>
                                        <input class="form-control" name="address" value="<?php echo $address; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">NRIC</label>
                                        <input type="text" class="form-control" name="nric" value="<?php echo $nric; ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Phone Number</label>
                                        <input type="text" class="form-control" name="phone_no" value="<?php echo $phone_no; ?>">
                                    </div>
                                </div>
                            </div>
                           
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Commercial Bank Name</label>
                                        <input type="text" class="form-control" name="commercial_bank_name" value="<?php echo $commercial_bank_name; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Owner Account Number</label>
                                        <input type="text" class="form-control" name="owner_account_no" value="<?php echo $owner_account_no; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Loan Account Number</label>
                                        <input type="text" class="form-control" name="loan_account_no" value="<?php echo $loan_account_no; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Monthly Loan</label>
                                        <input type="text" class="form-control" name="monthly_loan" value="<?php echo $monthly_loan; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                    <label class="control-label">Value In</label>
                                        <div>
                                            <select name="value_in" class="form-control">
                                                <option value='P' <?php echo vali_iif('P'==$value_in,'Selected','');?>>Percentage</option>
                                                <option value='A' <?php echo vali_iif('A'==$value_in,'Selected','');?>>Amount</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label">Rate</label>
                                        <div>
                                            <input type="text" class="form-control" placeholder="Rate" name="rate" value="<?php echo $rate;?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                    <button type="button" class="btn btn-warning" onclick="location.href='manage_vehicle.php?btn_search=&search_rental_description=<?php echo $search_rental_description; ?>'">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php include('_footer.php');?>