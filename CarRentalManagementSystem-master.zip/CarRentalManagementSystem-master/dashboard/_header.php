<?php
require("lib/setup.php");
session_start();
$sql = "SELECT 
	company_name,
	website_name,
	registration_no,
	address AS company_address,
	phone_no AS company_phone_no,
	image AS company_image
	FROM company WHERE id IS NOT NULL";
db_select($sql);
if (db_rowcount() > 0) {
	func_setSelectVar();
} ?>

<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/<?php echo $company_image; ?>" />
	<link rel="icon" type="image/png" href="assets/img/<?php echo $company_image; ?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title><?php echo $website_name; ?></title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="assets/css/material-dashboard.css" rel="stylesheet"/>
   
    <!--  JQuery UI    -->
    <link href="assets/css/jquery-ui.css" rel="stylesheet"/>


    <!--     Fonts and icons     -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

	<!-- Fancy Box -->
	<link rel="stylesheet" href="assets/css/bootstap-datepicker.css"/>

	<!-- Date Picker -->
	<link rel="stylesheet" href="assets/css/datepicker.css" />
    
</head>




