<html lang="en">

<?php
include "_header.php";

func_setReqVar();

$sql = "SELECT * FROM user WHERE id=" . $_SESSION['cid'];
//echo $sql;
db_select($sql);
if (db_rowcount() > 0) {
    func_setSelectVar();
}
?>

<body>

<div class="wrapper">
    
    <?php include '_leftpanel.php';?>

    <div class="content">

        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                <iframe id='frame' src="dashboard.php" frameborder="0" scrolling="no" width="100%" onload="resizeIframe(this)"></iframe>
                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Company
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Portfolio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    <a href="#"><?php echo $company_name; ?></a>, made with love for a better web
                </p>
            </div>
        </footer>
    </div>
</div>

<script>
  function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
  }
</script>

<?php include('_footer.php'); ?>

</body>

</html>
