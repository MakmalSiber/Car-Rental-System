<?php
use setasign\Fpdi\Fpdi;

require_once ('pdf/fpdf.php');
require_once ('pdf/autoload.php');

include ('_header.php');

func_setReqVar();

// user
$sql = "SELECT * FROM user WHERE id=".$_SESSION['cid'];

db_select($sql);
if (db_rowcount() > 0) {
	func_setSelectVar();
}

// Agreement

$sql = "SELECT
vehicle.id,
reg_no,
license_no,
model,
concat(firstname,' ' ,lastname) as fullname,
nric_no,
address AS customer_address,
postcode,
city,
country,
phone_no AS customer_phone_no,
email,
ref_name,
ref_relationship,
ref_phoneno,
balance,
sub_total,
est_total,
refund_dep,
refund_dep_status,
p_cost,
r_cost,
payment_details,
DATE_FORMAT(pickup_date, '%d/%m/%Y') AS pickup_date,
DATE_FORMAT(pickup_time, '%H:%i') AS pickup_time,
DATE_FORMAT(return_date, '%d/%m/%Y') AS return_date,
DATE_FORMAT(return_time, '%H:%i') AS return_time,
agreement_no
FROM vehicle
LEFT JOIN booking_trans ON vehicle.id = vehicle_id
LEFT JOIN customer ON customer_id = customer.id
WHERE booking_trans.id =" . $_GET['id'];
db_select($sql);

//echo $sql;
db_select($sql);
if (db_rowcount() > 0) {
    func_setSelectVar();
}

// initiate FPDI
$pdf = new Fpdi('L','mm',array(225,150));
// add a page
$pdf->AddPage();
// set the source file
$pdf->setSourceFile('assets/document/receipt.pdf');
// import all page
$tplIdx = $pdf->importPage(1);
// use the imported page and place it at position 10,10 with a width of 100 mm
$pdf->useTemplate($tplIdx);

// now write some text above the imported page
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetTextColor(0, 0, 0);

// logo company
$pdf->Image('assets/img/'.$company_image, 5, 8, 20);

// company name
$pdf->SetXY(25, 12);
$pdf->Write(0, $company_name);

// company address font
$pdf->SetFont('Helvetica', '', 8);
$pdf->SetTextColor(0, 0, 0);

// company address 
$pdf->SetXY(25, 14);
$pdf->MultiCell(70, 3.5, $company_address, 0);

// company phone no. 
$pdf->SetXY(25, 23);
$pdf->Write(0, $company_phone_no);

// font size
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetTextColor(0, 0, 0);

// receipt no
$pdf->SetXY(190,15.5);
$pdf->Write(0, $agreement_no);

// received from
$pdf->SetXY(34,38.5);
$pdf->Write(0, $fullname);

// model from
$pdf->SetXY(34,56.5);
$pdf->Write(0, $make.$model);

// rate
$pdf->SetXY(130,56.5);
$pdf->Write(0, 'RM'.$sub_total);

// reg no
$pdf->SetXY(34,64.5);
$pdf->Write(0, $reg_no);

// cdw
$pdf->SetXY(130,64.5);
$pdf->Write(0, '');

// pickup date
$pdf->SetXY(32,72);
$pdf->Write(0, $pickup_date);

// return date
$pdf->SetXY(70,72);
$pdf->Write(0, $return_date);

// refund dep
$pdf->SetXY(130,72);
$pdf->Write(0, 'RM'.$refund_dep);

// pickup time
$pdf->SetXY(32,79);
$pdf->Write(0, $pickup_time);

// return time
$pdf->SetXY(70,79);
$pdf->Write(0, $pickup_time);

// delivery cost
if($p_cost >= 1){
$pdf->SetXY(130,79);
$pdf->Write(0, 'RM'.$p_cost);
} elseif($r_cost >=1){
    $pdf->SetXY(130,79);
    $pdf->Write(0, 'RM'.$r_cost);   
} else {
    $pdf->SetXY(130,79);
    $pdf->Write(0, '');
}

// total
$receipt_total = ($sub_total + $refund_dep + $r_cost + $p_cost);
$pdf->SetXY(130,87);
$pdf->Write(0, 'RM'.$receipt_total);

// payment details
if($payment_details == "Cash"){
    $pdf->SetXY(177,57);
    $pdf->Write(0, '/');
} elseif($payment_details == "Card"){
    $pdf->SetXY(177,72);
    $pdf->Write(0, '/');
} elseif($payment_details == "Online"){
    $pdf->SetXY(177,79);
    $pdf->Write(0, '/');
}

//received by
$pdf->SetXY(10,110);
$pdf->Write(0, $username); 

// agrrement no
$pdf->SetXY(98,110);
$pdf->Write(0, $agreement_no); 

// date
$pdf->SetXY(172,110);
$pdf->Write(0, date("d/m/Y")); 

ob_clean();
header("Content-type:application/pdf");
header("Content-Disposition:attachment;filename='downloaded.pdf'");
$pdf->Output();
ob_end_flush();
