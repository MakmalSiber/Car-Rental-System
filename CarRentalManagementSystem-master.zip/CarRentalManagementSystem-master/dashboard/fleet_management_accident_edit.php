<?php
include "_header.php";

func_setReqVar();

if (isset($btn_save)) {
    func_setValid("Y");
    func_isEmpty($vehicle_id, "vehicle");
    func_isEmpty($car_status, "car_status");
    func_isEmpty($accident_date, "accident date");
    func_isEmpty($closed_date, "closed date");
    func_isEmpty($action_taken, "action taken");
    func_isEmpty($pic, "pic");
    func_isEmpty($pic_phone, "pic_phone");
    func_isEmpty($car_location, "car location");
    func_isEmpty($cost, "cost");
    func_isEmpty($period_close_case, "period close case");
    func_isEmpty($follow_up_date, "follow up date");
    func_isEmpty($remark, "remark");
    func_isEmpty($oe_report, "oe that reported");

    if ($_FILES["image"]["name"] != "") {
        $file_name = date("Ymd") . "_" . basename($_FILES["image"]["name"]);
        $target_path = DOC_ROOT . "images/" . $file_name;
        $file = "accident_image = '" . $file_name . "',";
        //echo $target_path;
    } else {
        $file = "";
    }

    if (($_FILES["image"]["type"] == "") || ($_FILES["image"]["type"] == "image/gif") || ($_FILES["image"]["type"] == "image/jpeg") || ($_FILES["image"]["type"] == "image/jpg") || ($_FILES["image"]["type"] == "image/pjpeg") || ($_FILES["image"]["type"] == "image/x-png") || ($_FILES["image"]["type"] == "image/png")) {
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_path);
    } else {
        func_setErrMsg("- File is not a valid image file");
    }

    if (func_isValid()) {

        $sql = "UPDATE fleet_accident SET
			vehicle_id = '" . $vehicle_id . "',
			car_status = '" . conv_text_to_dbtext3($car_status) . "',
			accident_date = '" . conv_datetodbdate($accident_date) . "',
			closed_date = '" . conv_datetodbdate($closed_date) . "',
			action_taken = '" . conv_text_to_dbtext3($action_taken) . "',
			pic = '" . conv_text_to_dbtext3($pic) . "',
			pic_phone = '" . conv_text_to_dbtext3($pic_phone) . "',
			car_location = '" . conv_text_to_dbtext3($car_location) . "',
			cost = " . $cost . ",
			period_close_case = '" . conv_text_to_dbtext3($period_close_case) . "',
			follow_up_date = '" . conv_datetodbdate($follow_up_date) . "',
			remark = '" . conv_text_to_dbtext3($remark) . "',
			oe_report = '" . conv_text_to_dbtext3($oe_report) . "',
			status = '" . $status . "',
			" . $file . "
			mid = " . $_SESSION['cid'] . ",
			mdate = CURRENT_TIMESTAMP WHERE id=" . $_GET['id'];
        //echo $sql;
        db_update($sql);

        vali_redirect("fleet_management_accident.php?btn_search=Search&page=" . $page . "&search_vehicle=" . $search_vehicle);
    }} else if (isset($btn_delete)) {

    $sql = "DELETE FROM fleet_accident WHERE id=" . $_GET['id'];
    db_update($sql);

    vali_redirect("fleet_management_accident.php?btn_search=&search_start_date=" . $search_start_date . "&search_end_date=" . $search_end_date . "&page=" . $page);
} else {

    $sql = "SELECT id,
				vehicle_id,
				car_status,
				DATE_FORMAT(accident_date, '%d/%m/%Y') as accident_date,
				DATE_FORMAT(closed_date, '%d/%m/%Y') as closed_date,
				action_taken,
				pic,
				pic_phone,
				car_location,
				cost,
				period_close_case,
				DATE_FORMAT(follow_up_date, '%d/%m/%Y') as follow_up_date,
				remark,
				oe_report,
				status,
				accident_image as image,
				cid,
				cdate
				FROM fleet_accident WHERE id=" . $_GET['id'];
    db_select($sql);
    if (db_rowcount() > 0) {
        func_setSelectVar();
    }

}
?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="red">
                            <h4 class="title">Accident</h4>
                        </div>

                        <!-- content -->
                        <div class="card-content">

                            <form method="POST" enctype="multipart/form-data">

                                <span style="color:red">
                                    <?php echo func_getErrMsg(); ?>
                                </span>

                                <div class="form-group">
                                    <label class="control-label">Vehicle</label>
                                </div>

                                <div class="form-group">
                                    <select class="form-control" name="vehicle_id" <?php echo $disabled; ?>>
                                        <option value="">Please Select</option>

                                        <?php
                                        $value = "";

                                        $sql = "SELECT id, reg_no, model, year from vehicle";
                                        db_select($sql);
                                        if (db_rowcount() > 0) {
                                            for ($j = 0; $j < db_rowcount(); $j++) {
                                                $value = $value . "<option value='" . db_get($j, 0) . "' " . vali_iif(db_get($j, 0) == $vehicle_id, 'Selected', '') . ">
                                                                                                                                    " . db_get($j, 1) . " : " . db_get($j, 2) . " (" . db_get($j, 3) . ")</option>";
                                            }
                                        }

                                        echo $value;
                                        ?>

                                    </select>

                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label"> Car Status</label>
                                            <input type="text" class="form-control" name="car_status" value="<?php echo $car_status; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Accident Date</label>
                                            <input class="form-control" type="text" id="accident_date" name="accident_date" value="<?php echo $accident_date; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Closed Date</label>
                                            <input class="form-control" type="text" id="closed_date" name="closed_date" value="<?php echo $closed_date; ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Action Taken</label>
                                            <input type="text" class="form-control" name="action_taken" value="<?php echo $action_taken; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Person In Charge (PIC)</label>
                                            <input type="text" class="form-control" name="pic" value="<?php echo $pic; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">PIC Phone</label>
                                            <input type="text" class="form-control" name="pic_phone" value="<?php echo $pic_phone; ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Follow Up Date</label>
                                            <input class="form-control" type="text" id="follow_up_date" name="follow_up_date" value="<?php echo $follow_up_date; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Remark</label>
                                            <input class="form-control" type="text" name="remark" value="<?php echo $remark; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">OE that Reported</label>
                                            <input type="text" class="form-control" name="oe_report" value="<?php echo $oe_report; ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Car Location</label>
                                            <input type="text" class="form-control" name="car_location" value="<?php echo $car_location; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Cost</label>
                                            <input type="text" class="form-control" name="cost" value="<?php echo $cost; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Period To Close Case</label>
                                            <input type="text" class="form-control" name="period_close_case" value="<?php echo $period_close_case; ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                            <div class="form-group label-floating">
                                                            <label class="control-label">Status</label>
                                                            <select name="transmission" class="form-control">
                                                                <option value='O' <?php echo vali_iif('O' == $status, 'Selected', ''); ?>>Open</option>
                                                                <option value='C' <?php echo vali_iif('C' == $status, 'Selected', ''); ?>>Close</option>
                                                            </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Accident Image</label>
                                                <input type="file" id="inputFile4" multiple="">
                                                <div class="input-group">
                                                    <input type="text" readonly="" class="form-control" name="image" value=" <?php echo $image; ?>">
                                                        <span class="input-group-btn input-group-sm">
                                                        <button type="button" class="btn btn-fab btn-fab-mini">
                                                            <i class="material-icons">attach_file</i>
                                                        </button>
                                                        </span>
                                                </div>
                                            </div>
                                        </div>
                                </div>

                                <div class="form-group">
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success" name="btn_save">Save</button>
                                        <button type="submit" class="btn btn-danger" name="btn_delete">Delete</button>
                                        <button type="button" class="btn btn-warning" onclick="location.href='fleet_management_accident.php?btn_search=&search_vehicle=<?php echo $search_vehicle; ?>'">Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!-- Date Picker -->
    <script src="assets/js/bootstrap-datepicker.js"></script>


    <script>
        $(document).ready(function () {
            var date_input = $('input[name="accident_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>

    <script>
        $(document).ready(function () {
            var date_input = $('input[name="closed_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>

    <script>
        $(document).ready(function () {
            var date_input = $('input[name="follow_up_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>