<?php
include("_header.php"); 
func_setReqVar(); 

if (isset($btn_clear)) { 
	vali_redirect('report_daily_pay.php'); 
} ?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="purple">
					<h4 class="title">Daily Pay</h4>
                </div>
            <div class="card-content">
			<form>
			<div class="form-group">
				<label class="control-label">Date</label>
					<input type="text" class="form-control" id="search_date" name="search_date" value="<?php echo $search_date;?>">
			</div>
			<div class="form-group">
				<div class="text-center">
					<button type="submit" class="btn btn-success" name="btn_search">Search</button>
					<button type="submit" class="btn btn-danger" name="btn_clear">Clear</button>
				</div>
			</div>
			<div class="table-responsive">
			<table class="table">
				<thead>
					<tr>
					<th>No</th>
					<th>Plate No.</th>
					<th>Status</th>
					<th>Deposit Status</th>
					<th>Rent Status</th>
					<th>Time Pickup</th>
					<th>Time Return</th>
					<th>Name</th>
					<th>Deposit</th>
					<th>Days</th>
					<th>Total</th>
					</tr>
				</thead>
				<tbody>
				<?php
				 func_setPage(); 
				 func_setOffset(); 
				 func_setLimit(10); 
				 if(isset($btn_search)){ 
					 if($search_date!=""){ 
						 $where=" AND DATE_FORMAT(pickup_date, '%d/%m/%Y') LIKE '%".$search_date."%'"; 
					} 
				} 
					$sql = "SELECT 
                    vehicle.id,
					reg_no,
					vehicle.availability,
					refund_dep_status,
					booking_trans.status,
					DATE_FORMAT(pickup_date, '%d/%m/%Y') as pickup_date, 
					DATE_FORMAT(pickup_time, '%H:%i:%s') as pickup_time, 
					DATE_FORMAT(return_date, '%d/%m/%Y') as return_date, 
					DATE_FORMAT(return_time, '%H:%i:%s') as return_time, 
                    booking_trans.id,
					concat(firstname,' ' ,lastname) as name,
					refund_dep,
					refund_dep_payment,
					sub_total
					FROM vehicle 
					LEFT JOIN booking_trans ON vehicle.id = vehicle_id 
					LEFT JOIN class ON class.id = class_id 
					LEFT JOIN customer ON customer_id = customer.id 
					WHERE booking_trans.id IS NOT NULL" .$where; db_select($sql); func_setTotalPage(db_rowcount()); db_select($sql." LIMIT ".func_getLimit()." OFFSET ". func_getOffset()); if(db_rowcount()>0){ for($i=0;$i<db_rowcount();$i++){ if(func_getOffset()>=10){ $no=func_getOffset()+1+$i; }else{ $no=$i+1; } echo "<tr>
									<td>".$no."</td>
									<td>".db_get($i,1)."</td>
									<td>".db_get($i,2)."</td>
									<td>".db_get($i,3)."</td>
									<td>".db_get($i,4)."</td>
									<td>".db_get($i,5)." ".db_get($i,6)."</td>
									<td>".db_get($i,7)." ".db_get($i,8)."</td>
									<td>".db_get($i,10)."</td>
									<td>RM ".db_get($i,11)." / ".db_get($i,12)."</td>
									<td>".dateDifference(conv_datetodbdate(db_get($i,5)) . db_get($i,6), conv_datetodbdate(db_get($i,7)) . db_get($i,8), '%d Day %h Hours')."</td>
									<td>RM ".db_get($i,13)."</td>
									<td></td>
								</tr>"; } }else{ echo "<tr><td colspan='20'>No records found</td></tr>"; } ?>
				<tr>
					<td colspan="20" style="text-align:center">
					<?php  func_getPaging('report_daily_pay.php?x&btn_search=&search_date='.$search_date.'&page'.$page); ?>
					</td>
				</tr>
				</tbody>
			</table>
			</div>
		</div>
	</div>
	</form>
            </div>
        </div>
    </div>
</div>

<?php include('_footer.php'); ?>

<script>
        $(document).ready(function () {
            var date_input = $('input[name="search_date"]');
            var container = $('.bootstrap form').length > 0 ? $('.bootstrap form').parent() : "body";
            date_input.datepicker({
                format: 'dd/mm/yyyy',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
</script>

