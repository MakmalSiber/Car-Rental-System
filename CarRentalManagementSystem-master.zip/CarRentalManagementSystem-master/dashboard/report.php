<?php
  // including FusionCharts PHP wrapper
  include('fusioncharts.php'); 

     //setting up connection with database
    $host_db="localhost"; // MySQL host server (might vary depending upon user)
    $user_db="root"; // MySQL database username
    $pass_db="password"; // MySQL password
    $name_db="myezgo_carrental"; // name of the database

    $dbhandle = new mysqli($host_db, $user_db, $pass_db, $name_db);
 
    if ($dbhandle->connect_error) {
        exit("There was an error with your connection".$dbhandle->connect_error);
    }

    $strQuery = "SELECT DISTINCT pickup_date, pickup_time, return_date, return_time FROM  booking_trans";
 
    $result = $dbhandle->query($strQuery) or exit("Error code ({$dbhandle->errno}): {$dbhandle->error}");

?>

<html>
 
 <head>
    
    <?php

    if ($result) {
    
        // creating an associative array to store the chart attributes        
        $arrData = array(
        "chart" => array(
            "theme" => "fint",
            "caption" => "Browser Market Share",
            "subcaption" => "February 2016",
            "captionFontSize" => "24",
            "paletteColors" => "#A2A5FC, #41CBE3, #EEDA54, #BB423F #,F35685",
            "baseFont" => "Quicksand, sans-serif",
            //more chart configuration options
        )
        );
    
        $arrData["data"] = array();
    
        // iterating over each data and pushing it into $arrData array
        while ($row = mysqli_fetch_array($result)) {
        array_push($arrData["data"], array(
            label => $row["browser"],
            value => $row["shareval"]
        ));
        }
    
        $jsonEncodedData = json_encode($arrData);
    
    }

    // Syntax for the instance -         
    $var = new FusionCharts("type of chart", 
    "unique chart id", 
    "width of chart", 
    "height of chart", 
    "div id to render the chart", 
    "type of data", 
    "actual data");

    // creating FusionCharts instance
    $doughnutChart = new FusionCharts("doughnut2d", "browserShareChart" , "100%", "450", "doughnut-chart", "json", $jsonEncodedData);
        
    // FusionCharts render method
    $doughnutChart->render();
        
    // closing database connection      
    $dbhandle->close();

    ?>

    <div id="doughnut-chart">A beautiful donut chart is on its way!</div>
  
   <!-- including FusionCharts JavaScript file -->
   <sript language="JavaScript" type="text/javascript" src="assets/js/fusioncharts.js"></sript>
   <sript language="JavaScript" type="text/javascript" src="assets/js/fusioncharts.charts.js"></sript>
 
 </head>
  
</html>