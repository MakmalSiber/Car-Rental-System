
<!-- START: FOOTER -->
<section id="footer">
	<footer>
		<div class="row sm-footer">
			<div class="container clear-padding">
				<div class="col-md-3 col-sm-6 footer-about-box">
					<h4><?php echo $website_name; ?></h4>
					<p>Our expertise provides the best, comfortable, clean and safe rental cars and vans for you and your loved ones.</p>
					<a href="#">READ MORE</a>
				</div>
				<div class="col-md-3 col-sm-6 contact-box">
					<h4>CONTACT US</h4>
					<p><i class="fa fa-home"></i>909 Jalan S2 F23 Garden Home</p>
					<p><i class="fa fa-envelope-o"></i> sales@myezgo.com</p>
					<p><i class="fa fa-phone"></i><?php echo $company_phone_no; ?></p>
					<p class="social-media">
						<a href="https://www.facebook.com/myezgon9/"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-google-plus"></i></a>
						<a href="#"><i class="fa fa-instagram"></i></a>
					</p>
				</div>
				<div class="clearfix visible-sm-block"></div>
				<div class="col-md-3 col-sm-6 footer-gallery">
					<h4>GALLERY</h4>
					<img src="assets/images/car10.jpg" alt="cruise">
					<img src="assets/images/car11.jpg" alt="cruise">
					<img src="assets/images/car12.jpg" alt="cruise">
					<img src="assets/images/car12.jpg" alt="cruise">
					<img src="assets/images/car10.jpg" alt="cruise">
					<img src="assets/images/car11.jpg" alt="cruise">
				</div>
				<div class="col-md-3 col-sm-6 footer-subscribe">
					<h4>SUBSCRIBE</h4>
					<p>Don't miss any deal. Subscribe to get offers alerts.</p>
					<form >
						<div class="col-md-10 col-sm-10 col-xs-9 clear-padding">
							<input type="email" required class="form-control" placeholder="Enter Your Email">
						</div>
						<div class="col-md-2 col-sm-2 col-xs-3 clear-padding">
							<button type="submit"><i class="fa fa-paper-plane"></i></button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row sm-footer-nav text-center">
			<p class="copyright">
				&copy; <?php echo $company_name; ?>
			</p>
			<div class="go-up">
				<a href="#"><i class="fa fa-arrow-up"></i></a>
			</div>
		</div>
	</footer>
</section>
<!-- END: FOOTER -->

</div>
<!-- END: SITE-WRAPPER -->
<!-- Load Scripts -->
<script src="assets/js/respond.js"></script>
<script src="assets/js/jquery.js"></script>
<script src="assets/plugins/owl.carousel.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery-ui.min.js"></script>
<script src="assets/js/bootstrap-select.min.js"></script>
<script src="assets/plugins/wow.min.js"></script>
<script type="text/javascript" src="assets/plugins/supersized.3.1.3.min.js"></script>
<script src="assets/js/js.js"></script>

